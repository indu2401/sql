import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class Main {

public static void main(String args[]) throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
				String mail="";boolean z=false;
				System.out.println("Customer Registration:\n");
				System.out.println("Enter the customer details:");
				System.out.println("Enter the first name:");
				String firstname=br.readLine();
				System.out.println("Enter the last name:");
				String Lastname=br.readLine();
				System.out.println("Enter the contact number:");
				String contact=br.readLine();
				System.out.println("Enter the e-mail id:");
				do{
					try{
				
				 mail=br.readLine();
				 z=validEmail(mail);
				 //System.out.println(z);
				// if(z)break;
				 if(!(z))
				{throw new emailException();
				}
				}
				catch (emailException m) {
					System.out.println("Re-enter Email ID");
				
				  }
				
				}while(!(z));
				
				System.out.println("Enter the proof type:");
				String type=br.readLine();
				System.out.println("Enter the proof id:");
				String proof=br.readLine(); 
		Customer c = new Customer();
				c.registerCustomer(firstname,Lastname,contact,mail,type,proof);
				c.display();
		
				
			
				
			

}
static boolean validEmail(String email) {
    
	if(email.contains("@")&&email.contains("."))
	{
		int i=email.indexOf("@");int j=email.indexOf(".");i++;j++;
		//System.out.println(i);
		//System.out.println(j);
		int diff=j-i;
		//System.out.println(diff);
		if(diff>1)
		return true;
	}
	return false;
}
static class emailException extends Exception
{
 public emailException()
 {

  System.out.println("Invalid Email ID");
 
}
}
} 
