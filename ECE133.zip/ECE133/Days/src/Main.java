import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class Main {

	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub
		String time1 = "1004/06/2018";
		String time2 = "01/06/2018";
		SimpleDateFormat sd = new SimpleDateFormat("dd/MM/yyyy");
		SimpleDateFormat sdf = new SimpleDateFormat("EEEE");
		Date d = sd.parse(time1);
		String days = sdf.format(d);
		System.out.println(days);
	}

}
