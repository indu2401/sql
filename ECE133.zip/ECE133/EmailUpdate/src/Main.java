import java.util.Scanner;


public class Main {

public static void register(String name,String address,String contact,String mail,String type,String proof)
	{
		int count=1; 

		System.out.println("Welcome "+name+".");
		System.out.println("Here are your details");
		System.out.println("Address: "+address);
		System.out.println("Contact Number: "+contact);
		System.out.println("E-Mail ID: "+mail);
		System.out.println("Proof type: "+type);
		System.out.println("Proof id: "+proof);
		System.out.println();
		System.out.println("Thank you for registering. Your id is "+count+"..");
		System.out.println();
		count++;
	} 

public static void  update(String name,String address,String contact,String mail,String type,String proof)
	{
		System.out.println("Your details are as follows");
		System.out.println("Name: "+name);
		System.out.println("Address: "+address);
		System.out.println("Contact Number: "+contact);
		System.out.println("E-Mail ID: "+mail);
		System.out.println("Proof type: "+type);
		System.out.println("Proof id: "+proof);
		System.out.println();
	} 

public static void main(String args[])
	{
				
		Scanner sc=new Scanner(System.in);
		System.out.println("Registration");
		System.out.println();
		System.out.println("Enter your name");
		String name=sc.nextLine();
		System.out.println("Enter your address");
		String address=sc.nextLine();
		System.out.println("Contact Number");
		String contact=sc.nextLine();
		System.out.println("E-Mail ID");
		String mail=sc.nextLine();
		System.out.println("Enter proof type");
		String type=sc.nextLine();
		System.out.println("Enter proof id");
		String proof=sc.nextLine();
		System.out.println();
		
		register(name,address,contact,mail,type,proof);
		
		System.out.println("Do you want to update the email id?(yes/no)");
			 
		String yn=sc.next();
			if(yn.equals("yes"))
				{
					System.out.println();
					System.out.println("Update Email:\nEnter new Email id");
					System.out.println();
					mail=sc.nextLine();
					mail=sc.nextLine();
					System.out.println("Email updated");
					System.out.println();
					//System.out.println(mail);
					update(name,address,contact,mail,type,proof);
					
				}else
				{
					System.out.println("Thank you");
				}
				sc.close();
			
			}
			
}

