import java.io.*;
public class Main {
	
	public static void register(String Name, String Address, String ContactNumber, String Email, String ProofType,String ProofID){
		System.out.println();
		System.out.println("Welcome " + Name + ".");
		System.out.println("Here are your details");
		System.out.println("Address: " + Address);
		System.out.println("Contact Number: " + ContactNumber);
		System.out.println("E-Mail ID: " + Email);
		System.out.println("Proof type: " + ProofType);
		System.out.println("Proof id: " + ProofID);
		System.out.println();
		System.out.println("Thank you for registering. Your id is 1..");
		
	}

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Registration");
		System.out.println();
		System.out.println("Enter your name");
		String name=br.readLine();
		System.out.println("Enter your address");
		String address=br.readLine();
		System.out.println("Contact Number");
		String contactNumber=br.readLine();
		System.out.println("E-Mail ID");
		String email=br.readLine();
		System.out.println("Enter proof type");
		String proofType=br.readLine();
		System.out.println("Enter proof id");
		String proofID=br.readLine(); 
		
		
		register(name, address, contactNumber, email, proofType, proofID);
		
	}

}
