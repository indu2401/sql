import java.util.*;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		String a = s.next();
		StringBuilder sb = new StringBuilder(a);
		String ss = sb.reverse().toString();
		if(a.equals(ss)){
			for(int i = 0 ;i<a.length() ; i++){
				int index = a.indexOf(a.charAt(i));
				int last_index = a.lastIndexOf(a.charAt(i));
				if((index+1) == (last_index)){
					System.out.println(index);
					System.out.println(last_index);
					System.out.println("yes");;
				}
				
			}
		}
	}

}
