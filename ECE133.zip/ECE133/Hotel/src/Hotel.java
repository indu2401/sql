import java.util.*;
public class Hotel{
String name, hotelId, address;
//String roomId, roomType, roomNumber, roomCapacity, roomAc, roomWifi, roomCabel, roomLaundry;
//ArrayList roomList=new ArrayList();
ArrayList<Room> robj = new ArrayList<Room>();
//ArrayList<Room> rom = new ArrayList<Room>();
public void addRoom(Room rom)
{
	robj.add(rom);
	
}
public void display()
{
	
	Iterator itr=robj.iterator();
	while(itr.hasNext()==true)
	{
		Room st=(Room)itr.next();
		System.out.println("Room Number :"+st.roomNumber);
		System.out.println("Room Type :"+st.roomType);
		System.out.println("Services Available:");
        if(st.roomAc.equals("true"))
        {
        	System.out.println("AC");
        }
        if(st.roomWifi.equals("true"))
        {
        	System.out.println("Wi-Fi");
        }
        if(st.roomCabel.equals("true"))
        {
        	System.out.println("Cable Connection");
        }
        if(st.roomLaundry.equals("true"))
        {
        	System.out.println("Laundry");
        }
        System.out.println();
	}
}
} 
