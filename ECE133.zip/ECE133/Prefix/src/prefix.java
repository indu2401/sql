import java.io.*;
import java.util.HashSet;
import java.util.Iterator;

public class prefix {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br =  new BufferedReader(new InputStreamReader(System.in));
		int n = Integer.parseInt(br.readLine());
		String a[]=new String[n];
		int count = 0;
		HashSet<String> set1 = new HashSet<String>();
		for(int i=0;i<n;i++)
		{
			a[i]=br.readLine();
			set1.add(a[i]);
		}
		Iterator itr = set1.iterator();
		while(itr.hasNext()){
			String first_String = (String) itr.next();
			if(itr.hasNext()){
				String prefix = (String) itr.next();
				
				if(prefix.length() > first_String.length() && prefix.substring(0, first_String.length()).equals(first_String) ){
					count++;
				}
			}
		}
		System.out.println(count);
	}

}
