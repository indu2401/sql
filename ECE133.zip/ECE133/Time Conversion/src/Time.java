import java.text.*;
import java.util.*;
public class Time {

	public static void main(String args[])throws Exception {
	        
	        Scanner br = new Scanner(System.in);
	        String train1 = br.nextLine();
	        String train2 = br.nextLine();
	        String exam = br.nextLine();
	        int travel= br.nextInt();
	        
	        Date d1 = new SimpleDateFormat("HH:mm:ss").parse(train1);
	        Date d2 = new SimpleDateFormat("HH:mm:ss").parse(train2);
	        Date d3 = new SimpleDateFormat("HH:mm:ss").parse(exam);
	        
	        
	        Calendar cal = Calendar.getInstance();
	        cal.setTime(d3);
	        cal.add(Calendar.MINUTE, travel);
	        
	        Date d4 = cal.getTime();
	        
	        // System.out.println(d4);
	        
	        if(d4.equals(d1) || d4.before(d1))
	        {
	       
	        System.out.println("Train1");
	       
	        }
	        
	        else if(d4.after(d1) && ( d4.equals(d2) || d4.before(d2)))
	        {
	       
	        System.out.println("Train2");
	       
	        }
	        else if(d4.after(d1) && d4.after(d2))
	        {
	       
	        System.out.println("No");
	       
	        }
	        
	    }
	    
	}
	
	

