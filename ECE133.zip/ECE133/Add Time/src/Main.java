import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class Main {

	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub
		
		StringBuffer sb = new StringBuffer("      As a Long day      ");
		sb.trimToSize();
		System.out.println(sb);
		String time1 = "13/01/2045";
		String time2 = "01/06/2018";
		SimpleDateFormat dt = new SimpleDateFormat("dd/MM/yyyy");
		Date d = dt.parse(time1);
		Calendar cal = Calendar.getInstance();
		cal.setTime(d);
		
		long days= TimeUnit.MILLISECONDS.toDays(cal.getTimeInMillis());
		
		System.out.println( "TimeUnit days: " + days);
		System.out.println( "TimeUnit years: " + days/365);
		Date d1 = dt.parse(time2);
		
		System.out.println(d.compareTo(d1));
		System.out.println("d" + d);
		System.out.println("d1" + d1);

		System.out.println("compare " + d1.compareTo(d));
		
		Calendar cal2 = Calendar.getInstance();
		cal2.setTime(d1);
		System.out.println( "dAY " + cal2.getDisplayName(Calendar.DAY_OF_WEEK, Calendar.LONG, Locale.US));
		System.out.println(cal2);
		System.out.println( "DATE " + cal.get(Calendar.DATE));
		cal.add(Calendar.HOUR_OF_DAY, cal2.get(Calendar.HOUR_OF_DAY));
		
		cal.add(Calendar.MINUTE, cal2.get(Calendar.MINUTE));
		
		cal.add(Calendar.SECOND, cal2.get(Calendar.SECOND));
		
		int dat = cal.get(Calendar.DAY_OF_MONTH);
		System.out.println(dat-1);
		String newTime = dt.format((cal.getTime()));
		System.out.println(newTime);
		
		String dates = "02/04/1985";
		SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		//SimpleDateFormat dSF = new SimpleDateFormat("MMM dd yyyy");
		Date date = df.parse(dates);
		System.out.println(df.format(date));
		
	}

}
