
public class Room {
	int roomId,  roomCapacity, roomType, roomNumber, sum, roomName, hallType; 
	String rooms;
	boolean roomWifi , roomSound, roomProjector;
	
	public Room(int roomId, int roomCapacity, int roomType, int roomNumber,int sum, int roomName, int hallType,String rooms,
			boolean roomWifi, boolean roomSound, boolean roomProjector) {
		super();
		this.roomId = roomId;
		this.roomCapacity = roomCapacity;
		this.roomType = roomType;
		this.roomNumber = roomNumber;
		this.roomName = roomName;
		this.hallType = hallType;
		this.rooms = rooms;
		this.sum = sum;
		this.roomWifi = roomWifi;
		this.roomSound = roomSound;
		this.roomProjector = roomProjector;
	}
	
void display() {
	
		System.out.println(rooms);
		
		System.out.println("Room ID : " + roomId);
		if(rooms.equals("Conference Hall") || rooms.equals("Party Hall")){
			System.out.println("Capacity : " +roomCapacity);
			System.out.println("Sound : " + roomSound);
			
			}
		if(rooms.equals("Lodge Room")){
		switch(roomType){
			case 1 :
				System.out.println("Room Type : Single");
				break;
			case 2:
				System.out.println("Room Type : Double");
				break;
			case 3:
				System.out.println("Room Type : Delux");
				break;
		}
		}
		System.out.println("wifi : " + roomWifi);
		if(rooms.equals("Conference Hall")){
		System.out.println("Projector : " + roomProjector );
		}
		
		
		System.out.println("Room Rate : " + sum);
		System.out.println();
	}
}
