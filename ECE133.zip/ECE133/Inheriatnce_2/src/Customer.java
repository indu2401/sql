
public class Customer {
	String fName, lName, contactNumber, eMail, proofType ;
	int proofId;
	
	public Customer(String fName, String lName, String contactNumber,
			String eMail, String proofType, int proofId) {
		super();
		this.fName = fName;
		this.lName = lName;
		this.contactNumber = contactNumber;
		this.eMail = eMail;
		this.proofType = proofType;
		this.proofId = proofId;
	}
	
	public void registerCustomer(){
		System.out.println("First Name : " + fName); 
		System.out.println("Last Name : " + lName);
		System.out.println("Contact Number : " + contactNumber);
		System.out.println("E-Mail : " + eMail);
		System.out.println("Proof Type : " + proofType);
		System.out.println("Proof ID : " + proofId);
	}
}
