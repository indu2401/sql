import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class Main {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		long a = 545645;
		long b = 154215;
		
		double d =  (a + b)/15;
		
		System.out.println(d);
			
				}

}
