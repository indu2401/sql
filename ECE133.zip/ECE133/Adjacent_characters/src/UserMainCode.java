
public class UserMainCode {

	public static String processString(String a){
		
		char[] charc = a.toCharArray();
		String adjString = "";
		for(int i =0 ; i< charc.length ; i++ ){
			if( i < charc.length-1 && charc[i] == charc[i+1]){
				adjString += (charc[i] + "*" );
			}
			else{
				adjString += charc[i];
			}
		}
		return adjString;
	}
}
