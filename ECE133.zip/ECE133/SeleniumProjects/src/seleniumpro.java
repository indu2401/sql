import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.support.ui.Select;



public class seleniumpro {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//--------------driver setup--------------------
		
		System.setProperty("webdriver.chrome.driver", "D:\\selenium\\chromedriver 2.35\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		
		driver.get("http://www.rediff.com");
		
	    System.out.println(driver.getTitle());
	    
	    System.out.println("driver source" + driver.getPageSource());
	    
	    System.out.println("" + driver.navigate());
	    
		driver.get("http://www.github.com");
		
		driver.findElement(By.id("user[login]")).sendKeys("Vignesh");
		
		System.out.println(driver.findElement(By.id("user[login]")).getText());
		
		
		WebElement TxtBoxContent = driver.findElement(By.id("user[login]"));
			
		
		System.out.println("Attribute " + TxtBoxContent.getAttribute("value"));
		
		driver.findElement(By.name("user[email]")).sendKeys("Vignesh@gmail.com");
		
		driver.findElement(By.xpath("//*[@id=\"user[password]\"]")).sendKeys("Vignesh@gmail.com");
		
		
		
		driver.findElement(By.xpath("/html/body/div[4]/div[1]/div/div/div[2]/div/form/button")).click();
		
		//------------------get label text-----------------------
		System.out.println("Get Text " + driver.findElement(By.name("user[login]")).getText());
		
		//------------------take screen shot------------------  
		
		try {
			File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			System.out.println(screenshot.getAbsolutePath());
			screenshot.getAbsoluteFile();
			File dest = new File("C:\\Users\\694801\\Desktop\\screen.png");
			FileUtils.copyFile(screenshot, dest);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.close();
		
		driver.get("http://toolsqa.com/automation-practice-form/");
		
		Select sel = new Select(driver.findElement(By.id("continents")));
		
		sel.selectByVisibleText("Africa");
		
		Select sels = new Select(driver.findElement(By.xpath("//*[@id=\"selenium_commands\"]")));
		
		String mul[] = {"Browser Commands","Switch Commands","Wait Commands"};
		for(String s : mul){
			
			sels.selectByVisibleText(s);
		}
		
			driver.findElement(By.id("tool-1")).click();
		
		
	}

}
