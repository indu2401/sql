import java.util.*;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		String a = "tdfje@gmail.com";
		if(a.matches("[\\w\\d\\W]+[\\W]{1}[\\w]{5}\\.com") ){
			System.out.println("Valid");
		}
		else{
			System.out.println("Invalid");
		}
		
		ArrayList<Integer> d = new ArrayList<Integer>();
		HashMap<Integer,Integer> hs = new HashMap<Integer,Integer>();
		
	}
}
