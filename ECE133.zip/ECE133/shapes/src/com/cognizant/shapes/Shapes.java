package com.cognizant.shapes;

public class Shapes {
	
	int numberOfSides;
	
	Circle c = new Circle();
	Square s = new Square();
	Triangle t = new Triangle();
	
	public void calculateShapeArea(int numberOfSides, int sides){
		if(numberOfSides == 1){
			c.calculateArea(sides);
		}
		else if(numberOfSides == 3) {
			t.calculateArea(sides);
		}
		else if(numberOfSides == 4){
			s.calculateArea(sides);
		}
		else{
			System.out.println("No Shapes Present");
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
			
	}

}
