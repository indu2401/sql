package com.cognizant.shapes;

public class Circle {

	public void calculateArea(int sides) {
		// TODO Auto-generated method stub
		System.out.println(3.14*sides*sides);
	}

}
