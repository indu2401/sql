package com.cognizant.shapes;

public class Triangle {

	public void calculateArea(int sides) {
		// TODO Auto-generated method stub
		
	}

}
