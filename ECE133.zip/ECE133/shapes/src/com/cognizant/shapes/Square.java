package com.cognizant.shapes;

public class Square {

	public void calculateArea(int sides) {
		// TODO Auto-generated method stub
		
	}

}
