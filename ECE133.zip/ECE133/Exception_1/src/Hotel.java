import java.util.ArrayList;
import java.util.Iterator;


public class Hotel {
	static String name;
	static String hotelId;
	static String address;
	public Hotel(String name, String hotelId, String address) {
		super();
		this.name = name;
		this.hotelId = hotelId;
		this.address = address;
	}
	public Hotel() {
		
	}
	static ArrayList roomList=new ArrayList();
	public void addRoom(String roomId,String roomType,String roomNumber,String roomCapacity,String roomAc,String roomWifi,String roomCabel,String roomLaundry)
	{
		
		roomList.add(roomId);
		roomList.add(roomNumber);
		if(roomType.equals("1"))
				{roomList.add("Normal");
				}
				
		else if(roomType.equals("2"))
				{roomList.add("Delux");
				}
				
		else if(roomType.equals("3"))
				{roomList.add("Super Delux");
				}
				
		roomList.add(roomCapacity);
		roomList.add(roomAc);
		roomList.add(roomWifi);
		roomList.add(roomCabel);
		roomList.add(roomLaundry);
		//for(Object s:roomList)
		//System.out.println(s);
	}
	public static void display()
	{
		System.out.println("Thank you for booking !!");
		System.out.println("The rooms details:");
		System.out.println("Hotel Name:"+name+".");
		System.out.println("Hotel ID:"+hotelId+".");
		System.out.println("Hotel Address:"+address+".");
		//System.out.println("\n");
		
		//System.out.println("\nRoom Details:\n");
		Iterator i=roomList.iterator();
		while(i.hasNext())
		{
	i.next();
		System.out.println("\nRoom Number :"+i.next());
		System.out.println("Room Type :"+i.next());
		i.next();
		System.out.println("Services Available:");
	
			Object a=i.next();
			//System.out.println(a);
			if(a.equals("true"))
			{
				System.out.println("AC");
			}
			Object b=i.next();
			//System.out.println(b);
			if(b.equals("true"))
			{
				System.out.println("Wi-Fi");
			}
			Object c=i.next();
			//System.out.println(c);
			if(c.equals("true"))
			{
				System.out.println("Cable Connection");
			}Object d=i.next();
			//System.out.println(d);
			if(d.equals("true"))
			{
				System.out.println("Laundry");
			}
			
			System.out.println();
			
		}
		}
		
		
		
	}
	
  
