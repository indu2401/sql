public class Room {
	String  roomId, roomType, roomNumber, roomCapacity, roomAc, roomWifi, roomCabel, roomLaundry;


	public Room(String roomId, String roomType, int roomNumber,
			String roomCapacity, String roomAc, String roomWifi,
			String roomCabel, String roomLaundry) {
		super();
		this.roomId = roomId;
		this.roomType = roomType;
		this.roomNumber = Integer.toString(roomNumber);
		this.roomCapacity = roomCapacity;
		this.roomAc = roomAc;
		this.roomWifi = roomWifi;
		this.roomCabel = roomCabel;
		this.roomLaundry = roomLaundry;
	}
	Hotel h=new Hotel();
public void add()
{
	h.addRoom(roomId, roomType, roomNumber, roomCapacity, roomAc, roomWifi, roomCabel, roomLaundry);
}
	public Room() {
		// TODO Auto-generated constructor stub
	}


	
}  
