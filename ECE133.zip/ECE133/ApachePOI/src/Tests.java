import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

public class Tests {
	
	@BeforeTest
	public void beforeTest(){
		System.out.println("Before Test()");
	}
	
	@AfterTest
	public void AfterTest(){
		System.out.println("After Test()");
	}
	
	@BeforeMethod
	public void BeforeMethod(){
		System.out.println("BeforeMethod()");
	}
	
	@AfterMethod
	public void AfterMethod(){
		System.out.println("AfterMethod()");
	}
	
	
	@AfterClass
	public void AfterClass(){
		System.out.println("Done After Class");
	}
	
	@Test(dependsOnMethods={"SignUp"})
	public void Login(){
		System.out.println("Done LogIn()");
	}
		
	@Test( description = "Done done ah done")
	public void SignUp(){
		System.out.println("Signup()");
	}
	
	@Test
	public void Create(){
		System.out.println("Done Creation()");
	}
	
	@BeforeClass
	public void ExecuteBefore(){
		System.out.println("Done Before Class");
	}
	
	
	
}