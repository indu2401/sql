import org.testng.annotations.Test;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


public class DataDrivenTest {
	
	WebDriver driver;
	
	@BeforeTest
	public void setup(){
		System.setProperty("webdriver.chrome.driver", "D:\\selenium\\chromedriver 2.35\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/");
		
	}
	
	
	 @DataProvider(name = "SignUp")
	 
	  public static Object[][] credentials() throws IOException, IOException {
		 
				XSSFWorkbook workbook = new XSSFWorkbook(new FileInputStream("D:\\ECE133\\ApachePOI\\excelcheck.xlsx"));
				
				XSSFSheet sheet = workbook.getSheetAt(0);
				Object a[][] = new Object[3][2];
				
				for(int i =0; i< 3; i++){
					
					XSSFRow row = sheet.getRow(i);
					
					XSSFCell cell = row.getCell(0);
					String username = cell.getStringCellValue();
					
					XSSFCell cell1 = row.getCell(1);
					String lastname = cell1.getStringCellValue();
					
						a[i][0] = username;
						a[i][1] = lastname;
					
	  }
				
				return a;
	 
	 }
	 
	 @Test(dataProvider = "SignUp")
	public void driveData(String userName, String Password){				
					 
					driver.findElement(By.id("txtUsername")).sendKeys(userName);
					driver.findElement(By.id("txtPassword")).sendKeys(Password);
					
					driver.findElement(By.id("btnLogin")).click();		
					
					for(Cookie ck : driver.manage().getCookies()){
						System.out.println("Name " + ck.getName());
						System.out.println("Domain " + ck.getDomain());
						System.out.println("Expiry " + ck.getExpiry());
						System.out.println("path  " + ck.getPath());
						System.out.println(" " + ck.getValue());
						System.out.println("Class " + ck.getClass());
						System.out.println();
					}

	}

	
	@AfterTest
	public void closeDriver(){
		driver.close();
	}

}
