import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;


public class apachepoi_excel {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "D:\\selenium\\chromedriver 2.35\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		
		
		try {
			XSSFWorkbook workbook = new XSSFWorkbook(new FileInputStream("D:\\ECE133\\ApachePOI\\excelcheck.xlsx"));
			
			XSSFSheet sheet = workbook.getSheetAt(0);
			
			for(int i =0; i< sheet.getLastRowNum(); i++){
				
				XSSFRow row = sheet.getRow(i);
				
				XSSFCell cell = row.getCell(0);
				String username = cell.getStringCellValue();
				
				XSSFCell cell1 = row.getCell(1);
				String lastname = cell1.getStringCellValue();
				
				XSSFCell cel2 = row.getCell(2);
				String birthday = cel2.getStringCellValue();
				
				XSSFCell cell3 = row.getCell(3);
				String email = cell3.getStringCellValue();
					
				XSSFCell cel4 = row.getCell(4);
				String address = cel4.getStringCellValue();
				
				XSSFCell cell5 = row.getCell(5);
				String city = cell5.getStringCellValue();
				
				
				XSSFCell cell6 = row.getCell(6);
				String state = cell6.getStringCellValue();
				
				XSSFCell cell7 = row.getCell(7);
				double pcode = cell7.getNumericCellValue();
				String postalcode = String.valueOf(pcode);
				
				XSSFCell cell18 = row.getCell(8);
				String password = cell18.getStringCellValue();

				
				driver.get("http://demo.borland.com/InsuranceWebExtJS/signup.jsf");
				
				driver.manage().timeouts().implicitlyWait(1, TimeUnit.MINUTES);
				driver.findElement(By.id("signup:fname")).sendKeys(username);
				driver.findElement(By.id("signup:lname")).sendKeys(lastname);
				
				driver.findElement(By.xpath("//*[@id=\"BirthDate\"]")).sendKeys(birthday);
				
				driver.findElement(By.id("signup:email")).sendKeys(email);
				driver.findElement(By.id("signup:street")).sendKeys(address);
				driver.findElement(By.id("signup:city")).sendKeys(city);
				driver.findElement(By.id("signup:state")).sendKeys(state);
				driver.findElement(By.id("signup:zip")).sendKeys(postalcode);
				driver.findElement(By.id("signup:password")).sendKeys(password);
				
				driver.findElement(By.id("signup:signup")).click();		
				
			}
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
	}

}
