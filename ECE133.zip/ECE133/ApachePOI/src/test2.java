import org.testng.annotations.Test;


public class test2 {
	@Test
	public void secondclasstest(){
		System.out.println("second class test");
	}
}