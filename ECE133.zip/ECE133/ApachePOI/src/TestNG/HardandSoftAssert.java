package TestNG;


import org.testng.annotations.Test;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;


public class HardandSoftAssert {
@Test
public void softAssert(){
	SoftAssert sa = new SoftAssert();
	System.out.println("SoftAssert started");
	sa.assertTrue(false);
	System.out.println("SoftAssert Executed");
}
@Test
public void hardAssert(){
	System.out.println("HardAssert started");
	Assert.assertTrue(false);
	System.out.println("HardAssert Executed");
}
}
