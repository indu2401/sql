package TestNG;

import org.testng.annotations.Test;

public class Test2 {
	  @Test
	  public void f2() {
		  System.out.println("Test2 Test()");
	  }
}
