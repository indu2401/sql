package TestNG;

import org.testng.annotations.Test;

public class Test3 {
	  @Test
	  public void f3() {
		  System.out.println("Test3 Test()");
	  }
}
