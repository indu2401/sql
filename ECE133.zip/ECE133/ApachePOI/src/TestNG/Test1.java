package TestNG;

import org.testng.annotations.Test;

public class Test1 {
	  @Test
	  public void f1() {
		  System.out.println("Test1 Test()");
	  }
}
