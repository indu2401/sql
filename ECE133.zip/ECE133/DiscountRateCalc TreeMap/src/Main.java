import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class Main {

	public TreeMap<String,Integer> discountCalc(HashMap<String, String> hm3, HashMap<String, Integer> hm4){
		
		TreeMap<String, Integer> discount= new TreeMap<String, Integer>(); 
		 Calendar cal =  Calendar.getInstance();
		 Calendar cal2 = Calendar.getInstance();
		Iterator<String> it = hm3.keySet().iterator();
		while(it.hasNext()){
			  String id = it.next();
		      String dates = hm3.get(id);
		      int amount = hm4.get(id);
		      int yeardiff = 0, disc =0;
		     // System.out.println(amount);
		      Date d;
			try {
				d = new SimpleDateFormat("dd/MM/yyyy").parse(dates);
				cal.setTime(d);
				yeardiff = Math.abs(cal.get(Calendar.YEAR) - cal2.get(Calendar.YEAR));
				/*System.out.println(cal.get(Calendar.YEAR));
				System.out.println(cal2.get(Calendar.YEAR));
				System.out.println(diff);*/
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		      
			if(yeardiff >= 5 && amount >= 20000) {
				disc = (amount * 20)/100; 
			}else if(yeardiff < 5 && amount >= 20000){
				disc = (amount * 10)/100;
			}else if(yeardiff >= 5 && amount < 20000){
				disc = (amount * 15)/100;
			}else{
				disc = (amount * 5)/100;
			}
			discount.put(id, disc);
		}
		 	 
		return discount;
	}
	public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub
		
		HashMap<String, String> hm1 = new HashMap<String,String>();
		HashMap<String, Integer> hm2 = new HashMap<String,Integer>();
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int noEmployees = Integer.parseInt(br.readLine());
		
		for(int i = 0 ; i<noEmployees ; i++){
			String id = br.readLine();
			String dateofReg = br.readLine();
			int amount =  Integer.parseInt(br.readLine());
			hm1.put(id, dateofReg);
			hm2.put(id, amount);
		}
		
		Main m = new Main();
		Iterator<String> itr = m.discountCalc(hm1,hm2).keySet().iterator();
		while(itr.hasNext()){
			String em_ids = itr.next();
			System.out.println(em_ids + " : " +m.discountCalc(hm1,hm2).get(em_ids));
		}
		//System.out.println(m.discountCalc(hm1,hm2));				
	}
}
