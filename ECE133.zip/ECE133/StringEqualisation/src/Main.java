import java.io.*;


public class Main {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String lines = br.readLine();
		String [] stringArrays = lines.split(" ");
		int size = stringArrays.length;
		char c = stringArrays[0].charAt(0);
		int lastWord = stringArrays[size-1].length();
		char d = stringArrays[size-1].charAt(lastWord-1);
		
		System.out.println(c + "\n" + d);
		
		if(c == d){
			System.out.println("Yes");
		}
	}

}
