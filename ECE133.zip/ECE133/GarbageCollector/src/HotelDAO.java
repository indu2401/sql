import java.sql.*;
public class HotelDAO {
	Connection con=ConnectionUtil.connectToMysql();
	PreparedStatement st=null;
	
	
	
	public void displayAllHotels() throws SQLException
	{
		String str="select * from Hotel";
		
	st=con.prepareStatement(str);
	
		
		ResultSet rs=st.executeQuery(str);
		
		while(rs.next())
		{
			System.out.println
			(rs.getString(1)+" "+rs.getString(2)+" "+rs.getString(3));
		}
		
		
	}
	
	public void deleteHotel(int id) throws Exception
	{
		String str=" Delete from Hotel where id=?";
		st=con.prepareStatement(str);
		st.setInt(1,id);
		st.executeUpdate();
		
		
	}
	
}
