
public class Reservation {
	
	String customer, room ,checkInDate, checkOutDate, bookingDate;

	public Reservation() {
		super();
	}

	public Reservation(String customer, String room,String bookingDate, String checkInDate,String checkOutDate ) {
		super();
		this.customer = customer;
		this.room = room;
		this.checkInDate = checkInDate;
		this.checkOutDate = checkOutDate;
		this.bookingDate = bookingDate;
	}
	 
	public void display(){
		System.out.println(customer + " - " + room + " - " + bookingDate +" - "  + checkInDate + " - " + checkOutDate);
	}
}
