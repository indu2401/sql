import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;

public class Main {
	
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static String hotel, address, type  ;
	static int id, roomId, roomNo, roomType, roomCap, allocate_room;
	static boolean ac, wifi, cable, laundry, availability ;
	
	static ArrayList roomDetails = new ArrayList();
	
	static ArrayList<String> CustomerDetails = new ArrayList<String>();
	
	
	static ArrayList<Integer> bookedRooms = new ArrayList<Integer>();

	static int CroomType, CroomCap, avail_room;
	static String CType , CAc , CWifi , CCable , CLaundry, reserv;
	static boolean Cac, Cwifi, Ccable, Claundry;
	
	public static void roomBooking() throws IOException {
		
		 System.out.println("\n\nEnter the room requirements:");
		 System.out.println("Enter the Room Type:\n1)Normal\n2)Delux\n3)Super Delux");
		 CroomType = Integer.parseInt(br.readLine());
		 
		 switch(CroomType){
		 	case 1 :
		 		CType = "Normal";
			  break;
		 	case 2 :
		 		CType = "Delux ";
		 	
				break;
		 	case 3 :
		 		CType = "Super Delux";
				break;
		 }
		 
		 System.out.println("Enter the Room Capacity:(1/2/3/4)");
		 CroomCap = Integer.parseInt(br.readLine());
		System.out.println("AC Service (true/false):");
		 Cac = Boolean.parseBoolean(br.readLine());
		 if(Cac){
			 CAc = "AC";
		 }
		System.out.println("Wi-Fi Service (true/false):");
		Cwifi = Boolean.parseBoolean(br.readLine());
		if(Cwifi){
			CWifi = "Wi-Fi";
		 }
		System.out.println("Cable Service (true/false):");
		 Ccable = Boolean.parseBoolean(br.readLine());
		 if(Ccable){
			 CCable = "Cable Connection";
		 }
		System.out.println("Laundry Service (true/false):");
		 Claundry = Boolean.parseBoolean(br.readLine());
		 if(Claundry){
			 CLaundry = "Laundry";
		 }
		 
		 
		 
		for(int z =0 ; z<roomDetails.size(); z+=6){
			
			if(roomDetails.get(z+1).equals(CType) &&  roomDetails.get(z+2).equals(CAc) && roomDetails.get(z+3).equals(CWifi) 
					&& roomDetails.get(z+4).equals(CCable) && roomDetails.get(z+5).equals(CLaundry) ){
				
				avail_room =  (int) roomDetails.get(z);
				
			//	System.out.println(avail_room);
				
				roomDetails.remove(z);
			    roomDetails.remove(z);
				roomDetails.remove(z);
				roomDetails.remove(z);
			    roomDetails.remove(z);
				roomDetails.remove(z);
				
				availability = true;
				
				// System.out.println(bookedRooms);
				
				if(!bookedRooms.contains(avail_room)){
					bookedRooms.add(avail_room);
					allocate_room = avail_room;
				}
				
			//	System.out.println(roomDetails);
			}
			
		}
		
				
	}
	
	static void details(String hotel2, int id2, String address2, ArrayList roomDetails2  ){
			
		System.out.println("The rooms Details in " + hotel2 + " :" );
		System.out.println("Hotel Name:" + hotel2 + ".");
		System.out.println("Hotel ID:" + id2 + ".");
		System.out.println("Hotel Address:" + address2 + ".");
		
		System.out.println("\n\nRoom Details:");
			
		for(int k =0; k< roomDetails2.size() ; k+=6){
		
			System.out.println("\n\nRoom Number :" + roomDetails2.get(k) );
			
			System.out.println("Room Type :" + roomDetails2.get(k+1));
			
			System.out.println("Services Available:");
		
			if(roomDetails2.get(k+2).equals("AC") ){
				System.out.println(roomDetails2.get(k+2));
			}
			if(roomDetails2.get(k+3).equals("Wi-Fi")){
				System.out.println(roomDetails2.get(k+3));
			}
			if(roomDetails2.get(k+4).equals("Cable Connection")){
				System.out.println(roomDetails2.get((k+4)));
			}
			if(roomDetails2.get(k+5).equals("Laundry")){
					
				System.out.println(roomDetails2.get((k+5)));
			}	
				
		}

	}
	
	public static void display(String firstName, String lastname, String contact, String mail, String prooftype, String proofID){
		
		System.out.println("The customer details are as follows");
		System.out.println("The customer details are:");
		
		System.out.println("First Name : "+ firstName);
		System.out.println("Last Name : "+ lastname);
		System.out.println("Contact Number : "+ contact);
		
		System.out.println("E-Mail : "+ mail);
		System.out.println("Proof Type : "+ prooftype);
		System.out.println("Proof ID : "+ proofID);
		
	}
	
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		System.out.println("\nEnter the Hotel details:\nEnter the Hotel Name:");
		 hotel = br.readLine();
		System.out.println("Enter the Hotel ID:");
		 id = Integer.parseInt(br.readLine());
		System.out.println("Enter the Hotel Address");
		 address = br.readLine();
		 int count = 0;
		String anotherRoom;
		
		do{
			
		System.out.println("Enter the Room Details:\nEnter the Room Id:");
			 roomId = Integer.parseInt(br.readLine());
		System.out.println("Enter the Room Number:");
			 roomNo = Integer.parseInt(br.readLine());
			 roomDetails.add(roomNo);	
			 
			 System.out.println("Enter the Room Type:\n1)Normal\n2)Delux\n3)Super Delux");
			 roomType = Integer.parseInt(br.readLine());
			 
			 switch(roomType){
			 	case 1 :
				  type = "Normal";
				  roomDetails.add("Normal");
				  break;
			 	case 2 :
			 		type = "Delux ";
			 		roomDetails.add("Delux");
					break;
			 	case 3 :
			 		type = "Super Delux";
			 		roomDetails.add("Super Delux");
					break;
			 }
			 		 
			System.out.println("Enter the Room Capacity:(1/2/3/4)");
			 roomCap = Integer.parseInt(br.readLine());
			System.out.println("AC Service (true/false):");
			 ac = Boolean.parseBoolean(br.readLine());
			System.out.println("Wi-Fi Service (true/false):");
			 wifi = Boolean.parseBoolean(br.readLine());
			System.out.println("Cable Service (true/false):");
			 cable = Boolean.parseBoolean(br.readLine());
			System.out.println("Laundry Service (true/false):");
			 laundry = Boolean.parseBoolean(br.readLine());
			 
			 
			 	if(ac){
				
			 		roomDetails.add("AC");
				}
			 	else {
			 		roomDetails.add("nAC");
			 	}
			 	
				if(wifi){
					
					roomDetails.add("Wi-Fi");
				}else{
					roomDetails.add("nW");
				}
				
				if(cable){
					
					roomDetails.add("Cable Connection");
				}else{
					roomDetails.add("nC");
				}
				
				if(laundry){
					
					roomDetails.add("Laundry");
				}else{
					roomDetails.add("nL");
				}
			 		 
		System.out.println("Do you want to add Another Room (yes/no):");
		 anotherRoom = br.readLine();
		}while(anotherRoom.equals("yes"));
		
		// System.out.println(roomDetails);
		System.out.println("Thank you for booking !!");
		details(hotel, id, address, roomDetails);
		
		do{
		System.out.println("Reservation\n\n\nCustomer Registration:");
		
		System.out.println("\n\nEnter the customer details:\nEnter the first name:");
		String firstName = br.readLine();
		CustomerDetails.add(firstName);
		System.out.println("Enter the last name:");
		String lastname = br.readLine();
		System.out.println("Enter the contact number:");
		String contact=br.readLine();
		System.out.println("Enter the e-mail id:");
		String mail=br.readLine();
		System.out.println("Enter the proof type:");
		String Prooftype=br.readLine();
		System.out.println("Enter the proof id:");
		String proofID=br.readLine();

		if(count > 0 ){
			System.out.println("\n");
		}
		
		display(firstName, lastname, contact , mail , Prooftype, proofID );
		roomBooking();
		 count++;
		while(!availability){
			System.out.println("No rooms of specified requirements\nPlease re-enter\n\n");
			roomBooking();
			
		}
		
		if(availability){
			System.out.println("Please take room number " + allocate_room );
			System.out.println();
			String customer_room = Integer.toString(allocate_room);
			CustomerDetails.add(customer_room);
			}
		
		System.out.println("\nEnter the Booking date");
		String bookDate = br.readLine();
		CustomerDetails.add(bookDate);
		System.out.println("Enter the check-in date");
		String startDate = br.readLine();
		CustomerDetails.add(startDate);
		System.out.println("Enter the check-out date");
		String endDate = br.readLine();
		CustomerDetails.add(endDate);
		
		System.out.println("Do you want to perform another reservation?(y/n)");
		 reserv = br.readLine();
		}while(reserv.equals("y"));
		
		System.out.println("The reservation details are as follows:\n\n");
		for(int q = 0 ; q<CustomerDetails.size() ; q+=5){
		//	System.out.println(allocate_room);
			Reservation reservation = new Reservation(CustomerDetails.get(q) , CustomerDetails.get(q+1), CustomerDetails.get(q+2), CustomerDetails.get(q+3), CustomerDetails.get(q+4) );		
			reservation.display();
		}
	}
}

