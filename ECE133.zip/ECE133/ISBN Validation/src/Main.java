import java.io.*;

public class Main {

	public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int number = Integer.parseInt(br.readLine());
		int sum =0, rem =0 , mul = 1;
		while(number>0){
			rem = number % 10;
			number = number / 10;
			sum += rem * mul;
			mul++;
		}
		System.out.println(sum);
		if(sum % 11 == 0){
			System.out.println("yes");
		}
	}

}
