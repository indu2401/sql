
public class UserMainCode {

	public static String reverseString(String a){
		
		StringBuilder reverseString = new StringBuilder(a);
		String reversed = reverseString.reverse().toString();
		return reversed;
	}
}
