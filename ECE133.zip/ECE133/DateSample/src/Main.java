import java.text.ParseException;
import java.io.*;
public class Main {

	static void book(int Charges, String Ac, String Cot, String Cable, String Wifi, String Laundry, String date1) {
		System.out.println("\nThe total charge is Rs." + Charges + ".");

		System.out.println("The services chosen are\n" + Cot + " cot " + Ac + " room");
		
		if(Cable.equals("C")){
			System.out.println("Cable connection enabled");
		}else{
			System.out.println("Cable connection disabled");
		}
		
		if(Wifi.equals("W")){
			System.out.println("Wi-Fi enabled");
		}else{
			System.out.println("Wi-Fi disabled");
		}
		
		if(Laundry.equals("L")){
			System.out.println("with laundry service");
		}else{
			System.out.println("without laundry service" );
		}
			
		System.out.println("and the Date of Booking is " + date1 );

	}
	
	public static void main(String[] args) throws IOException, ParseException {
		// TODO Auto-generated method stub
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		 
		System.out.println("Booking:");
		String ac, cot, cable, wifi, laundry, date, proceed;
		
		do{
			int charges = 0;
			System.out.println("\nPlease choose the services required.\nAC/non-AC(AC/nAC)");
			ac = br.readLine();
			if(ac.equals("AC")){
				charges += 1000;
			}
			else if(ac.equals("nAC")){
				charges += 750;
				ac = "non-AC";
			}
			
			System.out.println("Cot(Single/Double)");
			cot = br.readLine();
			if(cot.equals("Double")){
				charges += 350;
			}
			System.out.println("With cable connection/without cable connection(C/nC)");
			cable = br.readLine();
			if(cable.equals("C")){
				charges += 50;
			}
			System.out.println("Wi-Fi needed or not(W/nW)");
			wifi = br.readLine();
			if(wifi.equals("W")){
				charges += 200;
			}
			System.out.println("Laundry service needed or not(L/nL)");
			laundry = br.readLine();
			if(laundry.equals("L")){
				charges += 100;
			}
			
			System.out.println("Enter the Date of Booking");
			date = br.readLine();
			
			book(charges, ac, cot, cable, wifi, laundry, date);
			
			System.out.println("\nDo you want to proceed?(yes/no)");
			proceed = br.readLine();
			
		}while(proceed.equals("no"));
		
		System.out.println("\nThank you for booking. Your room number is 1.");
	}

}
