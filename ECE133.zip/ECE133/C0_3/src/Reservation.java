import java.util.ArrayList;
import java.util.Iterator;
public class Reservation {
	
		static String name;
		static String hotelId;
		static String address;
		public Reservation(String name, String hotelId, String address) {
			super();
			this.name = name;
			this.hotelId = hotelId;
			this.address = address;
		}
		public Reservation() {
			
		}
		static ArrayList roomList=new ArrayList();
		static ArrayList roomcheck=new ArrayList();
		static ArrayList cusList=new ArrayList();
		static ArrayList date=new ArrayList();
		static ArrayList croom=new ArrayList();
		public void adddates(String bd,String cd,String cod){
			date.add(bd);
			date.add(cd);
			date.add(cod);
			
		}
		public void displayfinal(ArrayList name)
		{int j=0;
			for(int i=0;i<name.size();i++)
			{
				
				System.out.println(name.get(i)+" - "+croom.get(i)+" - "+date.get(j++)+" - "+date.get(j++)+" - "+date.get(j++));
				//System.out.println(croom);
			}
		}
		public void addcus(String roomType,String roomCapacity,String roomAc,String roomWifi,String roomCabel,String roomLaundry)
				{
			cusList.add(roomType);
			cusList.add(roomCapacity);
			cusList.add(roomAc);
			cusList.add(roomWifi);
			cusList.add(roomCabel);
			cusList.add(roomLaundry);
				
			/*for(Object g:cusList)
			{
				System.out.println(g);
			}*/
				} 
		
		public int check()
			{
				Iterator i=roomcheck.iterator();
				//Iterator j=cusList.iterator();
				
				int count=0;int re=0;
				while(i.hasNext()){
					count=0;
					
					String no= (String) i.next();//System.out.println("roomno"+no);
					String ty=(String) i.next();//System.out.print(ty);System.out.println(cusList.get(0));
					String cap=(String) i.next();//System.out.print(cap);System.out.println(cusList.get(1));
					String ac=(String) i.next();//System.out.print(ac);System.out.println(cusList.get(2));
					String w=(String) i.next();//System.out.print(w);System.out.println(cusList.get(3));
					String cab=(String) i.next();//System.out.print(cab);System.out.println(cusList.get(4));
					String l=(String) i.next();//System.out.print(l);System.out.println(cusList.get(5));
					
						if(ty.equals(cusList.get(0)))count++;
						//if(cap.equals(cusList.get(1)))count++;
						if(ac.equals(cusList.get(2)))count++;
						if(w.equals(cusList.get(3)))count++;
						if(cab.equals(cusList.get(4)))count++;
						if(l.equals(cusList.get(5)))count++;
						//System.out.println("count"+count);
						if(count==5&&(!croom.contains(no)))
						{
							System.out.println("Please take room number "+no);re=3;
							System.out.println();
							croom.add(no);
							break;
										}	
				}
				
				//System.out.println(count);
				
				if(re!=3)
				{
					System.out.println("No rooms of specified requirements\nPlease re-enter\n\n");re=1;
					
				}cusList.clear();
				return re;
				}
				
			
			
			public void addCheck(String roomType,String roomNumber,String roomCapacity,String roomAc,String roomWifi,String roomCabel,String roomLaundry)
			{
				
				
				roomcheck.add(roomNumber);
				roomcheck.add(roomType);
				roomcheck.add(roomCapacity);
				roomcheck.add(roomAc);
				roomcheck.add(roomWifi);
				roomcheck.add(roomCabel);
				roomcheck.add(roomLaundry);
				
			}
			public void addRoom(String roomType,String roomNumber,String roomAc,String roomWifi,String roomCabel,String roomLaundry)
			{
				
				
				roomList.add(roomNumber);
				if(roomType.equals("1"))
						{roomList.add("Normal");
						}
						
				else if(roomType.equals("2"))
						{roomList.add("Delux");
						}
						
				else if(roomType.equals("3"))
						{roomList.add("Super Delux");
						}
				
				roomList.add(roomAc);
				roomList.add(roomWifi);
				roomList.add(roomCabel);
				roomList.add(roomLaundry);
				
			}
			public static void display()
			{
				System.out.println("Thank you for booking !!");
				System.out.println("The rooms Details in "+name+" :");
				System.out.println("Hotel Name:"+name+".");
				System.out.println("Hotel ID:"+hotelId+".");
				System.out.println("Hotel Address:"+address+".");
			
				
				System.out.println("\n\nRoom Details:");
				Iterator i=roomList.iterator();
				
				while(i.hasNext())
				{
			
				System.out.println("\n\nRoom Number :"+i.next());
				System.out.println("Room Type :"+i.next());
			
				System.out.println("Services Available:");
			
					Object a=i.next();
					//System.out.println(a);
					if(a.equals("true"))
					{
						System.out.println("AC");
					}
					Object b=i.next();
					//System.out.println(b);
					if(b.equals("true"))
					{
						System.out.println("Wi-Fi");
					}
					Object c=i.next();
					//System.out.println(c);
					if(c.equals("true"))
					{
						System.out.println("Cable Connection");
					}Object d=i.next();
					//System.out.println(d);
					if(d.equals("true"))
					{
						System.out.println("Laundry");
					}
					
					
					
				}
				}
				
				
				
			}
			 

