import java.io.*;
import java.util.*;


public class Main {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br =  new BufferedReader(new InputStreamReader(System.in));
		int n = Integer.parseInt(br.readLine());
		String [] arr = new String[n];
		int count = 0;
		HashSet<String> set1 = new HashSet<String>();
		
		for(int i =0 ;i<n ; i++){
			arr[i] = br.readLine();
			set1.add(arr[i]);
		}
		HashSet<String> set2 = (HashSet) set1.clone();
		
		Iterator itr = set1.iterator();
		while(itr.hasNext()){
			String first_String = (String) itr.next();
			
			Iterator itr2 = set2.iterator();
			
			while(itr2.hasNext()){
				String prefix = (String) itr2.next();
				
				if(prefix.length() > first_String.length() && prefix.substring(0, first_String.length()).equals(first_String) ){
					count++;
				}
			}
		}
		
		System.out.println(count);
	}

}
