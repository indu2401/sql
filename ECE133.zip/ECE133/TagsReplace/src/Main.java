import java.io.*;


public class Main {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String[] texts = new String[4];
		
		String ss = "abcdef";
		String s2 = "zadcfe";
		
		for(int i  = 0; i < ss.length() ; i+=2){
			
			if(ss.contains("z") ||  ss.contains("a") ){
				System.out.println(ss.indexOf("a"));
				System.out.println(s2.charAt(ss.indexOf("a")));
			}
		if( (int)  ss.charAt(i) + 1 ==  (int)  s2.charAt(i) ){
			System.out.println(ss.charAt(i)  + "valid");
			
		}
		}
		
		for(int i  = 1; i < ss.length() ; i+=2){
			if( (int)  ss.charAt(i)  ==  (int)  s2.charAt(i) -1 ){
				System.out.println(ss.charAt(i)  + "valid");
				
			}
		}
		
		/*for(int i = 0 ; i<4;i++){
		 texts[i] = br.readLine();
		}
		for(int i = 0 ; i<4 ; i++){
		//	System.out.println(texts[i].indexOf("<"));
		//	System.out.println(texts[i].indexOf(">"));
	//		System.out.println(texts[i].indexOf("</"));
		String replacedString = texts[i].substring(texts[i].indexOf("<"), texts[i].indexOf("<")+1).replaceAll("<", "").replaceAll("/", "*").replaceAll(">", "%")
				+ texts[i].substring(texts[i].indexOf(">")+1, texts[i].indexOf("</")) ;
		System.out.println(replacedString);
		}*/
	}
}
