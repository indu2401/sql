import java.util.ArrayList;
import java.util.Arrays;
import java.io.*;

public class Main {
		
public static void main(String[] args) throws IOException {
	
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	int n=Integer.parseInt(br.readLine());
	int count = 0;
	ArrayList<String> list1 = new ArrayList<String>();
	  for(int i=0;i<n;i++)
	     {
	    	 list1.add(br.readLine());
	     }
	     int m=Integer.parseInt(br.readLine());
	      ArrayList<String> list2 = new ArrayList<String>();
	      ArrayList<String> list3 = new ArrayList<String>();
	      for(int i=0;i<m;i++)
	      {
	     	 list2.add(br.readLine());
	      }
	    //  System.out.println(list2);
	for(int i=0;i<list1.size();i++)
	  {
		if( (!list2.contains(list1.get(i))) ) {
			list3.add(list1.get(i));
			
		}
	  }
		for(int j=0;j<list2.size();j++)
		  {
			if( !list1.contains(list2.get(j))) {
				
				list3.add(list2.get(j));
			}
		 }

	 System.out.println(list3.toString());
	
}
} 
