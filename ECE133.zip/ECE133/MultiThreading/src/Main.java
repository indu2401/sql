import java.io.*;


public class Main extends Thread {

	public Main(){
		System.out.println("Room Service Initiated for the room");
	}
	
	public void run(){
		System.out.println("Room checking is going on");
		
	}
	
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Do you want to check out yes/no"); 
		String checkStatus = br.readLine();
		
		if("yes".equals(checkStatus)){
		System.out.println("Enter the check-in date");
		String checkIn = br.readLine();
		System.out.println("Enter the check-out date");
		System.out.println("Enter the Room Type:\nNormal\nDeluxe\nSuper Deluxe ");
		String roomType = br.readLine();
		
		Main main = new Main();
		Thread thread = new Thread();
		thread = main;
		thread.start();
		
		}
		
		else{
			System.out.println("Thank you for continuing your stay");
		}
		
		
		
	}

}


