package Login;

import java.io.*;
import java.util.*;
import java.text.*;

public class login {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String birth = br.readLine();
		//String sDate1="31/12/1998";
		DateFormat date1=new SimpleDateFormat("dd/MM/yyyy");
		System.out.println(birth+"\t"+date1);
	}

}



