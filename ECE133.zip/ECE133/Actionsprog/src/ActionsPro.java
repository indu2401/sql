import java.util.List;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;



public class ActionsPro {



	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		/*System.setProperty("webdriver.ie.driver", "D:\\Selenium\\IEDriverServer.exe");
	    
		WebDriver driver = new InternetExplorerDriver();*/
		
		System.setProperty("webdriver.ie.driver", "D:\\Selenium\\IEDriverServer.exe");
	    
		WebDriver driver = new InternetExplorerDriver();
		
		
	//	driver.get("http://toolsqa.wpengine.com/automation-practice-switch-windows/");		
		
		//----------- Windows Handler -------------------
		
/*		driver.findElement(By.xpath("//*[@id=\"button1\"]")).click();
		
		Set<String> handlers = driver.getWindowHandles();
		
		
		for(String handler : handlers){
			System.out.println(handler);
			
			driver.switchTo().window(handler);
			driver.close();
		}
		*/
		
		
	//	driver.findElement(By.linkText("Droppable")).click();
	
	//-----------------find elements-------------
			
		
/*		List<WebElement> elements =  driver.findElements(By.xpath("//*[@type='text' or @type='password']"));
		
	//	List<WebElement> elements =  driver.findElements(By.xpath(".//*[@class='dijitReset dijitInputInner']"));
				
		
		for(WebElement webs : elements){
			//webs.sendKeys("HELLO");
			System.out.println(webs);
			webs.sendKeys("Hello");
		}
		*/
		
		
		//--------------Actions Drag and Drop--------------
		
/*		driver.switchTo().frame(0);
		
		Actions act = new Actions(driver);
		
		act.dragAndDrop(driver.findElement(By.id("draggable")), driver.findElement(By.id("droppable"))).build().perform();
		
		act.clickAndHold(driver.findElement(By.id("draggable"))).build().perform();
		act.moveToElement(driver.findElement(By.id("droppable"))).build().perform();
		act.release(driver.findElement(By.id("draggable"))).build().perform();*/
		
/*		 try{
	           driver.get("http://www.hexbytes.com");
	          //find first child node of div element with attribute=container
	          
	          List<WebElement> elements = driver.findElements(By.xpath("//div[@id='container']/*[1]"));
	          System.out.println("Test1 number of elements: " + elements.size()); 

	          for(WebElement ele : elements){
	              System.out.println(ele.getTagName());
	              System.out.println(ele.getAttribute("id"));
	              System.out.println("");
	              System.out.println("");
	          }
	   }
	   finally {
	       driver.close();
	   }*/
		
		//--------- Alert ---------------------
		
		driver.get("http://demo.guru99.com/test/delete_customer.php");			
		
	      	
        driver.findElement(By.name("cusid")).sendKeys("53920");					
        driver.findElement(By.name("submit")).submit();			
        		
		
		// Switching to Alert     
   
        Alert alert = driver.switchTo().alert();		
        		
        // Capturing alert message.    
        String alertMessage= driver.switchTo().alert().getText();		
        		
        // Displaying alert message		
        System.out.println(alertMessage);	
	
        // Accepting alert	
        	
        alert.accept();	
   
        driver.switchTo().alert().dismiss();
        
        
		
	}

}
