
public class UserMainCode {

	public static String processString(String a){
		
		char[] charc = a.toCharArray();
		
		// adjString stores non 'x'
		String adjString = "";
		// lowerLetters stores non 'x'
		String lowerLetters = "";
		for(int i =0 ; i< charc.length ; i++ ){
			if( i < charc.length-1 && charc[i] == 'x'){
				
				 lowerLetters = lowerLetters + 'x';
			}
			else{
				adjString += charc[i];
			}
		}
		return (adjString + lowerLetters);
	}
}
