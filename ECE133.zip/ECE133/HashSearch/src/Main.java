import java.util.*;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		int n = s.nextInt();
		
		Details d = new Details(101,"jack", "jack@email");
		
		ArrayList<Details> l = new ArrayList<Details>();
		l.add(d);
		
		for(Object  obj : l){
			Details details = (Details) obj;
			if(details.getId() == n){
				System.out.println(details.getName() + "\n" + details.getEmail());
			}
		}
	}

}
