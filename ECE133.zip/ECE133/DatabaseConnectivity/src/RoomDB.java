import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class RoomDB {
	Connection con=connectionUtil.connectToMysql();
	PreparedStatement st=null;	
	
	public void addRoom() throws SQLException
	{
		 
		String str="insert into room(hotelId,roomID,roomType,roomNumber,roomCapacity,roomAc,roomWifi,roomCabel,roomLaundry)"
				+ " values(?,?,?,?,?,?,?,?,?)";
		st=con.prepareStatement(str);
		
		// hotelID | roomID | roomType | roomNumber | roomCapacity | roomAc | roomWifi | roomCabel | roomLaundry |
		
		st.setInt(1,Main.hotelId);
		st.setInt(2, Main.roomId);
		st.setString(3, Main.type);
		st.setInt(4,Main.roomNumber);
		st.setInt(5, Main.roomCapacity);
		st.setInt(6, Main.AC);
		st.setInt(7,Main.Wi_Fi);
		st.setInt(8, Main.Cable);
		st.setInt(9, Main.Laundry);
		st.executeUpdate();
		
	//	System.out.println("Succesfully inserted Rooms");
	}
	
	public void displayAllRoom() throws SQLException
	{
		String str="select * from room";
		
		st=con.prepareStatement(str);
		
		ResultSet rs=st.executeQuery(str);
		
		while(rs.next())
		{
			System.out.println("\nRoom Details:\n");
			System.out.println("Room Number :" + rs.getInt(4));
			System.out.println("Room Type :" + rs.getString(3));
			System.out.println("Services Available:");
			
			if(rs.getInt(6) == 1){
				System.out.println("AC");
			}
			
			if(rs.getInt(7) == 1){
				System.out.println("Wi-Fi");
			}
			
			if(rs.getInt(8) == 1){
				System.out.println("Cable Connection");
			}
			
			if(rs.getInt(9) == 1){
				System.out.println("Laundry");
			}
		}
				
	}
}
