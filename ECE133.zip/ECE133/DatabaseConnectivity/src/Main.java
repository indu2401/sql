import java.io.*;
import java.sql.SQLException;


public class Main {
	
	 static String roomType, roomAc, roomWifi, roomCabel, roomLaundry,yn,yesno, cusname,
	 cuslname, cusmail, cusprooftype, cusproof, name, address, type , bd, cd, cod;
	 
	 static int hotelId, roomId, roomNumber, roomCapacity, AC = 0, Wi_Fi = 0, Cable = 0, Laundry = 0, cusID = 0, cuscontact, ID = 0;;
	
	public static void main(String args[]) throws IOException, SQLException{
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		HotelDB h = new HotelDB();
		RoomDB room = new RoomDB();
				
		System.out.println("\nEnter the Hotel details:");
		System.out.println("Enter the Hotel Name:");
		 name=br.readLine();
		System.out.println("Enter the Hotel ID:");
		 hotelId=Integer.parseInt(br.readLine());
		System.out.println("Enter the Hotel Address");
		 address=br.readLine();
		do{
		System.out.println("Enter the Room Details:");
		System.out.println("Enter the Room Id:");
		roomId=Integer.parseInt(br.readLine());
		System.out.println("Enter the Room Number:");
		roomNumber=Integer.parseInt(br.readLine());
		System.out.println("Enter the Room Type:");
		System.out.println("1)Normal");
		System.out.println("2)Delux");
		System.out.println("3)Super Delux");
		roomType=br.readLine();
		
		switch(roomType){
			case "1": 
				type = "Normal";
				break;
			case "2": 
				type = "Delux";
				break;
			case "3": 
				type = "Super Delux";
				break;
		}
		
		
		
		
		System.out.println("Enter the Room Capacity:(1/2/3/4)");
		roomCapacity=Integer.parseInt(br.readLine());
		System.out.println("AC Service (true/false):");
		roomAc=br.readLine();
		if("true".equals(roomAc)){
			AC =1;
		}
		
		System.out.println("Wi-Fi Service (true/false):");
		roomWifi=br.readLine();
		if("true".equals(roomWifi)){
			Wi_Fi =1;
		}
		
		System.out.println("Cable Service (true/false):");
		roomCabel=br.readLine();
		if("true".equals(roomCabel)){
			Cable =1;
		}
		
		System.out.println("Laundry Service (true/false):");
		roomLaundry=br.readLine();
		if("true".equals(roomLaundry)){
			Laundry =1;
		}
		
		System.out.println("Do you want to add Another Room (yes/no):");
		yn=br.readLine();
		
		
		h.addHotel();
		
		room.addRoom();
		
	}while(yn.equals("yes"));
		
		connectionUtil.connectToMysql();	
		
		h.displayAllHotels();
		room.displayAllRoom();
		
		
		do{
			
			cusID++;
			
			System.out.print("Reservation\n");
			System.out.println("\nCustomer Registration:\n\n");
			System.out.println("Enter the customer details:\nEnter the first name:");
			 cusname=br.readLine();
			System.out.println("Enter the last name:");
			 cuslname=br.readLine();
			System.out.println("Enter the contact number:");
			 cuscontact=Integer.parseInt(br.readLine());
			System.out.println("Enter the e-mail id:");
			 cusmail=br.readLine();
			System.out.println("Enter the proof type:");
			 cusprooftype=br.readLine();
			System.out.println("Enter the proof id:");
			 cusproof=br.readLine();
			
			CustomerDB customer = new CustomerDB();
			customer.addCustomer();
			customer.displayCustomers();
			
			do{
				ID++;
				int Cac = 0,Cwifi = 0, Ccable =0, Claundry = 0;
			System.out.println("\n\nEnter the room requirements:");
			System.out.println("Enter the Room Type:");
			System.out.println("1)Normal");
			System.out.println("2)Delux");
			System.out.println("3)Super Delux");
			String cusroomType=br.readLine();
			System.out.println("Enter the Room Capacity:(1/2/3/4)");
			String cusroomCapacity=br.readLine();
			System.out.println("AC Service (true/false):");
			String cusroomAc=br.readLine();
			if("true".equals(cusroomAc)){
				Cac = 1;
			}
			System.out.println("Wi-Fi Service (true/false):");
			String cusroomWifi=br.readLine();
			if("true".equals(cusroomWifi)){
				Cwifi =1;
			}
			System.out.println("Cable Service (true/false):");
			String cusroomCabel=br.readLine();
			if("true".equals(cusroomCabel)){
				Ccable = 1;
			}
			System.out.println("Laundry Service (true/false):");
			String cusroomLaundry=br.readLine();
			if("true".equals(cusroomLaundry)){
				Claundry = 1;
			}
			
			Reservation reserv = new Reservation(cusroomType, Cac, Cwifi, Ccable, Claundry);
			
			}while(Reservation.availability);
			
			System.out.println("\nEnter the Booking date");
			 bd=br.readLine();
			System.out.println("Enter the check-in date");
			 cd=br.readLine();
			System.out.println("Enter the check-out date");
			 cod=br.readLine();
			// r.adddates(bd, cd, cod);
			
			System.out.println("Do you want to perform another reservation?(y/n)");
			yesno=br.readLine();
			
			ReservationDB reserv = new ReservationDB();
			reserv.addReservation();
				
		}while(yesno.equals("y"));
		
		
	}
}
