import java.io.*;


public class Main {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int n = Integer.parseInt(br.readLine());
		
			UserMainCode code = new UserMainCode();
			if(code.isPerfect(n)){
				System.out.println("Perfect number");
		}
			else{
				System.out.println("Not a perfect number");
			}
	}
}