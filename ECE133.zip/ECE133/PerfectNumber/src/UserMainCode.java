
public class UserMainCode {
	
	public static boolean isPerfect(int a){
		
		boolean flag = false;
		int sum = 0;
		for(int i =1 ; i<a ; i++){
			if(a % i == 0){
				sum += i;
			}	
		}
		
		if(sum == a){
			flag = true;
		}
		return flag;
	}
}

