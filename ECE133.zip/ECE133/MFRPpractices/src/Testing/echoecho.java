package Testing;


import javax.swing.JFrame;
import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class echoecho {
	
	WebDriver driver;
	
	public void webDriverConnection(){
		
		System.setProperty("webdriver.chrome.driver", "D:\\selenium\\chromedriver 2.35\\chromedriver.exe");
		driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		
		driver.get("http://www.echoecho.com/htmlforms09.htm");
	}
	
	public void checkBox(){
		
		WebElement milk = driver.findElement(By.xpath("//input[contains(@value,'Milk')]"));
		
		WebElement butter = driver.findElement(By.xpath("//input[contains(@value,'Butter')]"));
		
		JOptionPane.showMessageDialog(new JFrame(),"Click Butter", "Alert", JOptionPane.OK_OPTION);
		
		if(!milk.isSelected()){
			milk.click();
			}
		
		if(!butter.isSelected()){
		butter.click();
	
		}
		
	}
	

	public void driverClose(){
		driver.close();
	}
	
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		echoecho echo = new echoecho();
		
		echo.webDriverConnection();
		echo.checkBox();
		echo.driverClose();
		
	}
	
	
}
