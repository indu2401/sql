
import java.util.*;



public class methods {
	
	public static int display(int n){
		if(n>100){
			return n;
		}
		else{
			System.out.println(n);
			return  display(n+1);
		}
	}

	public static void main(String[] args)  {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		display(1);
	//	String a = s.nextLine();
/*		ArrayList<Integer> b = new ArrayList<Integer>();
		b.add(10);
		b.add(20);
		b.add(30);
		b.add(40);
		b.add(50);
		ArrayList<Integer> c = new ArrayList<Integer>();
		ArrayList<Integer> d = new ArrayList<Integer>();
		
		Integer [] arr = new Integer[d.size()];
		c.add(10);
		c.add(20);
		c.add(70);
		c.add(60);
		c.add(80);
		
		for(int i = 0;i<b.size() ; i++){
			if(!c.contains(b.get(i))){
				d.add(b.get(i));
				d.add(c.get(i));
			}
		}
		
		arr = d.toArray(arr);
		Arrays.sort(arr);
		for(int i = 0; i<arr.length;i++){
		System.out.println(arr[i]);
		}*/
	}
}
