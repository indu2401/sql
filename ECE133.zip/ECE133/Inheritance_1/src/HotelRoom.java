
public class HotelRoom extends Room {
	int roomType;
	boolean wifi;

	public HotelRoom(int roomid, int hours, int rate, int roomType, boolean wifi) {
		super(roomid, hours, rate);
		this.roomType = roomType;
		this.wifi = wifi;
	}

	void display() {
		System.out.println("Lodge Room");
		System.out.println("Room ID : " + roomid);
		System.out.print("Room Type : ");
		if (roomType == 1)
			System.out.println("Single");
		else if (roomType == 2)
			System.out.println("Double");
		else
			System.out.println("Delux");
		System.out.println("wifi : " + wifi);
		System.out.println("Room Rate : " + rate);
		System.out.println();
	}
}
