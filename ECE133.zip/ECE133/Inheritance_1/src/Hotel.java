import java.util.*;
import java.util.Iterator;

public class Hotel {
	String name, hotelId, address ;

	List<Room> roomList = new ArrayList<Room>();
	
public void addRoom (Room room){
	roomList.add(room);
}

void display() {
	int cnt = roomList.size();
	System.out.println("Hotel Room Details : ");
	for (int i = 0; i < cnt; i++) {
		Room r = roomList.get(i);
		r.display();
	}
}

}