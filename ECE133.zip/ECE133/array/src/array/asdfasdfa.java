package array;
import java.util.*;
public class asdfasdfa {
	public static void main(String args[])
	{
	Scanner sc=new Scanner(System.in);
	int n=sc.nextInt();
	int count = 0;
	String a[]=new String[n];
	for(int i=0;i<n;i++)
	{
		a[i]=sc.next();
	}
	for(int i=0;i<n;i++)
	{
		String prefix = a[i];
		if( a[i+1].startsWith(prefix)){
			count++;
		}
	}
	/*System.out.println(9999%9);
	boolean b1 = Character.isAlphabetic('a');
    boolean b2 = Character.isAlphabetic('1');
    System.out.println("b1"+b1+" "+b2);*/
    GregorianCalendar g = new GregorianCalendar();
    System.out.println(g);
    Calendar c = Calendar.getInstance();
    System.out.println(c);
	}
	
}

