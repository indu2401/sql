import java.util.Arrays;
import java.util.Scanner;


public class Highest_Freq {
	
	String name, country, skill;
    
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getSkill() {
		return skill;
	}

	public void setSkill(String skill) {
		this.skill = skill;
	}

	// Returns maximum repeating element in arr[0..n-1].
	// The array elements are in range from 0 to k-1
	   static int frequency(int a[],
			    int n, int x)
			    {
			        int count = 0;
			        for (int i=0; i < n; i++)
			        if (a[i] == x) 
			            count++;
			        return count;
			    }
	
	   static void print2largest(int a[], int arr_size)
	    {
	        int i,h1,h2,h3;
	   
	        /* There should be atleast two elements */
	        if (arr_size < 3)
	        {
	            System.out.print(" Invalid Input ");
	            return;
	        }
	       
	         h1 = h2 = h3 = 0;
	        for( i=0;i<arr_size;i++)
	        {
	            if(a[i] > h1)
	            {
	            	 h2 = h1;
	                 h3 = h2; 
	                 System.out.println("Array value"+ a[i] + "\n" + i );
	            	 h1 = a[i];
	                 
	            }
	            else if (a[i] > h2)
	            {
	            	 h3 = h2;
	                 h2 = a[i];
	                 
	            }
	            else if  (a[i] > h3)
	            {
	                h3 = a[i];
	            }
	        }
	        System.out.println(h1 + "\n" + h2 + "\n" + h3 );
	        
	        
	    }
	
	public static void main(String args[]){
			Scanner s = new Scanner(System.in);
			int voters = s.nextInt();
			int n = s.nextInt();
			int y=0, value =0, max=0;
			int a[] = new int[n];
			int c[] = new int[n];
			for(int i =0; i<n; i++){
				a[i] = s.nextInt();
			}
	     //   int x = 1;
	        for(int x = 1; x<=voters; x++){	         
	        c[x-1] =  frequency(a, n, x);
	        System.out.println(c[x-1]);
	        }
	        for(int i =0; i<voters;i++){
	        	for(int j =0; j<voters;j++){
		        	if(c[i]>c[j]){
		        		
		        	}
		        }
	        }
	        print2largest(c, voters);
	        
	}
	
}


