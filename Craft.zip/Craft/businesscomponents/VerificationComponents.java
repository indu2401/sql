package businesscomponents;

import supportlibraries.ReusableLibrary;
import supportlibraries.ScriptHelper;


/**
 * Verification Components class
 * @author Cognizant
 */
public class VerificationComponents extends ReusableLibrary
{
	/**
	 * Constructor to initialize the component library
	 * @param scriptHelper The {@link ScriptHelper} object passed from the {@link DriverScript}
	 */
	public VerificationComponents(ScriptHelper scriptHelper)
	{
		super(scriptHelper);
	}
	
}