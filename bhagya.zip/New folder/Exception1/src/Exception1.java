public class Exception1 extends Throwable{
public String getMessage(){
	return ("Invalid Room Number\nRe-enter Room Number");
}
}  