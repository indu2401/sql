import java.util.Comparator;


public class CompareSorting implements Comparator<Room>{
	
	    public int compare(Room emp1,Room emp2) {
	        return emp1.roomNumber.compareTo(emp2.roomNumber);
	    }
}
