public class UserMainCode {
public static int findNextPalindrome(int num){
	int pal;
	int res=0;
	int rem;
	int j;
for(int i=num+1;;i++){
	pal=0;
	 j=i;
	while(j>0){		
		rem=j%10;
		pal=rem+(pal*10);
		j=j/10;
	}	
	if(pal==i){
		res=pal;
		break;
	}
	}
return res;	
	
}
}