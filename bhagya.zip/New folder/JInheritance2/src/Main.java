import java.util.Scanner;

public class Main {

	private static String fName;
	private static String lName;
	private static String contactNumber;
	private static String eMail;
	private static String proofType;
	private static int proofId;
	private static int roomCapacity;
	private static boolean roomAc;
	private static boolean roomWifi;
	private static boolean roomCabel;
	private static boolean roomLaundry;
	private static int roomNumber;
	private static int rate;
	private static int hours;

	public static void main(String[] args) {
		String Hname, Haddress, w, amenities, roomType1;
		int roomid = 0, roomName, roomType = 0, hallType, capacity;
		boolean wifi, soundSystem, projector;
		Room obj2 = new Room(roomid, hours, rate, roomType, roomNumber, roomCapacity, roomAc, roomWifi, roomCabel, roomLaundry);
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Hotel Details");
		System.out.println("Enter the Hotel name");
		Hname = sc.nextLine();
		System.out.println("Enter the Hotel Location");
		Haddress = sc.nextLine();
		Hotel obj1 = new Hotel();
		do {
			roomid++;
			int sum = 0;
			System.out.println("Enter the Room name");
			System.out.println("1.Hotel Room");
			System.out.println("2.Hall");
			roomName = sc.nextInt();
			if (roomName == 1) {
				int hours = 24;
				System.out.println("Enter the Room Type");
				System.out.println("1.Single");
				System.out.println("2.Double");
				System.out.println("3.Delux");
				roomType = sc.nextInt();
				if (roomType == 1)
					sum = sum + ((1000 * hours) / 24);
				else if (roomType == 2)
					sum = sum + ((1500 * hours) / 24);
				else
					sum = sum + ((2000 * hours) / 24);
				System.out.println("Need WiFi ??(true/false)");
				wifi = sc.nextBoolean();
				obj2 = new HotelRoom(roomid, hours, sum, roomType, wifi);
				obj1.addRoom(obj2);

			} else {
				int hours = 1;
				System.out.println("Enter the Hall Type");
				System.out.println("1.Party Hall");
				System.out.println("2.Conference Hall");
				hallType = sc.nextInt();
				if (hallType == 1) {
					System.out.println("Enter the Capacity");
					capacity = sc.nextInt();
					System.out.println("Need soundSystem ??(true/false)");
					soundSystem = sc.nextBoolean();
					sc.nextLine();
					System.out.println("Enter the Party Name");
					roomType1 = sc.nextLine();
					System.out.println("Enter the Amenities Cost");
					amenities = sc.nextLine();
					sum = sum + 200 * hours;
					obj2 = new PartyHall(roomid, hours, sum, capacity, soundSystem, roomType1, amenities);
					obj1.addRoom(obj2);
				}

				else {
					sum = sum + 250 * hours;
					System.out.println("Enter the Capacity");
					capacity = sc.nextInt();
					System.out.println("Need soundSystem ??(true/false)");
					soundSystem = sc.nextBoolean();
					System.out.println("Need WiFi ??(true/false)");
					wifi = sc.nextBoolean();
					System.out.println("Need Projector ??(true/false)");
					projector = sc.nextBoolean();
					obj2 = new ConferenceHall(roomid, hours, sum, capacity, soundSystem, wifi, projector);
					obj1.addRoom(obj2);
				}
			}
			System.out.println("Do you want to add another room?(y/n)");
			w = sc.next();
		} while (w.equals("y"));
		obj1.display();
		System.out.println("Customer Registration:");
        System.out.println("Enter the customer details:");
        System.out.println("Enter the first name:");
        fName=sc.next();
        //sc.next();
        System.out.println("Enter the last name:");
        lName=sc.next();
        System.out.println("Enter the contact number:");
        contactNumber=sc.next();	 
        System.out.println("Enter the e-mail id:");
        eMail=sc.next();
        System.out.println("Enter the proof type:");
       proofType=sc.next();	
        System.out.println("Enter the proof id: ");
        proofId=sc.nextInt();	 
		Customer c=new Customer();
		
		c.registerCustomer();
		
			  
	}
}
