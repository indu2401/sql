import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Hotel {
	String name, address;
	int hotelId;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getHotelId() {
		return hotelId;
	}

	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}

	public List<Room> getRoomList() {
		return roomList;
	}

	public void setRoomList(List<Room> roomList) {
		this.roomList = roomList;
	}

	List<Room> roomList = new ArrayList<>();

	void addRoom(Room obj2) {
		roomList.add(obj2);
	}

	void display() {
		int cnt = roomList.size();
		System.out.println("Hotel Room Details : ");
		for (int i = 0; i < cnt; i++) {
			Room r = roomList.get(i);
			r.display();
		}
	}
	void availability()
	{
		System.out.println("AVAILABILITY CHECK");
		for (int j = 0; j < roomLisr.size(); j++) {
			Room r = roomDetails.get(j);
			if( ( r.roomName == CroomName && (r.hallType == ChallType || (r.roomType == CroomType ) )  )){
				if(r.roomWifi == Cwifi || r.roomProjector == Cprojector || r.roomCapacity == Ccapacity || r.roomSound == CsoundSystem ){
					
					System.out.println("Room Number :" + r.roomNumber);
					CroomRate = r.sum;
					break;
				}
			}
	}
}
