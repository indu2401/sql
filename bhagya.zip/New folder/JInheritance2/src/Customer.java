
public class Customer {
	String fName, lName, contactNumber, eMail;
	int proofType, proofId ;
	public void registerCustomer()
	{
		System.out.println("Thank you for registering.");
		System.out.println("The customer details are as follows");
		System.out.println("First Name :"+fName);
		System.out.println("Last Name :"+lName);
		System.out.println("Contact Number :"+contactNumber);
		System.out.println("E-Mail :"+eMail);
		System.out.println("Proof Type : "+proofType);
		System.out.println("Proof ID : "+proofId);
	} 



}
