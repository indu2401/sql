public class Room {
	int roomid, hours;
	int rate;
	int roomType, roomNumber, roomCapacity;
	boolean roomAc, roomWifi, roomCabel, roomLaundry; 

	

	
	public Room(int roomid, int hours, int rate, int roomType, int roomNumber,
			int roomCapacity, boolean roomAc, boolean roomWifi,
			boolean roomCabel, boolean roomLaundry) {
		super();
		this.roomid = roomid;
		this.hours = hours;
		this.rate = rate;
		this.roomType = roomType;
		this.roomNumber = roomNumber;
		this.roomCapacity = roomCapacity;
		this.roomAc = roomAc;
		this.roomWifi = roomWifi;
		this.roomCabel = roomCabel;
		this.roomLaundry = roomLaundry;
	}




	void display() {
	}
}