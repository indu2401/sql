import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;


public class Safari {
	public static void main(String[] args) {
		{

			System.setProperty("webdriver.chrome.driver","D:\\Salenium\\chromedriver 2.35\\chromedriver.exe ");
			WebDriver driver=new ChromeDriver();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			driver.get("http://www.echoecho.com/htmlforms09.htm");
			WebElement ele1=driver.findElement(By.xpath("//input[@value='Milk']"));
			ele1.click();
			WebElement ele2=driver.findElement(By.xpath("/html/body/div[2]/table[9]/tbody/tr/td[4]/table/tbody/tr/td/div/span/form/table[3]/tbody/tr/td/table/tbody/tr/td/input[2]"));
			if(!(ele2.isSelected()))
			{
				ele2.click();
			}
		} 
	}

}
