
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.swing.text.html.StyleSheet.ListPainter;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;




public class SelectMultiple {
	public static void main(String[] args) throws IOException{

		System.setProperty("webdriver.chrome.driver","D:\\Salenium\\chromedriver 2.35\\chromedriver.exe ");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("https:////jqueryui.com/");
		
		List<WebElement> ele=driver.findElements(By.tagName("a"));
		
		for(int i=0;i<ele.size();i++)
		{
			System.out.println(ele.get(i).getText());
		}

	}

}
