import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.hwpf.model.FileInformationBlock;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;


public class ExtractFromXl {
	public static void main(String[] args) throws IOException {
		FileInputStream file=new FileInputStream("C:\\Users\\694819\\Desktop\\bhgya.xlsx");
		XSSFWorkbook workbook=new XSSFWorkbook(file);
		XSSFSheet sheet=workbook.getSheetAt(0);
		int rowcount=sheet.getLastRowNum();
		System.out.println(rowcount);
		for(int i=0;i<=rowcount;i++)
		{
			XSSFRow row=sheet.getRow(i);
			XSSFCell cell=row.getCell(0);
			String username=cell.getStringCellValue();
			XSSFCell cell1=row.getCell(1);
			String password=cell1.getStringCellValue();
			XSSFCell cell2=row.getCell(0);
			String FirstName=cell2.getStringCellValue();
			XSSFCell cell3=row.getCell(0);
			String LastName=cell3.getStringCellValue(); 


			System.setProperty("webdriver.chrome.driver","D:\\Salenium\\chromedriver 2.35\\chromedriver.exe ");

			WebDriver driver=new ChromeDriver();


			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

			/*driver.get("http://demo.borland.com/InsuranceWebExtJS/index.jsf");

			WebElement ele=driver.findElement(By.id("quick-link:jump-menu"));
			Select sele=new Select(ele);
			 */
			//sele.selectByIndex(1);
			//sele.selectByVisibleText("Australia");

			driver.findElement(By.id("login-form:email")).sendKeys(username);
			driver.findElement(By.id("login-form:password")).sendKeys(password);
			driver.findElement(By.id("login-form:login")).click();
			driver.findElement(By.xpath("//*[@id='login-form:signup']")).click();
			driver.findElement(By.xpath("//*[@id='signup:fname']")).sendKeys(FirstName);
			driver.findElement(By.xpath("//*[@id='signup:lname']")).sendKeys(LastName); 

		}
	}


}
