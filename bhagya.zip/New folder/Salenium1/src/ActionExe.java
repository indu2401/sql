import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;


public class ActionExe {
	public static void main(String[] args) {
		
			System.setProperty("webdriver.chrome.driver","D:\\Salenium\\chromedriver 2.35\\chromedriver.exe ");
			WebDriver driver=new ChromeDriver();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			driver.get("https:////jqueryui.com/");
			driver.findElement(By.linkText("Droppable")).click();
			driver.switchTo().frame(0);
			WebElement ele1=driver.findElement(By.id("droppable"));
			WebElement ele2=driver.findElement(By.id("draggable"));
			Actions act=new Actions(driver);
			act.dragAndDrop(ele2, ele1).build().perform();
		
	
	}

}
