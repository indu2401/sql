import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class Exe3 {
public static void main(String[] args) throws Exception
{
	System.setProperty("webdriver.chrome.driver","D:\\Salenium\\chromedriver 2.35\\chromedriver.exe ");
	WebDriver driver=new ChromeDriver();
	driver.get("http://www.rediff.com");
	String s=driver.getTitle();
	System.out.println(s);
	driver.findElement(By.linkText("Create a Rediffmail account")).click();
	driver.navigate().back();
} 
}