import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class Exe4 {
public static void main(String[] args) throws Exception
{
	System.setProperty("webdriver.chrome.driver","D:<\\Selenium\\Selenium softwares\\Chrome Drivers\\chromedriver 2.35\\chromedriver.exe>");
	WebDriver driver=new ChromeDriver();
	driver.get("http://github.com");
	driver.findElement(By.name("user[login]")).sendKeys("Rajeshwari");
	driver.findElement(By.xpath("//*[@id=\"user[password]\"]")).sendKeys("1234");
}
} 