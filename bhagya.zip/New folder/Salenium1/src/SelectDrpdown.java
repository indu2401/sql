import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;


public class SelectDrpdown {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","D:\\Salenium\\chromedriver 2.35\\chromedriver.exe ");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://toolsqa.com/automation-practice-form/");
		
		//single select
		/*WebElement ele=driver.findElement(By.id("continents"));
		Select sele=new Select(ele);
		
		sele.selectByIndex(4);
		sele.selectByVisibleText("Australia");
		*[@id="continents"]*/
		
		
		//multiple select
	/*	WebElement ele=driver.findElement(By.id("selenium_commands"));
		Select sele=new Select(ele);
		sele.selectByIndex(0);
		sele.selectByIndex(1);
		sele.selectByIndex(2);
		sele.selectByIndex(4);
		*/
		
		//Deselect
		WebElement ele=driver.findElement(By.id("selenium_commands"));
		Select sele=new Select(ele);
		sele.selectByIndex(0);
		sele.selectByIndex(1);
		sele.selectByIndex(2);
		sele.selectByIndex(4);
		sele.deselectByIndex(0);
		//sele.deselectByIndex(1);
		sele.deselectByIndex(4);
		
		
		
	}
}
