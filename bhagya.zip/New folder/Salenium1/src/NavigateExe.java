import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class NavigateExe {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","D:\\Salenium\\chromedriver 2.35\\chromedriver.exe ");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, null);
		driver.get("https://jqueryui.com");
		driver.findElement(By.linkText("Download"));
		driver.findElement(By.linkText("Development"));
		//driver.navigate().back();
		driver.navigate().forward();
		//driver.navigate().refresh();
		
		
		
	}

}
