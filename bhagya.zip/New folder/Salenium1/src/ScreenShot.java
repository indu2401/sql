
import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;




public class ScreenShot {
	public static void main(String[] args) throws IOException{

		System.setProperty("webdriver.chrome.driver","D:\\Salenium\\chromedriver 2.35\\chromedriver.exe ");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("https:////jqueryui.com/");
		driver.findElement(By.linkText("Droppable")).click();
		driver.switchTo().frame(0);
		WebElement ele1=driver.findElement(By.id("droppable"));
		WebElement ele2=driver.findElement(By.id("draggable"));
		

		Actions act=new Actions(driver);
		act.dragAndDrop(ele2, ele1).build().perform();
		
		File src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(src, new File("C:\\workspace\\694819\\Salenium1\\SaleniumPac\\error.png"));
			

	}

}
