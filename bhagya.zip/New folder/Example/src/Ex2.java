import java.util.Scanner;


public class Ex2 {
	 public static void main(String[] args) {
		 Scanner s=new Scanner(System.in);
		 
		System.out.println("Enter the name: ");
		String name=s.next();
		System.out.println("Enter the password: ");
		String pwd=s.next();
		boolean c=login(name,pwd);
		if(c==true)
		{
			System.out.println("Valid user");
		}
		else
		{
			System.out.println("Invalid user");
		}
	 }
		
		static boolean login(String name,String pwd)
		{
		String username[]={"xxx","yyy","zzz"};
		String password[]={"xxx","yyy","zzz"};
		boolean b=false;
		for(int i=0;i<username.length;i++)
		{
		if(name.equals(username[i])&& pwd.equals(password[i]))
		{
			b=true;
			break;
		}
		else
			b=false;
		}
		return b;
		}

}