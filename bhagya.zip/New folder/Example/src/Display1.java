import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class Display1 {
	 public static void main(String[] args) throws IOException
	    {
	       BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
	       
	       for(int i=1;i<=2;i++)
	       {
	        System.out.println("Team "+i+"\nTeam name:");
	        String a=br.readLine();
	        System.out.println("Score:");
	        int b=Integer.parseInt(br.readLine());
	        System.out.println("Overs played:");
	        int c=Integer.parseInt(br.readLine());
	        System.out.println("Match Deatails:\nTeam "+i+":\nName:"+a+"Score:"+b+"\nOvers played:"+c);
	       }
	        //System.out.println("Team 2:\nTeam name:");
	        //String d=br.readLine();
	       
	        //System.out.println("Score:");
	        //int e=Integer.parseInt(br.readLine());
	        /*System.out.println("Overs played");
	        int f=Integer.parseInt(br.readLine());*/
	       // System.out.println("Match Deatails:\nTeam 1:\nName:"+a+"Score:"+b+"\nOvers played:"+c+"\nTeam 2:\nName:"+d+"\nScore:"+e+"\nOvers played:"+f);
	        
	        
	        
	    }
}
