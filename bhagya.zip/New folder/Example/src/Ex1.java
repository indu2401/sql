import java.util.Scanner;


public class Ex1 {
	 public static void main(String[] args) {
		 Scanner s=new Scanner(System.in);
		//System.out.println("Enter the name: ");
		String username="admin";
		String password="admin";
		//String username=s.next();
		System.out.println("Enter user name:"+username);
		System.out.println("Enter the password: "+password);
		//String password=s.next();
		
		/*if(username==password)
		{
			System.out.println("Valid user");
		}*/
		if(username.equals(password))
		{
			System.out.println("Valid user");
		}
		/*if(username.equals("admin") && password.equals("admin"))
		{
			System.out.println("Valid user");
		}*/
		else
		{
			System.out.println("Invalid user");
		}
	}

}
