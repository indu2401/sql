import java.util.Scanner;


public class Match1 {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the match date");
		String date=s.nextLine();
		System.out.println("Enter the team one");
		String teamOne=s.nextLine();
		System.out.println("Enter the team two");
		String teamTwo=s.nextLine();
		System.out.println("Enter the venue");
		String venue=s.nextLine();
		
		Match m=new Match(date,teamOne,teamTwo,venue);
		m.setDate(date);
		m.setTeamOne(teamOne);
		m.setTeamTwo(teamTwo);
		m.setVenue(venue);
		System.out.println("Match Details");
		System.out.println(m.toString());
		
	}

}
