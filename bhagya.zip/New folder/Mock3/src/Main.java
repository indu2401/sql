import java.util.Scanner;


public class Main {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		String a=s.next();
		UserMainCode u=new UserMainCode();
		System.out.println(u.reverseString(a));
		
	}

}
