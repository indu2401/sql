
public class UserMainCode {
	String reverseString(String a)
	{
		String rev=" ";
		char[] c=a.toCharArray();
		for(int i=0;i<c.length;i++)
		{
			rev=c[i]+rev;
		}
		return rev;
	}

}
