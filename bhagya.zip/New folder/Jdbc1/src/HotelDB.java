import java.sql.*; 

import java.sql.*;


public class HotelDB {
	Connection con=ConnectionUtil.connectToMysql();
	PreparedStatement st=null;	

	public void addHotel() throws SQLException
	{

		String str="insert into Hotel(hotelId,name,address)"
				+ " values(?,?,?)";
		st=con.prepareStatement(str);

		st.setInt(1,Main.hotelId);
		st.setString(2, Main.name);
		st.setString(3, Main.address);
		st.executeUpdate();

		//	System.out.println("Succesfully inserted Rooms");
	}

	public void displayAllHotels() throws SQLException
	{
		String str="select * from hotel";

		st=con.prepareStatement(str);

		ResultSet rs=st.executeQuery(str);

		while(rs.next())
		{
			System.out.println("Thank you for booking !!The rooms Details in " + rs.getString(2) + " :");
			System.out.println
			("Hotel Name:" + rs.getString(2) + "\n"  +"Hotel ID:" +  rs.getInt(1) +"." + "\n" + "Hotel Address:"+ rs.getString(3));
		}

	}

}   