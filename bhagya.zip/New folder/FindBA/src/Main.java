import java.util.*;

public class Main {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		int i=0;
		int a1 = sc.nextInt();
		ArrayList<Integer> a = new ArrayList<Integer>();
		for(i=0;i<a1;i++) {
			a.add(sc.nextInt());
		}
		a1 = sc.nextInt();
		ArrayList<Integer> b = new ArrayList<Integer>();
		for(i=0;i<a1;i++) {
			b.add(sc.nextInt());
		}	
		ArrayList<Integer> c = 	UserMainCode.findDifference(a,b);
		for(int x : c) {
			System.out.println(x);
		}
	}
}
