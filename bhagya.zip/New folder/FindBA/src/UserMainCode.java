import java.util.ArrayList;

public class UserMainCode {
	public static ArrayList<Integer> findDifference(ArrayList<Integer> a, ArrayList<Integer> b) {
		ArrayList<Integer> arr=new ArrayList<Integer>();
		int count=0;
		for(int i=0;i<b.size();i++)
		{
			for(int j=0;j<a.size();j++){
				if(b.get(i)==a.get(j))
				{
					count++;
				}
			}
			if(count==0)
			{
				arr.add(b.get(i));
			}
			count=0;
		}
		return arr;
	}
}
