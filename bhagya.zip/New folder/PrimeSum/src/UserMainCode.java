
public class UserMainCode {
	int findPrimeSum(int a)
	{
		int sum=0;
		int count=0;
		for(int i=2;i<a/2;i++)
		{
			if(a%i==0)
			{
				count++;
			}
		}
		for(int i=0;i<a;i++)
		{
		if(count==0)
		{
			sum=sum+i;
		}
		}
		return sum;
	}

}
