import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;


public class TestEx {
	//@Test(priority=1)
	//@Test(enabled=true)
	//@Test(description="Login")
	
	@BeforeClass
	@Test
	public void display()
	{
		System.out.println("HI");
	}
	//@Test(priority=3)
	//@Test(enabled=false)
	//@Test(description="function")
	
	@Test(dependsOnMethods={"display"})
	public void display1()
	{
		System.out.println("Hello");
	}
	//@Test(priority=2)
	//@Test(enabled=true)
	//@Test(description="register")
	
	@BeforeMethod
	public void display2()
	{
		System.out.println("Hello day");
	}
	
	@AfterMethod
	public void display3()
	{
		System.out.println("Hello world");
	}
	
	@AfterClass
	public void display4()
	{
		System.out.println("completed");
	}
}
