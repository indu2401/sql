
public class Ex1 {
	

}
