package Test.Test;

import org.testng.annotations.Test;

public class NewTestOne {
	public class NewTestTwo {
		@Test
		public void func()
		{
			System.out.println("function");
		}
	}

}
