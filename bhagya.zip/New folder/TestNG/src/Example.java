import org.testng.annotations.AfterClass;


public class Example {
	@AfterClass
	public void function()
	{
		System.out.println("function well");
	}

}
