import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


public class DataDrivenEx {
	WebDriver driver;
	
	@Test
	public void setup()
	{
		System.setProperty("webdriver.chrome.driver","D:\\Salenium\\chromedriver 2.35\\chromedriver.exe ");
		driver=new ChromeDriver();
		WebDriver driver=new ChromeDriver();
		driver.get("http://demo.borland.com/InsuranceWebExtJS/index.jsf");
	}
	
	@DataProvider(name="signup")
	public static Object[][] credentials() throws IOException{
		XSSFWorkbook workbook=new XSSFWorkbook(new FileInputStream("C:\\Users\\694819\\Desktop\\bhgya.xlsx"));
		XSSFSheet sheet=workbook.getSheetAt(0);
		
		Object a[][]=new Object[3][2];
		
		for(int i=0;i<3;i++)
		{
			XSSFRow row=sheet.getRow(i);
			XSSFCell cell=row.getCell(0);
			
			String username=cell.getStringCellValue();
			XSSFCell cell1=row.getCell(0);
			
			String password=cell1.getStringCellValue();
			XSSFCell cell2=row.getCell(1);
			
		
			
			a[i][0]=username;
			a[i][1]=password;



			/*driver.get("http://demo.borland.com/InsuranceWebExtJS/index.jsf");

			WebElement ele=driver.findElement(By.id("quick-link:jump-menu"));
			Select sele=new Select(ele);
			 */
			//sele.selectByIndex(1);
			//sele.selectByVisibleText("Australia");

			
		}
		return a;
	}
	@Test(dataProvider="signup")
	public void result(String username,String password)
	{
		driver.findElement(By.id("login-form:email")).sendKeys(username);
		driver.findElement(By.id("login-form:password")).sendKeys(password);
		driver.findElement(By.id("login-form:login")).click();
		driver.findElement(By.xpath("//*[@id='login-form:signup']")).click();
	}
	@AfterTest
	public void closeM()
	{
		driver.close();
	}
		
}
