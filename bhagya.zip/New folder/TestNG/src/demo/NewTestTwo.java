package demo;

import org.testng.annotations.Test;

public class NewTestTwo {
	@Test
	public void disp()
	{
		System.out.println("hello");
	}

}
