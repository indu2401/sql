package demo;

import org.testng.annotations.Test;

public class NewTestThree {
	public class NewTestTwo {
		@Test
		public void work()
		{
			System.out.println("work");
		}
	}

}
