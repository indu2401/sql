public class UserMainCode {
    static Boolean validatePassword(String un, String pw) {
    	boolean flag=false;
    	String res=un.substring(un.length()-3,un.length());
    	StringBuffer b=new StringBuffer();
    	String res1=res+res+res;
    	if(pw.equals(res1))
    	{
    		flag=true;
    	}
    	else
    	{
    		flag=false;
    	}
    	return flag;
    }
}
