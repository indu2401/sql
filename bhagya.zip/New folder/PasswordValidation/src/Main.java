import java.io.IOException;
import java.util.Scanner;


public class Main {
    public static void main(String args[])throws IOException
    {
    	Scanner s=new Scanner(System.in);
    	String a=s.next();
    	String b=s.next();
    	UserMainCode u=new UserMainCode();
    	if(u.validatePassword(a, b))
    	{
    		System.out.println("Valid");
    	}
    	else
    	{
    		System.out.println("Invalid");
    	}

    }
    
}
