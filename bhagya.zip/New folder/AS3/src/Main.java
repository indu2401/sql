import java.util.Scanner;
import java.io.*;
public class Main {

	public static void main(String[] args)throws Exception {
		// TODO Auto-generated method stub
		String rrrnum="";
		int space=0;
		Boolean avail=false;
		String resagain="";
		Hotel h=new Hotel();
		String aroom="yes";
		BufferedReader sc=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the Hotel details:");
		System.out.println("Enter the Hotel Name:");
		String h_name=sc.readLine();
		System.out.println("Enter the Hotel ID:");
		String h_id=sc.readLine();
		System.out.println("Enter the Hotel Address");
		String h_add=sc.readLine();
		do
		{
			System.out.println("Enter the Room Details:");
			System.out.println("Enter the Room Id:");
			String roomid=sc.readLine();
			System.out.println("Enter the Room Number:");
			String roomno=sc.readLine();
			System.out.println("Enter the Room Type:\n1)Normal\n2)Delux\n3)Super Delux");
			String roomtype=sc.readLine();
			if(roomtype.equals("1"))
			{
				roomtype="Normal";
			}
			else if(roomtype.equals("2"))
			{
				roomtype="Delux";
			}
			else if(roomtype.equals("3"))
			{
				roomtype="Super Delux";
			}
			System.out.println("Enter the Room Capacity:(1/2/3/4)");
			String roomcapa=sc.readLine();
			System.out.println("AC Service (true/false):");
			String roomac=sc.readLine();
			System.out.println("Wi-Fi Service (true/false):");
			String roomwifi=sc.readLine();
			System.out.println("Cable Service (true/false):");
			String roomcab=sc.readLine();
			System.out.println("Laundry Service (true/false):");
			String roomlan=sc.readLine();
			System.out.println("Do you want to add Another Room (yes/no):");
			aroom=sc.readLine();
			Room r=new Room(roomid,roomtype,roomno,roomcapa,roomac,roomwifi,roomcab,roomlan);
			h.addRoom(r); 
		}
		while(aroom.equals("yes"));
		if(aroom.equals("no"));
		{
			System.out.println("Thank you for booking !!");
			System.out.println("The rooms Details in "+h_name +" :");
			System.out.println("Hotel Name:"+h_name+".");
			System.out.println("Hotel ID:"+h_id+".");
			System.out.println("Hotel Address:"+h_add+".");
			 System.out.println();
		        System.out.println();
			System.out.println("Room Details:");
			h.display();
			do
			{
			System.out.println("Reservation\n\n");	
			System.out.println("Customer Registration:\n\n");
			System.out.println("Enter the customer details:");
			System.out.println("Enter the first name:");
			String fname=sc.readLine();
			System.out.println("Enter the last name:");
			String lname=sc.readLine();
			System.out.println("Enter the contact number:");
			String cnum=sc.readLine();
			System.out.println("Enter the e-mail id:");
			String email=sc.readLine();
			System.out.println("Enter the proof type:");
			String ptype=sc.readLine();
			System.out.println("Enter the proof id:");
			String pid=sc.readLine();
			if(space !=0)
			{
				System.out.println();System.out.println();
			}
			System.out.println("The customer details are as follows");
			System.out.println("The customer details are:");
			System.out.println("First Name : "+fname);
			System.out.println("Last Name : "+lname);
			System.out.println("Contact Number : "+cnum);
			System.out.println("E-Mail : "+email);
			System.out.println("Proof Type : "+ptype);
			System.out.println("Proof ID : "+pid);
			System.out.println();System.out.println(); 
			do
			{
			System.out.println("Enter the room requirements:");
			System.out.println("Enter the Room Type:\n1)Normal\n2)Delux\n3)Super Delux");
			String rrtype=sc.readLine();
			if(rrtype.equals("1"))
			{
				rrtype="Normal";
			}
			else if(rrtype.equals("2"))
			{
				rrtype="Delux";
			}
			else if(rrtype.equals("3"))
			{
				rrtype="Super Delux";
			}
			System.out.println("Enter the Room Capacity:(1/2/3/4)");
			String rrcap=sc.readLine();
			System.out.println("AC Service (true/false):");
			String rrac=sc.readLine();
			System.out.println("Wi-Fi Service (true/false):");
			String rrwifi=sc.readLine();
			System.out.println("Cable Service (true/false):");
			String rrcab=sc.readLine();
			System.out.println("Laundry Service (true/false):");
			String rrlan=sc.readLine();
			avail=h.Availability(rrtype, rrcap, rrac, rrwifi, rrcab,rrlan);
			if(avail==true)
			{
				System.out.println("Please take room number "+h.reserved);System.out.println();
				rrrnum=h.reserved;
			}
			else
			{
				System.out.println("No rooms of specified requirements\nPlease re-enter\n\n\n\n");
			}
			} 
			while(avail==false);
			System.out.println();
			System.out.println("Enter the Booking date");
			String bdate=sc.readLine();
			System.out.println("Enter the check-in date"); 
			String cindate=sc.readLine(); 
			System.out.println("Enter the check-out date");
			String coutdate=sc.readLine();
			Reservation rres=new Reservation(fname,rrrnum,cindate,coutdate,bdate);
			h.addreservation(rres);
			System.out.println("Do you want to perform another reservation?(y/n)");
			space=space+1;
			resagain=sc.readLine();
			}
			while(resagain.equals("y")); 
			if(resagain.equals("n"));
			{
				System.out.println("The reservation details are as follows:\n\n");
				h.displayres();
			}
		}
	}
}