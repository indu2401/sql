
public class UserMainCode {
	static boolean isTrendy(int a)
	{
		int  m=a;
		boolean resp=false;
		if(a>=100&&a<=999)
		{
			int x=m/10;
			int y=x%10;
			if(y%3==0)
			{
				resp=true;
			}
			else
			{
				resp=false;
			}
			
		}
		return resp;
	}
}
