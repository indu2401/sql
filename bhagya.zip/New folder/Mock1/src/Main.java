import java.util.Scanner;


public class Main {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int a=s.nextInt();
		UserMainCode u=new UserMainCode();
		if(u.isTrendy(a)==true)
		{
		System.out.println("Trendy Number");
		}
		else
		{
			System.out.println("Not a Trendy Number");
		}
	}

}
