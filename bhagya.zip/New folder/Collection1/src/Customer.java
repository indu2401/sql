import java.io.IOException;
import java.util.Scanner;
import java.util.TreeSet;


public class Customer 
{
	String fn;
	String ln;
	String cn;
	String em;
	String pt;
	String pi;
	public Customer(String fn, String ln, String cn, String em, String pt,
			String pi) {
		super();
		this.fn = fn;
		this.ln = ln;
		this.cn = cn;
		this.em = em;
		this.pt = pt;
		this.pi = pi;
	}
	
	public String toString(){
		return ("The customer details are:\nFirst Name : "+fn+"\nLast Name : "+ln+"\nContact Number : "+cn+"\nE-Mail : "+em+"\nProof Type : "+pt+"\nProof ID : "+pi);
	}

	}    