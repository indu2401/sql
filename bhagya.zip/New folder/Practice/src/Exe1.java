import java.util.Scanner;


public class Exe1 {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		String a=s.next();
		StringBuilder b=new StringBuilder(a);
		String r=b.reverse().toString();
		System.out.println(r);
	}

}
