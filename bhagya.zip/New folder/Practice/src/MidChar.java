import java.util.Scanner;


public class MidChar {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		String a=s.next();
		StringBuffer b=new StringBuffer(a);
		int d=a.length()/2;
		String  c=b.substring(d-1,d+1);
		System.out.println(c);
		
	}

}
