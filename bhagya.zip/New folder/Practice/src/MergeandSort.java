import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Scanner;


public class MergeandSort {
	static ArrayList<Integer> sortMerge(ArrayList<Integer> l1,ArrayList<Integer> l2)
	{
		l1.addAll(l2);
		Collections.sort(l1);
		ArrayList<Integer> l3=new ArrayList<Integer>();
		l3.add(l1.get(2));
		l3.add(l1.get(6));
		l3.add(l1.get(8));
		return l3;
		
	}
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		ArrayList<Integer> l1=new ArrayList<Integer>();
		ArrayList<Integer> l2=new ArrayList<Integer>();
		for(int i=0;i<5;i++)
		{
			l1.add(s.nextInt());
		}
		for(int i=0;i<5;i++)
		{
			l2.add(s.nextInt());
		}
		ArrayList<Integer> l3=sortMerge(l1,l2);
		Iterator f=l3.iterator();
		while(f.hasNext())
		{
		System.out.println(f.next());
		}
	}

}
