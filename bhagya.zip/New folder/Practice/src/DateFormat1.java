//checking for date of birth format
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;


public class DateFormat1 {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		String a=s.next(); 
		
		SimpleDateFormat sd=new SimpleDateFormat("dd/MM/yyyy");
		sd.setLenient(false);
		try {
			Date d1=sd.parse(a);
			System.out.println("Valid");
			
		} catch (ParseException e) {
			System.out.println("Invalid");
		}
		
		
	}

}
