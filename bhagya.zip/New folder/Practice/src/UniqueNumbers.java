import java.util.Scanner;


public class UniqueNumbers {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int a=s.nextInt();
		int b=s.nextInt();
		int c=s.nextInt();
		
		int count=0;
		if(a==b||a==c||b==c)
		{
			count++;;
			
		}
		if(a!=c&&a!=b)
		{
			count++;
		}
		if(b!=c&&b!=a)
		{
			count++;
		}
		if(c!=a&&c!=b)
		{
			count++;
		}
	
		
		System.out.println(count);
		
	}
}

		