import java.util.Scanner;


public class PrimeNumbers1 {
	static boolean isPrime(int a)
	{
		boolean flag=true;
		for(int i=2;i<=a/2;i++)
		{
		if(a%i==0)
		{
			flag=false;
		}
		}
		return flag;
	}
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int n=s.nextInt();
		for(int i=1;i<=n;i++)
		{
			if(isPrime(i))
			{
			System.out.println(i);
			}
		}
		
	}

}
