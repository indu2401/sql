import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;


public class DateMatch {
	void calender(String a,String b)
	{
		SimpleDateFormat format=new SimpleDateFormat("dd/MM/yyy");
		SimpleDateFormat format1=new SimpleDateFormat("EEEE");
		Date d1=null;
		Date d2=null;
		String f1;
		try {
			d1 = format.parse(a);
			 f1 = format1.format(d1);
			d2=format.parse(b);
			long diff=Math.abs((d2.getTime()-d1.getTime())/(1000*24*60*60))/30;
			System.out.println(diff);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		
	}
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		DateMatch m=new DateMatch();
		String a=s.next();
		String b=s.next();
		m.calender(a,b);
	}

}
