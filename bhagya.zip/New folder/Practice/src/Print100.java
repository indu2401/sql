
public class Print100 {
	public static void main(String[] args) {
		
		int arr[]=new int[101];
		try {
			printNum(arr,1);
		} catch (ArrayIndexOutOfBoundsException e) {
			
		}
	}
	static void printNum(int arr[],int in)
	{
		arr[in]=in;
		System.out.println(arr[in]);
		printNum(arr,in+1);
	}

}
