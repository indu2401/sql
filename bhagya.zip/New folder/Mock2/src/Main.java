import java.util.Scanner;


public class Main {
	public static void main(String[] args) {
		Scanner s= new Scanner(System.in);
		int a=s.nextInt();
		UserMainCode u=new UserMainCode();
		if(u.isTopper(a))
		{
			System.out.println("yes");
		}
		else
		{
			System.out.println("no");
		}
	}

}
