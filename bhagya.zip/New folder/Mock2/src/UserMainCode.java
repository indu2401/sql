
public class UserMainCode {
	boolean isTopper(int a)
	{
		int n=a;
		int r=0;
		int res=0,res1=0;
		boolean result=false;
		while(n>0)
		{
			r=n%10;
			if(r%2==0)
			{
				res=res+r;
			}
			else if(r%2==1)
			{
				res1=res1+r;
			}
			n=n/10;
			
		}
		if(res==res1)
		{
			result=true;
		}
		return result;
	}

}
