import java.util.Scanner;


public class Main {
	static String name;
	static String address;
	static String contactNumber;
	static String email;
	static String proofType;
	static String proofId;
	public static void register(String name,String address, String contactNumber,
			String email,String proofType,String proofId)
	{
		System.out.println("\nWelcome "+name+".\nHere are your details");
		System.out.println("Address: "+address);
		System.out.println("Contact Number: "+contactNumber);
		System.out.println("E-Mail ID: "+email);
		System.out.println("Proof type: "+proofType);
		System.out.println("Proof id: "+proofId);
	}
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Registration\n");
		System.out.println("Enter your name");
		name=s.nextLine();
		System.out.println("Enter your address");
		address=s.nextLine();
		System.out.println("Contact Number");
		contactNumber=s.nextLine();
		System.out.println("E-Mail ID");
		email=s.nextLine();
		System.out.println("Enter proof type");
		proofType=s.nextLine();
		System.out.println("Enter proof id");
		proofId=s.nextLine();
		Main m=new Main();
		m.register(name,address,contactNumber,email,proofType,proofId);
		System.out.println("\nThank you for registering. Your id is 1..");


	}

}
