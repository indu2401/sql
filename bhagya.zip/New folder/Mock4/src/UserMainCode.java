
public class UserMainCode {
/*	String processString(String a)
	{
		String x=" ";
		char[] c=a.toCharArray();
		for(int i=0;i<c.length;i++)
		{
			
			x=x+c[i];
			if(c[i]=='x')
			{
				c[c.length]=c[i];
			}
		}
		String r=(String)c;
	}*/
	public String processString(String inputString) {
	    int xCounter = 0;
	    int writeIndex = 0;
	    final int size = inputString.length();
	    char[] resultArray = new char[size];
	    for (int readIndex = 0; readIndex < size; readIndex++) {
	        char c = inputString.charAt(readIndex);
	        if(c == 'x'){
	            xCounter++;
	            resultArray[size - xCounter] = c;
	        } else {
	            resultArray[writeIndex++] = c;
	        }
	    }
	    return new String(resultArray);
	}

}
