 

public class UserMainCode {
	static boolean isPalindrome(String a)
	{
		
		boolean resp=false;
		char c[]=a.toCharArray();
		String r="";
		for(int i=0;i<c.length;i++)
		{
			r=c[i]+r;
			//System.out.println(r);
		
		
		
		}
		if(a.equals(r))
		{
			resp=true;
			
		}
		return resp;
	}

}
