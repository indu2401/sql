
import java.util.Scanner;


public class Main {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		String a=s.next();
		UserMainCode u=new UserMainCode();
		boolean res=u.isPalindrome(a);
		System.out.println(res);
		if(u.isPalindrome(a))
		{
			System.out.println(a+" is Palindrome");
			
		}
		else
		{
			System.out.println(a+" is not a Palindrome");
		}
	}

}
