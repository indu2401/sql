public class UserMainCode {
	static void isPalindrome(String s)
	{
		 StringBuffer str1 = new StringBuffer(s);
         StringBuffer str2 = new StringBuffer(s);
         str1.reverse();
        
		if(String.valueOf(str1).compareTo(String.valueOf(str2))==0)

           System.out.println(str2+" is a palindrome");

        else
            System.out.println(str2+" is not a palindrome");
		
		
	}
} 
/*
public class UserMainCode {
	static boolean isPalindrome(String a)
	{
		
		boolean resp=false;
		char c[]=a.toCharArray();
		String r=" ";
		for(int i=0;i<c.length;i++)
		{
			r=c[i]+r;
			//System.out.println(r);
		}
		
		if(a.equals(r))
		{
			resp=true;
		}
		return resp;
	}

}*/
