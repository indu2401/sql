import java.util.Scanner;

public class Main {

	
	

	        public static void main(String[] args)
	        {
	            String s;
				StringBuffer str2;
				StringBuffer str1;
	            Scanner scan =new Scanner (System.in);
	           
	            s = scan.nextLine();
	            UserMainCode u=new UserMainCode();
	            u.isPalindrome(s);
	            
	            
	        }
	   
	} 
/*import java.util.Scanner;


public class Main {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		String a=s.next();
		UserMainCode u=new UserMainCode();
		boolean res=u.isPalindrome(a);
		System.out.println(res);
		if(u.isPalindrome(a))
		{
			System.out.println(a+" is Palindrome");
		}
		else
		{
			System.out.println(a+" is not a Palindrome");
		}
	}

}
*/