import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;


public class DateFormat {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		String a=s.next();
		SimpleDateFormat f=new SimpleDateFormat("dd/MM/yyyy");
		f.setLenient(false);
		try {
			Date d=f.parse(a);
			System.out.println("Valid");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			System.out.println("Not valid");
		}
		
	}

}
