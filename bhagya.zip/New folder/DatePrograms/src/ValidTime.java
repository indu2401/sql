import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;


public class ValidTime {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		String a=s.nextLine();
		if(a.matches("[0-9]{2}:[0-9]{2}\\s(am|pm|AM|PM)"))
		{
		SimpleDateFormat f=new SimpleDateFormat("h:mm");
		f.setLenient(false);
		try {
			Date d=f.parse(a);
			System.out.println("Valid");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			System.out.println("Not valid");
		}
		}
		else
			{
			System.out.println("Not valid123");
			}
			
		
	}

}
