import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;


public class DiffBtwnMonths {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		String a=s.nextLine();
		String a1=s.nextLine();
		long diff;
		SimpleDateFormat f=new SimpleDateFormat("dd/MM/yyyy");
		//SimpleDateFormat f1=new SimpleDateFormat("dd/MM/yyyy");
		f.setLenient(false);
		int x,y,x1,y1;
		try {
			Calendar c=Calendar.getInstance();
			
			Date d=f.parse(a);
			c.setTime(d);
			x=c.get(Calendar.MONTH);
			y=c.get(Calendar.YEAR);
			Date d1=f.parse(a1);
			c.setTime(d1);
			x1=c.get(Calendar.MONTH);
			y1=c.get(Calendar.YEAR);
			if(y1>=y)
			{
				diff=Math.abs((y1-y)*12+x1-x);
			}
			else
			{
				diff=Math.abs((y-y1)*12+x-x1);
			}
			
			//diff=x-y;
			System.out.println(diff);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			System.out.println("Not valid");
		}
		
			
	}

}
