
public class UserMainCode {
    
  static  String formNewString(String[] b,Integer n)
    {
	  StringBuffer sb=new StringBuffer();
	  String res="";
	  for(int i=0;i<n;i++)
	  {
		  res=res+b[i].substring(b[i].length()-2, b[i].length()-1);
	  }
	  return res;
    }
    
}
