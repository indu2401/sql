import java.util.Scanner;

public class Main {
    public static void main(String args[])
    {
    	Scanner s=new Scanner(System.in);
    	int a=s.nextInt();
    	String b[]=new String[a];
    	for(int i=0;i<a;i++)
    	{
    		b[i]=s.next();
    	}
    	UserMainCode u=new UserMainCode();
    	System.out.println(u.formNewString(b, a));
    	
    }

        
    }

