
public class NameExe {
	String name;
	String email;
	
	public NameExe(String name, String email) {
		super();
		this.name = name;
		this.email = email;
	}

	@Override
	public String toString() {
		return "NameExe [name=" + name + ", email=" + email + "]";
	}
	

}
