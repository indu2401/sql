import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;


public class Main {
	NameExe n;
	public static void main(String[] args) {
		HashMap<Integer,Object> hm=new HashMap<Integer,Object>();
		Scanner s=new Scanner(System.in);
		int a=s.nextInt();
		for(int i=0;i<a;i++)
		{
			int id=s.nextInt();
			String name=s.next();
			String email=s.next();
			hm.put(id,new NameExe(name, email));
			
		}
		for(Map.Entry<Integer,Object> set:hm.entrySet())
		{
			System.out.println(set.getKey()+" "+set.getValue());
		}
		int b=s.nextInt();
		for(Map.Entry<Integer,Object> map:hm.entrySet())
		{
		if(b==map.getKey())
		{
			System.out.println(map.getKey()+" "+map.getValue());
		}
		}
		
	}

}
