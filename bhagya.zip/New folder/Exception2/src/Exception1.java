public class Exception1 extends Throwable{
public String getMessage(){
	return ("Invalid Email ID\nRe-enter Email ID");
}
}  