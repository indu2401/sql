import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;


public class Main {
	static String ac;
	static String cot;
	static String cable;
	static String wifi;
	static String laundry;
	static String date;
	//static int room=0;
	
	void book(String ac,String cot, String cable,String wifi,String laundry)
	{
		 int res=0;
		    
		    if(ac.equals("AC"))
		    {
		    	res=res+1000;
		    }
		    else
		    {
		    	res=res+750;
		    }
		    if(cot.equals("Single"))
		    {
		    	res=res+0;
		    }
		    else
		    {
		    	res=res+350;
		    }
		    if(cable.equals("C"))
		    {
		    	res=res+50;
		    }
		    else
		    {
		    	res=res+0;
		    }
		    if(wifi.equals("W"))
		    {
		    	res=res+200;
		    }
		    else
		    {
		    	res=res+0;
		    }
		    if(laundry.equals("L"))
		    {
		    	res=res+100;
		    }
		    else
		    {
		    	res=res+0;
		    }
		    System.out.println("The total charge is Rs."+res+".");
		    System.out.print("The services chosen are\n"+cot+" cot ");
		    if(ac.equals("AC"))
		    {
		    	System.out.println("AC room");
		    }
		    else if(ac.equals("nAC"))
		    {
		    	System.out.println("non-AC room");
		    }
		    if(cable.equals("C"))
		    {
		    	System.out.println("Cable connection enabled");
		    }
		    else
		    {
		    	System.out.println("Cable connection disabled");
		    }
		    if(wifi.equals("W"))
		    {
		    	System.out.println("Wi-Fi enabled");
		    }
		    else
		    {
		    	System.out.println("Wi-Fi disabled");
		    }	
		    if(laundry.equals("L"))
		    {
		    	System.out.println("with laundry service");
		    }
		    else
		    {
		    	System.out.println("without laundry service");
		    }
		    //System.out.println("and the Date of Booking is "+date);
	}
	static void checkStatus(int choiceRoom,ArrayList<Integer> array)
	{
		if(array.contains(choiceRoom))
		{
			System.out.println("Room number "+choiceRoom+" is booked.");
		}
		else
		{
			System.out.println("Room number "+choiceRoom+" is not booked.");
		}
			
	}
	
	
	public static void main(String[] args) throws IOException {
		BufferedReader s=new BufferedReader(new InputStreamReader(System.in));
		ArrayList<Integer> array=new ArrayList<Integer>();
		Main m=new Main();
		int i;
		int room=0;
		do{
		System.out.println("Menu\n1. Book\n2. Check Status\n3. Exit");
		System.out.println("Enter your choice");
		i=Integer.parseInt(s.readLine());
		if(i==1)
		{
			String a;
		do{
			
		System.out.println("Booking:");
		
		System.out.println("Please choose the services required."
				+ "\nAC/non-AC(AC/nAC)");
		ac=s.readLine();
		System.out.println("Cot(Single/Double)");
		cot=s.readLine();
		System.out.println("With cable connection/without cable connection(C/nC)");
		cable=s.readLine();
		System.out.println("Wi-Fi needed or not(W/nW)");
		wifi=s.readLine();
		System.out.println("Laundry service needed or not(L/nL)");
		laundry=s.readLine();
		//System.out.println("Enter the Date of Booking");
		//date=s.readLine();
		
		m.book(ac, cot, cable,wifi, laundry);
		room++;
		array.add(room);
		
		System.out.println("Do you want to proceed?(yes/no)");
	    a=s.readLine();
		}while(a.equals("no"));
	    
	    System.out.println("Thank you for booking. Your room number is "+room+".");
		}
		else if(i==2){
			System.out.println("Check Status:");
			System.out.println("Enter room number");
			int choiceRoom=Integer.parseInt(s.readLine());
			m.checkStatus(choiceRoom,array);
		}
		else if(i==3)
			
		{
			System.exit(0);
		}
		
	}while(i<=3);
	}	

}
