import java.util.Arrays;

public class UserMainCode {
	public static int findRange(int[] a) {
		/*int max=a[0],min=a[0];
		int diff=0;
		Arrays.sort(a);
		diff=a[a.length-1]-a[0];
		return diff;*/
		int max=0;
		int min=a[0];
		for(int i=0;i<a.length;i++)
		{
			if(a[i]>max)
			{
				max=a[i];
				

			}
			if(a[i]<min)
			{
				min=a[i];
				

			}

		}
		int diff=max-min;
		//System.out.println(max);
		return diff;
	}
}
