import java.util.Scanner;


public class PatternPgm {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		String a=s.next();
		if(a.matches("[A-Z]{1}[a-z]{3}[0-9]{2}[@_#]{1}"))
		{
			System.out.println("valid");
		}
		else
		{
			System.out.println("not valid");
		}
	}

}
