import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;


public class GenerateSeries {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int a=s.nextInt();
		
		
		element(a);
	}
	static void element(int a)
	{
		
		ArrayList<Integer> arr=new ArrayList<Integer>();
		
		for(int i=1;i<=a;i++)
		{
			if(i%2!=0)
			{
				arr.add(i);
			}
		}
		int sum=arr.get(0);
		for(int i=1;i<arr.size();i++)
		{
			if(i%2!=0)
			{
				sum=sum+arr.get(i);
			}
			else
			{
				sum=sum-arr.get(i);
			}
		}
		System.out.println(sum);
		
		
	}

}
