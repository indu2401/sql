import java.util.Scanner;
import java.util.StringTokenizer;


public class MaximumVowels {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		String a=s.nextLine();
		StringBuffer sb=new StringBuffer("");
		StringTokenizer t=new StringTokenizer(a," ");
		a.toLowerCase();
		int max=0;
		String x="";
		while(t.hasMoreTokens())
		{
			int count=0;
			
			String b=t.nextToken();
			//System.out.println(b);
			for(int i=0;i<b.length();i++)
			{
				if(b.charAt(i)=='a'||b.charAt(i)=='e'||b.charAt(i)=='i'||b.charAt(i)=='o'||b.charAt(i)=='u')
				{
					count++;
				}
			}
			if(count>max)
			{
				max=count;
				x=b;
				
			}
		}
		System.out.println(x);
	}

}
