import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Scanner;


public class ArraySortMerge {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		ArrayList<Integer> a=new ArrayList<Integer>();
		ArrayList<Integer> a1=new ArrayList<Integer>();
		for(int i=0;i<5;i++)
		{
			a.add(s.nextInt());
		}
		for(int i=0;i<5;i++)
		{
			a1.add(s.nextInt());
		}
		ArrayList<Integer> a2=sortMerge(a,a1);
		Iterator<Integer> i=a2.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
		
		
		
	}
	static ArrayList<Integer> sortMerge(ArrayList<Integer> a,ArrayList<Integer> a1)
	{
		a.addAll(a1);
		Collections.sort(a);
		ArrayList<Integer> arr=new ArrayList<Integer>();
		arr.add(a.get(2));
		arr.add(a.get(6));
		arr.add(a.get(8));
		return arr;
	}

}
