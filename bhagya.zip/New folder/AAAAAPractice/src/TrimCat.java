import java.util.Scanner;


public class TrimCat {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		String a=s.nextLine();
		
		StringBuffer sb=new StringBuffer();
		for(int i=0;i<a.length();i=i+2)
		{
			char b=a.charAt(i);
			sb.append(b);
			
		}
		System.out.println(sb.toString());
		
	}

}
