import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;


public class HashMapToArrayList {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int a=s.nextInt();
		HashMap<Integer,String> map=new HashMap<Integer,String>();
		for(int i=0;i<a;i++)
		{
			map.put(s.nextInt(),s.next());
		}
		HashMapToArrayList h=new HashMapToArrayList();
		ArrayList<String> arr=h.mapToarray(map);
		Iterator<String> it=arr.iterator();
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
	}
	
	ArrayList<String> mapToarray(HashMap<Integer, String> map)
	{
		ArrayList<String> arr=new ArrayList<String>();
		Iterator<String> it=map.values().iterator();
		while(it.hasNext())
		{
			String a=it.next();
			if(a.matches("^[a-z].*")&&a.matches(".*[0-9]{1}.*")&&a.matches(".*[A-Z]$"))
			{
				arr.add(a);
			}
		}
		return arr;
	}

}
