import java.util.Scanner;
import java.util.StringTokenizer;


public class ShiftWords {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		String a=s.nextLine();
		StringBuffer sb=new StringBuffer();
		/*int b=a.indexOf(" ");
		int c=a.lastIndexOf(" ");
		String d=a.substring(0,b);
		String e=a.substring(c+1);
		String f=a.substring(b,c);
		//System.out.println(d+ " "+e);
		sb.append(e).append(f).append(" ");
		sb.append(d);
		System.out.println(sb.toString());*/
	    String []b=a.split("\\s");
	    String temp;
	    temp=b[0];
	    b[0]=b[b.length-1];
	    b[b.length-1]=temp;
	    
	    for(int i=0;i<b.length;i++)
	    {
	    	sb.append(b[i]).append(" ");
	    	
	    }
		sb.deleteCharAt(sb.length()-1);
		System.out.println(sb.toString());
		
	}

}
