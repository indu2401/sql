import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

class Elements
{
	static int l=0;
	public static int[] calculateElectricityBill(int n,ArrayList<Integer>al,int n1,ArrayList<Integer>al1)
	{
		int j=0,m=0;
		int a[]=new int[n+n1];

		for(int i=0;i<n;i++)
		{j=0;
			for(int k=0;k<n1;k++)
			{
				if(!al.get(i).equals(al1.get(k)))
				{
				
					j++;
				}
				
			}
			if(j==n1)
			{
				a[l]=al.get(i);
				l++;
			}
		}
		for(int i=0;i<n1;i++)
		{m=0;
			for(int k=0;k<n;k++)
			{
				if(!al1.get(i).equals(al.get(k)))
				{
					
					m++;
				}
			}
			if(m==n)
			{
				a[l]=al1.get(i);
				l++;
				
			}
		}
		
		Arrays.sort(a);
	return a;
	}


public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	int n=sc.nextInt();
	ArrayList<Integer> al=new ArrayList<Integer>();
	ArrayList<Integer> al1=new ArrayList<Integer>();	
for(int i=0;i<n;i++)
{
	al.add(sc.nextInt());
}	
int n1=sc.nextInt();
for(int i=0;i<n1;i++)
  {
	al1.add(sc.nextInt());
  }		
	int  []ans= calculateElectricityBill(n,al,n1,al1);
	for(int i=0;i<ans.length;i++)
		System.out.println(ans[i]);
		

}
}
