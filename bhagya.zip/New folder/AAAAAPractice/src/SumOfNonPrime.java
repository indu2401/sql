import java.util.Scanner;


public class SumOfNonPrime {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int a=s.nextInt();
		int sum=1;
		int k=0;
		for(int i=2;i<=a;i++)
		{
			k=0;
			for(int j=2;j<i;j++)
			{
				if(i%j==0)
				{
					k++;
				}
			}
			if(k!=0)
			{
				sum=sum+i;
			}
			
		}
		
		System.out.println(sum);
	}

}
