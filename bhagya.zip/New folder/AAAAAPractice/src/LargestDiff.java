import java.util.Scanner;


public class LargestDiff {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int a=s.nextInt();
		int n1=0,n2=0,n3 = 0;
		int b[]=new int[a];
		
		for(int i=0;i<a;i++)
		{
			b[i]=s.nextInt();
		}
		for(int j=0;j<b.length-1;j++)
		{
			n2=Math.abs(b[j]-b[j+1]);
			if(n2>n1)
			{
				n1=n2;
				n3=j+1;
			}
		}
		System.out.println(n3);
	}

}
