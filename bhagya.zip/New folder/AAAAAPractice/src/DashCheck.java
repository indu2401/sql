import java.util.Scanner;


public class DashCheck {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		String a=s.next();
		String b=s.next();
		int i,j,flag = 0;
		for(i=0,j=0;i<a.length()||j<b.length();i++,j++)
		{
			if(i==a.length())
			{
				if(a.substring(i-1).contains("-"))
				{
					flag=1;
					break;
				}
			}
			if(i==b.length())
			{
				if(b.substring(i-1).contains("-"))
				{
					flag=1;
					break;
				}
			}
			if(a.charAt(i)=='-')
			{
				if(a.charAt(i)!=b.charAt(i))
				{
					flag=1;
					break;
				}
			}
		}
		if(flag==0)
		{
			System.out.println("yes");
		}
		else
		{
		System.out.println("no");
		}
	}

}
