
public class SwapTwoNUm {
	public static void main(String[] args) {

		int a,b,c;
		a=1;
		b=2;

		System.out.print("a is ");
		System.out.println(a);
		System.out.print("b is ");
		System.out.println(b);


		//<add your code to swap a and b here>
		c=a;
		a=b;
		b=c;
		System.out.print("a is ");
		System.out.println(a);
		System.out.print("b is ");
		System.out.println(b);


	}

}
