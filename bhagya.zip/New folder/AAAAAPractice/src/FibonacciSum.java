import java.util.Scanner;


public class FibonacciSum {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int a=s.nextInt();
		int n1=0,n2=1,sum=0,c=0,d=1;;
		for(int i=3;i<=a;i++)
		{
			System.out.println(n1);
			sum=sum+n1;
			c=n1+n2;
			n1=n2;
			n2=c;
			//d=d+c;
			
			
		}
		System.out.println(sum);
	}

}
