import java.util.Scanner;


public class EvenOddIndexSum {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int a=s.nextInt();
		int b=a;
		int r=0;
		int i=0;
		int sum=0;
		int sum1=0;
		int count=0;
		int arr[]=new int[10];
		while(b>0)
		{
			
			r=b%10;
			arr[i]=r;
			b=b/10;
			count++;
			i++;
		}
		for(int j=0;j<=count;j++)
		{
			if(j%2==0)
			{
				sum=sum+arr[j];
			}
			else
			{
				sum1=sum1+arr[j];
			}
		}
		System.out.println(sum+" "+sum1);
	}

}
