
import java.util.Scanner;


public class Prefix {
public static void main(String args[])
{
	Scanner s=new Scanner(System.in);
	int n=s.nextInt();
	String arr[]=new String[n];
	for(int i=0;i<n;i++)
	{
		arr[i]=s.next();//prefix finder
	}
	int c=0;
	for(int i=0;i<n;i++)
	{
		int co=0;
		for(int k=i;k<arr.length;k++)
		{
			if(arr[i].equals(arr[k]) && i!=k)
			{
				co++;	
			}	
		}
		if(co==0)
		{
		for(int j=0;j<n;j++)
		{
			if(arr[j].length()>arr[i].length())
			{
				if(arr[j].substring(0,arr[i].length()).equals(arr[i]))
					c++;
				
			}
		}
		}
	}
	System.out.println(c);
}
} 
