import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Scanner;


public class DuplicateEle {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		String a=s.nextLine();
		System.out.println(remove(a));
		
	}
	static String remove(String a)
	{
		StringBuffer sb=new StringBuffer();
		LinkedHashSet<Character> l=new LinkedHashSet<Character>();
		for(int i=0;i<a.length();i++)
		{
			l.add(a.charAt(i));
		}
		Iterator<Character> i=l.iterator();
		while(i.hasNext())
		{
			char c=i.next();
			sb.append(c);
		}
		return sb.toString();
	}

}
