import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;


public class ElementsSOrtReverse {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int a=s.nextInt();
		String arr[]=new String[a];
		for(int i=0;i<a;i++)
		{
			arr[i]=s.next();
		}
		String e=s.next();
		element(arr,e);
	}
	static void element(String arr[],String b)
	{
		
		ArrayList<String> a=new ArrayList<String>();
		for(int i=0;i<arr.length;i++)
		{
			a.add(arr[i]);
		}
		Collections.sort(a);
		Collections.reverse(a);
		for(int i=0;i<a.size();i++)
		{
			if(b.equals(a.get(i)))
			{
			System.out.println(i+1);
			}
		}
		
	}
		
}
