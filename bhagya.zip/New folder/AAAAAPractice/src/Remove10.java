import java.util.Scanner;
public class Remove10
{
public static void main(String[]args)
{
Scanner sc=new Scanner(System.in);
int size=sc.nextInt();
int[]m=new int[size];
int[]n=new int[size];
int j=0;
for(int i=0;i<size;i++)
{
n[i]=sc.nextInt();
}
for(int i=0;i<size;i++)
{
if(n[i]!=10)
{
m[j]=n[i];
j++;
}}
for(int i=0;i<size;i++)
{
System.out.println(m[i]);
}
}
}
