import java.util.Scanner;
import java.util.StringTokenizer;


public class NegativeString {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		String a=s.nextLine();
		/*int b=s.nextInt();
		String c=Integer.toBinaryString(b);
		System.out.println(c);*/
		String c;
		StringBuffer sb=new StringBuffer();
		StringTokenizer t=new StringTokenizer(a," ");
		while(t.hasMoreTokens())
		{
			String b=t.nextToken();
			
			if(b.equals("is"))
			{
				c=b.replace("is", "is not");
				sb.append(c).append(" ");
			}
			else
			{
				sb.append(b).append(" ");
			}
		}
		System.out.println(sb.toString());
	}

}
