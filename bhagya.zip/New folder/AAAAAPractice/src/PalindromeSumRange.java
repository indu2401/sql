import java.util.ArrayList;
import java.util.Scanner;


public class PalindromeSumRange {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int a=s.nextInt();
		int b=s.nextInt();
		ArrayList<Integer> l=new ArrayList<Integer>();
		for(int i=a;i<=b;i++)
		{
			int r=0 , n3=i;
			while(n3!=0)
			{
				
				r=(r*10)+(n3%10);
				n3=n3/10;
			}
			if(r==i)
			{
				l.add(i);
			}
		}
		int sum=0;
		for(int i=0;i<l.size();i++)
		{
			sum=sum+l.get(i);
		}
		System.out.println(sum);

	}
	

}
