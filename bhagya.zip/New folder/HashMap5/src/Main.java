import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeMap;



public class Main {

	public static void main(String args[]) {
		Scanner s=new Scanner(System.in);
		int n=s.nextInt();
		HashMap<String,Integer> map1=new HashMap<String,Integer>();
		HashMap<String,Integer> map2=new HashMap<String,Integer>();
		for(int i=0;i<n;i++)
		{
			String st=s.next();
			map1.put(st, s.nextInt());
			map2.put(st, s.nextInt());
		}
		UserMainCode u=new UserMainCode();
		TreeMap<String, String> tree=u.calculateGrades(map1, map2);
		Iterator<String> it=tree.keySet().iterator();
		while(it.hasNext())
		{
			String key=it.next();
			String grade=tree.get(key);
			System.out.println(key+"\n"+grade);
		}


	}


}


