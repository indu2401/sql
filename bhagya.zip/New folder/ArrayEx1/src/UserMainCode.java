import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;


public class UserMainCode {
	ArrayList<Integer> findUnion(ArrayList<Integer> a1,ArrayList<Integer> a2)
	{
		ArrayList<Integer> arr=new ArrayList<Integer>(a1);
		arr.addAll(a2);
		Collections.sort(arr);
		HashSet<Integer> h=new HashSet<Integer>(arr);
		ArrayList<Integer> arr1=new ArrayList<Integer>(h);
		return arr1;
		
	}

}
