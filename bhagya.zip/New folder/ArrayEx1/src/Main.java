import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
import java.util.concurrent.ArrayBlockingQueue;


public class Main {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int a=s.nextInt();
		ArrayList<Integer> arr1=new ArrayList<Integer>();
		ArrayList<Integer> arr2=new ArrayList<Integer>();
		for(int i=0;i<a;i++)
		{
			arr1.add(s.nextInt());
		}
		for(int i=0;i<a;i++)
		{
			arr2.add(s.nextInt());
		}
		ArrayList<Integer> arr3=new UserMainCode().findUnion(arr1, arr2);
		Iterator i=arr3.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
	}

}
