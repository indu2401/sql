import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String s=sc.next();
		char[] a=s.toCharArray();
		String ans="";int count=0;
		System.out.println(s.length());
		System.out.println(a.length);
		for(int i=0;i<s.length();i++)
		{
			if((i%2==0))
			{
				ans+=a[i];
			}else
			if(i%2!=0)
			{
				if(!(a[i]=='a'||a[i]=='e'||a[i]=='i'||a[i]=='o'||a[i]=='u'||a[i]=='A'||a[i]=='E'||a[i]=='I'||a[i]=='O'||a[i]=='U'))
				{
					ans+=a[i];
				}
			}
			
			
		}
		System.out.println(ans);
		//System.out.println(count);
	}

}
