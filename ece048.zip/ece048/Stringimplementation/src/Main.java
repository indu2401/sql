
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String a[][]=new String[5][3];
String[][] salutation = { {"101", "jack", "jack@gmail.com"}, {"101", "jack", "jack@gmail.com"},{"101", "jack", "jack@gmail.com"},
{"101", "jack", "jack@gmail.com"},
{"101", "jack", "jack@gmail.com"}};



	}

}
