import java.util.*;
public class Main {
public static void main(String args[])
{
	Scanner sc=new Scanner(System.in);
	String s=sc.nextLine();
	char[] arr=s.toCharArray();
	int n=sc.nextInt();
	//method 1
	for(int i=0;i<n;i++)
	{
		System.out.print(arr[i]);
	}
	for(int i=arr.length-n;i<arr.length;i++)
	{
		System.out.print(arr[i]);
	}
	//method 2
	String a=s.substring(0, n)+s.substring(s.length()-n, s.length());
	System.out.println("\n"+a);
}
}
