import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException
	{
		// TODO Auto-generated method stub
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		int n=Integer.parseInt(br.readLine());
		int sum=0;
		UserMainCode obj=new UserMainCode();
		sum=obj.isPerfect(n);
		if(sum==n)
		{
			System.out.println("Perfect number");
		}else
			System.out.println("Not a perfect number");
	}

}
