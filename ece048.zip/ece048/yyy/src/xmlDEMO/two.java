package xmlDEMO;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

public class two {
	@Test
	void  s2()
	{
		System.out.println("after class");
	}
}
