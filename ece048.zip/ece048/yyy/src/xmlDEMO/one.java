package xmlDEMO;


import org.testng.annotations.Test;

public class one {
	@Test
	void  sub()
	{
		System.out.println("before method");
	}
}
