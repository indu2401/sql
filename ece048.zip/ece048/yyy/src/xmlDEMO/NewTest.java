package xmlDEMO;

import org.testng.annotations.Test;

public class NewTest {
 
  @Test(priority =1,description="enabled")
	void  hi()
	{
		System.out.println("hi");
		//int a=0/0;
	}
}
