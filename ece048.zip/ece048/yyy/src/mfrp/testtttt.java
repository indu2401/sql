package mfrp;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;

public class testtttt {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		WebDriver driver;
		System.setProperty("webdriver.chrome.driver", "D:\\Selenium\\chromedriver 2.35\\chromedriver.exe");
		 driver=new ChromeDriver();
		Reporter.log("chrome browser opened");
		 driver.manage().window().maximize();
	     Reporter.log("Browser Maximized");
	        
		driver.get("https://www.savaari.com/");
		Reporter.log("application opened");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id=\"approot\"]/mat-sidenav-container/mat-sidenav-content/app-home/div[1]/div[2]/div[2]/app-outstation/div/div/div/label[2]/span")).click();
		//driver.findElement(By.xpath("//input[@value='oneWay']")).click();
		driver.findElement(By.id("fromCityList")).sendKeys("bangalore");
		driver.findElement(By.xpath("//input[@placeholder='Start typing city - e.g. Mysore']")).sendKeys("chennai");
		//date picker
		driver.findElement(By.xpath("//*[@id=\"approot\"]/mat-sidenav-container/mat-sidenav-content/app-home/div[1]/div[2]/div[2]/app-outstation/div/form/div[3]/div[1]/div/p-calendar[1]/span/input")).click();
		//date selection
		driver.findElement(By.xpath("//*[@id=\"approot\"]/mat-sidenav-container/mat-sidenav-content/app-home/div[1]/div[2]/div[2]/app-outstation/div/form/div[3]/div[1]/div/p-calendar[1]/span/div/table/tbody/tr[5]/td[3]/a")).click();
		
		WebElement pickuptime=driver.findElement(By.xpath("//*[@id=\"pickUpTime\"]"));
		Select s=new Select(pickuptime);
		s.selectByIndex(5);
		driver.findElement(By.xpath("//button[text()='Select Car']")).click();
	}

}
