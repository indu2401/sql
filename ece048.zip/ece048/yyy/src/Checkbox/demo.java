package Checkbox;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Reporter;

public class demo {
	
	public static void main(String[] args) {
		
		WebDriver driver;
		System.setProperty("webdriver.chrome.driver", "D:\\Selenium\\chromedriver 2.35\\chromedriver.exe");
		 driver=new ChromeDriver();
		Reporter.log("chrome browser opened");
		 driver.manage().window().maximize();
	     Reporter.log("Browser Maximized");
	        
		driver.get("http://www.echoecho.com/htmlforms09.htm");
		Reporter.log("application opened");
		WebElement Milkcheckbox,Buttercheckbox;
		
		Milkcheckbox = driver.findElement(By.cssSelector("input[value='Milk']"));
		Milkcheckbox.click();
		Buttercheckbox = driver.findElement(By.cssSelector("input[value='Butter']"));
		Buttercheckbox.click();
	
		if(!(Buttercheckbox.isSelected()))
		
		{
			Buttercheckbox.click();
		}
		if(!(	Milkcheckbox.isSelected()))
			
		{
			Milkcheckbox.click();
		}
		
	

	}
}
