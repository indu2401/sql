package mfrptest;



import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import javax.xml.bind.Binder;

import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;


 class TestData
{
	
	public TestData() throws Exception
	{
		super();
	}
	
	public String getFrom() {
	return from;
}
public void setFrom(String from) {
	this.from = from;
}
public String getTo() {
	return to;
}
public void setTo(String to) {
	this.to = to;
}
public String getCusname() {
	return cusname;
}
public void setCusname(String cusname) {
	this.cusname = cusname;
}
public String getCusmail() {
	return cusmail;
}
public void setCusmail(String cusmail) {
	this.cusmail = cusmail;
}
public long getCusmobil() {
	return cusmobil;
}
public void setCusmobil(long cusmobil) {
	this.cusmobil = cusmobil;
}
public String getCuslocality() {
	return cuslocality;
}
public void setCuslocality(String cuslocality) {
	this.cuslocality = cuslocality;
}
public String getCusaddress() {
	return cusaddress;
}
public void setCusaddress(String cusaddress) {
	this.cusaddress = cusaddress;
}
public String getCuslandmark() {
	return cuslandmark;
}
public void setCuslandmark(String cuslandmark) {
	this.cuslandmark = cuslandmark;
}
	
XSSFWorkbook workbook = new XSSFWorkbook(new FileInputStream("C:\\Users\\694800\\Desktop\\mfrp.xlsx"));
XSSFSheet sheet = workbook.getSheetAt(0); 
XSSFRow row = sheet.getRow(0);  

		
	

	
		
		XSSFCell fro=row.getCell(0);
		String from=fro.getStringCellValue();
		XSSFCell too=row.getCell(1);
		String to=too.getStringCellValue();
		XSSFCell name=row.getCell(2);
		String cusname=name.getStringCellValue();
		XSSFCell mail=row.getCell(3);
		String cusmail=mail.getStringCellValue();
		XSSFCell mobile=row.getCell(4);
		long cusmobil= (long) mobile.getNumericCellValue();
	
		XSSFCell locality=row.getCell(5);
		String cuslocality=locality.getStringCellValue();
		XSSFCell address=row.getCell(6);
		String cusaddress=address.getStringCellValue();
		XSSFCell landmark=row.getCell(7);
		String cuslandmark=landmark.getStringCellValue();
		
		



}

public class NewTest extends TestData {


	public NewTest() throws Exception {
		super();
	}
	public void screenShot(){
		try {
			File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			screenshot.getAbsoluteFile();
			File dest = new File("C:\\Users\\694800\\Desktop\\"+ System.currentTimeMillis() +".png");
			FileUtils.copyFile(screenshot, dest);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	} 

	public WebDriver driver;

@BeforeTest
@Parameters("browser")
public void WebDriverConnection(String browser) throws Exception{

		if(browser.equalsIgnoreCase("chrome")){
			System.setProperty("webdriver.chrome.driver", "D:\\Selenium\\chromedriver 2.35\\chromedriver.exe");
			 driver=new ChromeDriver();
			Reporter.log("chrome browser opened");
			 driver.manage().window().maximize();
		     Reporter.log("Browser Maximized");
		        
			driver.get("https://www.savaari.com/");
			Reporter.log("application savaari opened");
		}
	
				else if(browser.equalsIgnoreCase("InternetExplorer")){
					System.setProperty("webdriver.ie.driver","D:\\Selenium softwares\\IE Driver\\IEDriverServer_Win32_3.12.0\\IEDriverServer.exe");
					 driver=new InternetExplorerDriver();
					Reporter.log("ie browser opened");
	
	
	 driver.manage().window().maximize();
     Reporter.log("Browser Maximized");
        
	driver.get("https://www.savaari.com/");
	Reporter.log("application savaari opened");


}
}





@Test(priority =1)
public void TravelDetails() throws Exception 
{
	//one way radio button
			//driver.findElement(By.xpath("//*[@id=\"approot\"]/mat-sidenav-container/mat-sidenav-content/app-home/div[1]/div[2]/div[2]/app-outstation/div/div/div/label[2]/span")).click();
	
	WebElement t1=driver.findElement(By.id("fromCityList"));
	

	//Robot robot = new Robot();
	
	WebDriverWait wait = new WebDriverWait(driver,20);
	wait.until(ExpectedConditions.visibilityOf(t1));
	
	t1.sendKeys(getFrom());
	
	Thread.sleep(2000);
	t1.sendKeys(Keys.ARROW_DOWN,Keys.ENTER);
	//robot.keyPress(KeyEvent.VK_TAB);
	
	
	//robot.keyRelease(KeyEvent.VK_TAB);
	Reporter.log("From is selected as"+from);
	WebElement t2=driver.findElement(By.xpath("//*[@id=\"approot\"]/mat-sidenav-container/mat-sidenav-content/app-home/div[1]/div[2]/div[2]/app-outstation/div/form/div[2]/div[2]/input"));
	
	
	
	t2.sendKeys(getTo());
	Thread.sleep(5000);
	t2.sendKeys(Keys.ARROW_DOWN,Keys.ENTER);
	//robot.keyPress(KeyEvent.VK_TAB);
	//robot.keyRelease(KeyEvent.VK_TAB);
	Reporter.log("Destination is selected as"+to);
			//date picker
			driver.findElement(By.xpath("//*[@id=\"approot\"]/mat-sidenav-container/mat-sidenav-content/app-home/div[1]/div[2]/div[2]/app-outstation/div/form/div[3]/div[1]/div/p-calendar[1]/span/input")).click();
			//date selection
			driver.findElement(By.xpath("//*[@id=\"approot\"]/mat-sidenav-container/mat-sidenav-content/app-home/div[1]/div[2]/div[2]/app-outstation/div/form/div[3]/div[1]/div/p-calendar[1]/span/div/table/tbody/tr[5]/td[3]/a")).click();
			Reporter.log("Date is selected as 31");
			//pickuptime
	
	WebElement list=driver.findElement(By.xpath("//*[@id=\"pickUpTime\"]"));
	Select s=new Select(list);
	s.selectByIndex(5);
	Reporter.log("Pickup time is selected as 1.00 pm");
	//closealert
	//driver.findElement(By.xpath("//*[@id=\"cdk-overlay-0\"]/mat-dialog-container/app-too-early-dialog/button")).click();
	screenShot();
	//selectcarbutton
	driver.findElement(By.xpath("//*[@id=\"approot\"]/mat-sidenav-container/mat-sidenav-content/app-home/div[1]/div[2]/div[2]/app-outstation/div/form/div[4]/div/div[1]/button")).click();
	Reporter.log("select car button clicked");
	//navigating to next page
	//driver.navigate().to("https://www.savaari.com/select_cars?from_city_name=Bangalore,%20Karnataka&from_city_id=377&to_city_details=W3siY2l0eUlkIjoyNzU0LCJjaXR5TmFtZSI6IkNoZW5uYWksIFRhbWlsIE5hZHUiLCJTb3VyY2VfY2l0eV9pZCI6IjgxIiwiYWxpYXMiOlsiTWFkcmFzIl19XQ%3D%3D&trip_sub_type=oneWay&trip_type=outstation&pickup_date=25-07-2018&pickup_time=1532460600&drop_date=");
	
}

@Test(priority =2)
public void SelectCar() throws Exception
{
	

	driver.navigate().forward();
	Reporter.log("Moved forward to select car page");
	//selecting a car
			Thread.sleep(5000);
			screenShot();
			driver.findElement(By.xpath("//*[@id=\"approot\"]/mat-sidenav-container/mat-sidenav-content/app-select-car/div[2]/div/div/div[1]/div[4]/div/button")).click();
			
			Reporter.log("selecting the car");	
	
	
	
	
}

@Test(priority =3)
public void BookingPage() throws Exception
{

	
	//booking page
	driver.navigate().forward();
	Reporter.log("Moved forward to details page");
	Thread.sleep(2000);

	driver.findElement(By.xpath("//*[@id=\"approot\"]/mat-sidenav-container/mat-sidenav-content/app-booking/div[2]/app-booking-pickup-detail/div/div[2]/form/div[1]/div/input")).sendKeys(cusname);
	Reporter.log("Name entered as "+cusname);
	driver.findElement(By.xpath("//*[@id=\"approot\"]/mat-sidenav-container/mat-sidenav-content/app-booking/div[2]/app-booking-pickup-detail/div/div[2]/form/div[2]/input")).sendKeys(cusmail);
	Reporter.log("Mail entered as "+cusmail);
	driver.findElement(By.xpath("//*[@id=\"approot\"]/mat-sidenav-container/mat-sidenav-content/app-booking/div[2]/app-booking-pickup-detail/div/div[2]/form/div[3]/div/input")).sendKeys(String.valueOf(cusmobil));
	Reporter.log("MobileNumber entered as "+cusmobil);
	Thread.sleep(1000);
	driver.findElement(By.xpath("//*[@id=\"approot\"]/mat-sidenav-container/mat-sidenav-content/app-booking/div[2]/app-booking-pickup-detail/div/div[2]/form/div[4]/div/input")).sendKeys(cuslocality);
	
	

	Thread.sleep(2000);
	driver.findElement(By.xpath("//*[@id=\"approot\"]/mat-sidenav-container/mat-sidenav-content/app-booking/div[2]/app-booking-pickup-detail/div/div[2]/form/div[4]/div/input")).sendKeys(Keys.ARROW_DOWN);
	driver.findElement(By.xpath("//*[@id=\"approot\"]/mat-sidenav-container/mat-sidenav-content/app-booking/div[2]/app-booking-pickup-detail/div/div[2]/form/div[4]/div/input")).sendKeys(Keys.ENTER);
	Thread.sleep(2000);
	Reporter.log("Locality entered as "+cuslocality);
	
	driver.findElement(By.xpath("//*[@id=\"approot\"]/mat-sidenav-container/mat-sidenav-content/app-booking/div[2]/app-booking-pickup-detail/div/div[2]/form/div[5]/div/textarea")).sendKeys(cusaddress);
	Reporter.log("Address entered as "+cusaddress);
	driver.findElement(By.xpath("//*[@id=\"approot\"]/mat-sidenav-container/mat-sidenav-content/app-booking/div[2]/app-booking-pickup-detail/div/div[2]/form/div[5]/div/input")).sendKeys(cuslandmark);
	Reporter.log("Name entered as "+cuslandmark);
	
	screenShot();
	driver.findElement(By.xpath("//*[@id=\"approot\"]/mat-sidenav-container/mat-sidenav-content/app-booking/div[2]/app-booking-pickup-detail/div/div[2]/form/button/div/span")).click();
	Reporter.log("Proceed to payment button clicked");
	WebElement totalfare=driver.findElement(By.xpath("//*[@id=\"static-1\"]/div/div[4]/div[2]/div"));
	Reporter.log("Total fare is "+totalfare.getText());
	
	
}


@AfterTest
public void CloseDriver() throws Exception
{


	driver.close();
	Reporter.log("Driver closed");
	
}
}
	






