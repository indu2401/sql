package hackerrank;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

	public static void main(String args[]) throws IOException
	{
		/*BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		int n=Integer.parseInt(br.readLine());*/
		//String z[]=new String[n];
	/*	for(int i=0;i<n;i++)
		{
			z[i]=br.readLine();
		}
		for(int i=0;i<n;i++)
		{
			System.out.println(z[i]);
		}
		for(int i=0;i<n;i++)	
		{
	String s=z[i];*/
	//System.out.println("arrayloop"+s);
	int start=0,last=0,count=0,del=0;
	String s="<SA premium>Imtiaz has a secret crush</SA premium>";
if(s.contains("<"))
{
	do
	{
		if(s.contains("<"))
		{
		System.out.println("in do"+s);
		
	start=s.indexOf("<")+1;
	last=s.indexOf(">");

	
	String tag=s.substring(start,last);
	
System.out.println("start"+start);
System.out.println("last"+last);
System.out.println("tag"+tag);
String endtag="</"+tag+">";
System.out.println("endtag"+endtag);

int index=s.indexOf(endtag);
System.out.println("index"+index);
if(index==-1)
{
	
	System.out.println("None");
	
	count=1;
	s=s.substring(last+1);
	System.out.println(s);

	del=s.indexOf(">");		
	
	System.out.println("del   "+del);
	System.out.println(s.charAt(del));
	s=s.substring(del+1);
	System.out.println(s);
	System.out.println("after deleting"+s.length());
	
	
}else
{
	
String toprint=s.substring(last+1,s.length()-(tag.length()+3));
System.out.println(toprint);
if(s.contains("<"))
{
	
	s=toprint;
	//System.out.println("contains");
	
	
}else
{
int add=tag.length()+3;
System.out.println("tag length"+add);
s=s.substring(index+add);
//System.out.println("s"+s);
System.out.println("after printing"+s.length());
}

	}
		}
	}while(s.length()>0);

	
}
	
		}
}


