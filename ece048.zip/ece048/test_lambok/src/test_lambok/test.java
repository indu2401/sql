package test_lambok;

import lombok.*;


@Data
public class test {
	
public int id;
	
public String name;



}
