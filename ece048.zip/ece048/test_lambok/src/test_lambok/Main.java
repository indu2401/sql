package test_lambok;

import lombok.*;


public class Main {

	test t=new test();;
	t.setId();
	
	
	
	
	
	
}
