import java.util.Comparator;


public class RoomSort implements Comparator<Room>  {
	 public int compare(Room r1,Room r2) {
	        return r1.roomNumber.compareTo(r2.roomNumber);
	    }
}  
