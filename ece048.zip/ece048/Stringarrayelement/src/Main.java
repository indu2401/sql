import java.util.Arrays;
import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();int ans=0;
				String arr[]=new String[n];
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.next();
			
		}
		Arrays.sort(arr);
		String key=sc.next();
		for(int i=0;i<n;i++)
		{
			System.out.println(arr[i]);
			if(arr[i].equals(key))
			{
				 ans = i;break;
			}
			
		}System.out.println(ans);
		
		
		
		//System.out.println(arr.);
	}

}