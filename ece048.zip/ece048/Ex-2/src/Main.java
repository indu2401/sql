import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class Main {
	static boolean validEmail(String email) {
	    // editing to make requirements listed
	    // return email.matches("[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,4}");
		//email.matches("[A-Z0-9._%+-]*+@[A-Z0-9.-]*+.[A-Z0-9.-]*");
	    //boolean i=email.matches("[a-zA-Z0-9._%+-]*+@[a-zA-Z0-9.-]*+.[a-zA-Z]*");
	    //System.out.println(i);
	    //return i;
		if(email.contains("@")&&email.contains("."))
		{
			int i=email.indexOf("@");int j=email.indexOf(".");i++;j++;
			//System.out.println(i);
			//System.out.println(j);
			int diff=j-i;
			//System.out.println(diff);
			if(diff>1)
			return true;
		}
		return false;
	}
	static class emailException extends Exception
	{
	 public emailException()
	 {
	
	  System.out.println("Invalid Email ID");
	 
	}
public static void main(String args[]) throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
				String mail="";int z=0;
				System.out.println("Customer Registration:\n");
				System.out.println("Enter the customer details:");
				System.out.println("Enter the first name:");
				String firstname=br.readLine();
				System.out.println("Enter the last name:");
				String Lastname=br.readLine();
				System.out.println("Enter the contact number:");
				String contact=br.readLine();
				do{
					try{
				System.out.println("Enter the e-mail id:");
				 mail=br.readLine();
				 if(!validEmail(mail))
				{throw new emailException();
				}
				}
				catch (emailException m) {
					System.out.println("Re-enter Email ID");
					z++;
				  }
					}while(!(z==0));
					
				
				System.out.println("Enter the proof type:");
				String type=br.readLine();
				System.out.println("Enter the proof id:");
				String proof=br.readLine(); 
		Customer c = new Customer();
				c.registerCustomer(firstname,Lastname,contact,mail,type,proof);
				c.display();
		
				
			
				
			

}
}
}
