package save;

import java.io.*;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;
public class ssss {

//		public static void register(String name,String address,String contact,String mail,String type,String proof)
//		{
//			int count=1;
//		
//		System.out.println("Welcome "+name+".");
//			System.out.println("Here are your details");
//		System.out.println("Address: "+address);
//		System.out.println("Contact Number: "+contact);
//		System.out.println("E-Mail ID: "+mail);
//		System.out.println("Proof type: "+type);
//		System.out.println("Proof id: "+proof);
//		System.out.println();
//		System.out.println("Thank you for registering. Your id is "+count+"..");
//		System.out.println();
//		count++;
//		}
		public static void viewCustomers(String[] a)
		{
			//Iterator i=a.iterator();
			int i=1;
			while(a.length>0)
			{
				System.out.println("Customers list\nThe registered customers are");
				System.out.format("%-15s%-15s\n","Customer ID","Customer name");
				System.out.format("%-15s%-15s\n",i,a[i]);
				System.out.println("Thank You");
				
			}
		
			
		}
	
		public static void main(String args[]) throws IOException
		{
			int i=1;
			
		//String name[]=new String[10];
			//ArrayList name=new ArrayList();
			/*
			ArrayList address=new ArrayList();
			ArrayList contact=new ArrayList();
			ArrayList mail=new ArrayList();
			ArrayList type=new ArrayList();
			ArrayList proof=new ArrayList();
			//String yn=new String();
			 * */
			String[] name= new String[10];
			 String contact,address,mail,type,proof;
			//String yn="";
			String yn;
			do{
			//Scanner sc=new Scanner(System.in);
				BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			System.out.println("Registration");
			//System.out.println();
			System.out.println("Enter your name");
			 //name.add(br.readLine());
			name[i]=br.readLine();
			 System.out.println(name);
			System.out.println("Enter your address");
			 //address.add(br.readLine());
			address=br.readLine();
			System.out.println(address);
			System.out.println("Contact Number");
			 //contact.add(br.readLine());
			contact=br.readLine();
			System.out.println(contact);
			System.out.println("E-Mail ID");
			
			// mail.add(br.readLine());
			mail=br.readLine();
			
			System.out.println(mail);
			System.out.println("Enter proof type");
			 //type.add(br.readLine());
			type=br.readLine();
			System.out.println(type);
			System.out.println("Enter proof id");
			// proof.add(br.readLine());
			proof=br.readLine();
			System.out.println(proof);
			//System.out.println();
			System.out.println("Thank you for registering. Your id is "+i+"..");
			//register(name[i],address,contact,mail,type,proof);
			System.out.println("Do you want to continue registration (y/n)?");
			//i++;
			
			  yn=br.readLine();
			 System.out.println(yn);
			 i++;
			}while(yn.equals("y"));
			
			if(yn.equals("n"))
			{
				viewCustomers(name);
			}
		
			//sc.close();
		
		}
		
		

		

	}



