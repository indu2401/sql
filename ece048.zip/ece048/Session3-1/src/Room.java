public class Room {
	int roomid, hours;
	int rate;

	public Room() {
	}

	public Room(int roomid, int hours, int rate) {
		this.roomid = roomid;
		this.hours = hours;
		this.rate = rate;
	}

	void display() {
	}
}