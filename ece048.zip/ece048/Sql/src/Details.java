import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class Details {
	
	int id;
	String name, email;
	
	Connection con=ConnectionUtil.connectToMysql();
	PreparedStatement st=null;	
	
	public Details(int id, String name, String email) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		
	}
	
	public Details() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	public void display() throws SQLException
	{
		String str="select * from details";
		
		st=con.prepareStatement(str);
		
		ResultSet rs=st.executeQuery(str);
		
		while(rs.next())
		{
			
			System.out.println("The reservation details are as follows:\n");
			System.out.println(rs.getInt(1));
			System.out.println("Name : "  + rs.getString(2));
			System.out.println("Email : " + rs.getString(3));		
				
	}
}

	public void search(int ID) throws SQLException
	{
		String str="select id from details where id = " + ID;
		
	
		st=con.prepareStatement(str);
		
		ResultSet rs=st.executeQuery(str);
		
		while(rs.next())
		{
			
			System.out.println("The SEARCH ID :\n");
		//	System.out.println("ID " + rs.getInt(1));
			int emp_ID = rs.getInt(1);
			if(emp_ID != 0){
				String strs = "select * from details where id = " + emp_ID;
				
				st=con.prepareStatement(strs);
				
				ResultSet r=st.executeQuery(strs);
				while(r.next()){
				System.out.println("Name " + r.getString(2));
				System.out.println("Email " + r.getString(3));
				}
			}
			
				
	}
}
	
}
