
import java.sql.*;
import java.util.Locale;
import java.util.ResourceBundle;



import com.mysql.jdbc.Driver;

public class ConnectionUtil {
	
	public static Connection connectToMysql() 
	
	{

		String url="jdbc:mysql://localhost:3306/employee";

		String user="root";

		String pass="root";
		
		try {
			
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection con=DriverManager.getConnection
							(url,user,pass);
					System.out.println("Connection Established");
					return con;
					
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
		//	Class.forName(com.mysql.jdbc.Driver.class.getName());
				
				/*Driver driver = new com.mysql.jdbc.Driver();
				
				DriverManager.registerDriver(driver);*/		
			
		}
		/*	} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
		 catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return null;
		
	}
	
	
} 
