import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.*;
public class Main {
	
	Connection con=ConnectionUtil.connectToMysql();
	
	PreparedStatement st=null;	
	
	public void addEmployee(int ID, String Name, String Email) throws SQLException
	{
		 
		String str="insert into details(id , name , email  )"
				+ " values(?,?,?)";
		st=con.prepareStatement(str);
		
		// hotelID , roomID , roomType , roomNumber , roomCapacity , roomAc , roomWifi , roomCabel , roomLaundry ,
		
		st.setInt(1,ID);
		st.setString(2, Name);
		st.setString(3, Email);
		
	
		st.executeUpdate();
		
	//	System.out.println("Succesfully inserted Reserv");
	}

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
	//	int n = s.nextInt();
	//	int id = s.nextInt();
	//	String name = s.next(), email = s.next();
		Main m = new Main();
	//	m.addEmployee(id,name,email);
		
		Details d  = new Details();
	//	d.display();
		System.out.println("Enter the id to be searched");
		int key = s.nextInt();
		
		d.search(key);
		
	}

}
