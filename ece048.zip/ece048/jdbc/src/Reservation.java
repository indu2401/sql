
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class Reservation {
	String cusType;
	int cusAC, cusWifi, cusCable, cusLaundry;
	static boolean availability = false;
	
	Connection con=connectionUtil.connectToMysql();
	PreparedStatement st=null;	
	

	public Reservation(String cusType, int cusAC, int cusWifi,
			int cusCable, int cusLaundry) {
		super();
		this.cusType = cusType;
		this.cusAC = cusAC;
		this.cusWifi = cusWifi;
		this.cusCable = cusCable;
		this.cusLaundry = cusLaundry;
	}

	public String getCusType() {
		return cusType;
	}

	public int getCusAC() {
		return cusAC;
	}

	public int getCusWifi() {
		return cusWifi;
	}

	public int getCusCable() {
		return cusCable;
	}

	public int getCusLaundry() {
		return cusLaundry;
	}
	
	public void checkRoom() throws SQLException
	{
		String str="select * from hotel";
		
		int roomNo;
		
		st=con.prepareStatement(str);
		
		ResultSet rs=st.executeQuery(str);
		
		while(rs.next())
		{
			if(rs.getString(3).equals(cusType) && rs.getInt(6) == cusAC && rs.getInt(7) == cusWifi && rs.getInt(8) == cusCable && rs.getInt(9) == cusLaundry){
				availability = true;
				System.out.println( "Please take room number " + rs.getInt(6));
			
			}
			
			
		}
			
	}
	
} 
