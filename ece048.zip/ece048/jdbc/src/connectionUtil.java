
import java.sql.*;
import java.sql.Connection;
import java.util.Locale;
import java.util.ResourceBundle;


import com.mysql.jdbc.Driver;

public class connectionUtil {
	
	public static Connection connectToMysql() 
	
	{
		ResourceBundle rb= ResourceBundle.getBundle("mysql",Locale.getDefault());

		String url=rb.getString("db.url");

		String user=rb.getString("db.username");

		String pass=rb.getString("db.password");
		
		try {
			
				//Class.forName("com.mysql.jdbc.Driver");
			
		//	Class.forName(com.mysql.jdbc.Driver.class.getName());
				
				Driver driver = new com.mysql.jdbc.Driver();
				
				DriverManager.registerDriver(driver);
			
			Connection con=DriverManager.getConnection
					(url,user,pass);
			System.out.println("Connection Established");
			return con;
		}
		/*	} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
		 catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return null;
		
	}
	
	
} 
