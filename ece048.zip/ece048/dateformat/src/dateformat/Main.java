package dateformat;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class Main {

	public static void main(String[] args) throws IOException, ParseException {
		
		String s="02/06/2018";
		String ss="07/06/2014";
	
			 int count=0;
			
			SimpleDateFormat d=new SimpleDateFormat("dd/MM/yyyy");
			d.setLenient(false);
			Date d1 = null,d2 = null,d3 = null;
			try{
			 d1=d.parse(s);
			 d2=d.parse(ss);
			 d3=d.parse(s);
			}
			catch(ParseException e)
			{
				System.out.println("exception");
				e.printStackTrace();
			}
			Calendar c=Calendar.getInstance();
			c.setTime(d1);
			
			long milli=c.getTimeInMillis();
			c.setTime(d2);
			
			long milli1=c.getTimeInMillis();
			long diff=Math.abs(milli-milli1);//difference in milliseconds
			int days=(int) TimeUnit.MILLISECONDS.toDays(diff);//conversion of milliseconds to day
			//int year=TimeUnit.DAYS.
			System.out.println(days);
			SimpleDateFormat day=new SimpleDateFormat("EEEEEE ");
			
			String ans=day.format(d3);//to print day of first date in words
			System.out.println(ans);
			
			
		
	
	}

}
