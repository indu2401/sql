
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//String dou="as.sdf";
//String a[]=dou.split(".");
String a[]={"1234","4500000"};
//System.out.println(a.length);
System.out.println(a[1]);
int length=(a[1].length()-1);
System.out.println("length"+length);
int end=length;

	if(a[1].charAt(length)=='0')
	{
		//System.out.println("lengthin loop"+length);
		while((a[1].charAt(length)=='0'))
		{
			System.out.println("lengthin loop"+length);
			
		end--;
		length--;
		if(!(a[1].charAt(length)=='0'))
			break;
		}
	}

System.out.println(a[0].length()+":"+(end+1));
	}

}
