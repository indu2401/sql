import java.util.Arrays;
import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		String a[]=new String[n];
		int count[]=new int[n];
		int z=0,x=0;
		for(int i=0;i<n;i++)
		{
			a[i]=sc.next();
		}
		for(int i=0;i<n;i++)
		{
			z=0;
			System.out.println("i= "+a[i]);
			for(int j=0;j<n;j++)
			{
				System.out.println(a[j]);
		
				
				if(a[j].startsWith(a[i])){
					
					z++;
				}
				
			
				
			}count[i]=z-1;
			System.out.println("count"+count[i]);
		}
		
		
		Arrays.sort(count);
		System.out.println(count[(count.length)-1]);
		
		//if("asf".startsWith("asf"))
		//System.out.print("yes");
		

	}

}
