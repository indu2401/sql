package one;

import java.util.Scanner;

public class login {

	

	public static void main(String[] args, char[] CharSequence) {
	 Scanner sc=new Scanner(System.in);
	 String Userid,password;
	 Userid=sc.next();
	 password=sc.next();
	if(Userid.equals("admin") && password.equals("adminpassword123"))
	{
		System.out.println("logged in");
	}else
	{
		System.out.println("Invalid credintials");
	}
	}

}
