import java.util.Arrays;


public class Main {

	public static void main(String args[])
	{
		int a[]={12,24,7,36,14};
		int b[]={11,26,7,14};
		int lengtha=a.length;
		int lengthb=b.length;
		int c[] = new int[lengtha+lengthb];
		int aub[] =new int[lengtha+lengthb];
		int aib[] = new int[lengtha+lengthb];
		int union=0,intersection=0;
		
		for(int i=0;i<lengtha;i++)
		{
			
				c[i]=a[i];
			
		}
		for(int i=lengtha,j=0;j<lengthb;i++,j++)
		{
			//System.out.println(c[i]+" "+b[j]);
				c[i]=b[j];
			
		}
		//System.out.println(lengtha);
		Arrays.sort(c);
		for(int i=0;i<lengtha+lengthb;i++)
		{
			
			System.out.println(c[i]);
			
		}
		
		for(int i=0;i<=lengtha+lengthb;i++)
		{
			if(i==lengtha+lengthb-1)
			{
				aub[union]=c[i];
				union++;
			}else
			if(i!=lengtha+lengthb){
				if(c[i]!=c[i+1])
				{
					aub[union]=c[i];
					union++;
				}
			}
				
		
		}
		
		
		for(int i=0;i<lengtha;i++)
		{
			for(int j=0;j<lengthb;j++)
			{
				if(a[i]==b[j])
				{
					aib[intersection]=a[i];
					intersection++;
				}
			
			}
		}
		
		for(int i=0;i<aub.length;i++)
		{
			if(aub[i]!=0)
				System.out.println("union"+aub[i]);
			
		}
		for(int i=0;i<aib.length;i++)
		{
			if(aib[i]!=0)
				System.out.println("intersection"+aib[i]);
			
		}
		
		for(int i=0;i<aib.length;i++)
		{
			for(int j=0;j<aub.length;j++)
			{
				if(aub[i]==aib[j])
				{
					aub[i]=0;
				}
			
			}
		}
		for(int i=0;i<aub.length;i++)
		{
			if(aub[i]!=0)
				System.out.println("ans"+aub[i]);
			
		}
		
		
	}
}
