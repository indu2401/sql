import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<String,Float> hm=new HashMap<String,Float>();
		Scanner sc=new Scanner(System.in);
		Float sum = (float)0;
		int n=sc.nextInt();
		for(int i=0;i<n;i++)
		{
			String device=sc.next();
			Float rate=sc.nextFloat();
			hm.put(device, rate);
		}
		int z=sc.nextInt();
		String arr[]=new String[z];
		for(int i=0;i<z;i++)
		{
			arr[i]=sc.next();
		}
		
		Iterator i=hm.keySet().iterator();
	/*String key = (String) i.next();
			for(;i.hasNext(); key= (String) i.next())
			{
			
			for(int k=0;k<arr.length;k++)
			{
				System.out.println("arr"+arr[k]+"key in map "+key+"k"+k);
				boolean yes=arr[k].equals(key);
				if(yes==true)
				{
					Float e=hm.get(key);
					sum=sum+e;
				}
			}
			}*/
		while(i.hasNext())
		{
		String key=(String) i.next();
		Float value=hm.get(key);
		System.out.println(key+"value "+hm.get(key));
		for(int q=0;q<arr.length;q++)
		{
			if(key.equals(arr[q]))
			{
				
				sum=sum+value;
				
			}
			
			
			
		}
		
		
		
		
		
		}
		System.out.println(sum);

	}

}
