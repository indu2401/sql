import java.util.*;
public class Main {

		public static void register(String name,String address,String contact,String mail,String type,String proof)
		{
			int count=1;
		System.out.println("Welcome "+name+".");
		System.out.println("Here are your details");
		System.out.println("Address: "+address);
		System.out.println("Contact Number: "+contact);
		System.out.println("E-Mail ID: "+mail);
		System.out.println("Proof type: "+type);
		System.out.println("Proof id: "+proof);
		System.out.println();
		System.out.println("Thank you for registering. Your id is "+count+"..");
		count++;
		}
		public static void main(String args[])
		{
			
			Scanner sc=new Scanner(System.in);
			System.out.println("Registration");
			System.out.println();
			System.out.println("Enter your name");
			String name=sc.nextLine();
			System.out.println("Enter your address");
			String address=sc.nextLine();
			System.out.println("Contact Number");
			String contact=sc.nextLine();
			System.out.println("E-Mail ID");
			String mail=sc.nextLine();
			System.out.println("Enter proof type");
			String type=sc.nextLine();
			System.out.println("Enter proof id");
			String proof=sc.nextLine();
			System.out.println();
			register(name,address,contact,mail,type,proof);
			sc.close();
		
		}

		

	}



