
import java.io.*;
import java.util.*;


 class  checkout extends Thread{  
	  public void run(){  
	    //System.out.println("My thread is in running state.");  
		  roomservice t2=new roomservice();   
		     t2.start();
		     try {
				t2.join();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    
			
		     System.out.println("Room Service is clear - You can proceed with checkout process");
		     Main mt=new Main();
		    if(mt.rt.equals("Normal"))
		     System.out.println("The total rent for "+mt.diffInDays+" Days is "+mt.diffInDays*1500);
		    if(mt.rt.equals("Deluxe"))
				     System.out.println("The total rent for "+mt.diffInDays+" Days is "+mt.diffInDays*2500);
		    if(mt.rt.equals("Super Deluxe"))
			     System.out.println("The total rent for "+mt.diffInDays+" Days is "+mt.diffInDays*3500);
		  
	  }   
}
	   class roomservice extends Thread{  
		  public void run(){  
		      System.out.println("Room Service Initiated for the room ");  
			  System.out.println("Room checking is going on");
			   
		  } 	}  
	  
public class Main {
static String rt;static int diffInDays;

	public static void main(String[] args) throws Exception {		
BufferedReader br=new BufferedReader(new InputStreamReader((System.in))); 

System.out.println("Do you want to check out yes/no");
String yn=br.readLine();
String cid,cod;String one[];
String two[];
if(yn.equals("yes"))
{
	System.out.println("Enter the check-in date");
	cid=br.readLine();
	 one=cid.split("/");
	/*for(String s:one){
	System.out.println(s);
	}*/
	System.out.println("Enter the check-out date");
	cod=br.readLine();
	 two=cod.split("/");
	/*for(String s:one){
		System.out.println(s);
		}*/
	
	System.out.println("Enter the Room Type:");
	System.out.println("Normal");
	System.out.println("Deluxe");
	System.out.println("Super Deluxe");
	rt=br.readLine();
	 Calendar calendar = Calendar.getInstance();  
     calendar.add(Calendar.DATE, Integer.parseInt(one[0]));  

     calendar.add(Calendar.MONTH, Integer.parseInt(one[1]));  

     calendar.add(Calendar.YEAR, Integer.parseInt(one[2])); 
     
     Calendar calendar1 = Calendar.getInstance();  
     calendar1.add(Calendar.DATE,Integer.parseInt(two[0]));  

     calendar1.add(Calendar.MONTH, Integer.parseInt(two[1]));  

     calendar1.add(Calendar.YEAR, Integer.parseInt(two[2]));  
     long ms1 = calendar.getTimeInMillis();
     long ms2 = calendar1.getTimeInMillis();
     // Calculate the difference in millisecond between two dates
     long diff= ms2-ms1;
     diffInDays = (int) (diff / (24 * 60 * 60 * 1000));
     //System.out.println(diffInDays);
     
	checkout t1=new checkout();   
     t1.start();
    
}else
{
	System.out.println("Thank you for continuing your stay");
}

	}

}
	  
