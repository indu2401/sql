
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String a="New York";
//System.out.println(a.charAt(1)+" "+a.charAt(0));

for(int i=1;i<a.length();i=i+2)
{  // System.out.println(i);
	System.out.print(a.charAt(i)+""+a.charAt(i-1));
}
	}

}
