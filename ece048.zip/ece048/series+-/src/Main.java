import java.util.Scanner;


public class Main {
	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	int n=sc.nextInt();
	int sum=1;
	for(int i=3,j=1;i<=n;i=i+2,j++)
	{
		if(j%2!=0)
		
			sum+=i;
		else
			sum-=i;
		System.out.println(sum);
	}
}
}
