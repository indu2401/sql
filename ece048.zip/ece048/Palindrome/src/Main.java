import java.util.*;
import java.io.*;


public class Main  {
	public static void main(String[] args) throws IOException {
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	boolean z;
String s=br.readLine();
UserMainCode obj=new UserMainCode();
z=obj.isPalindrome(s);
if(z==true)
{
	System.out.println(s+" is a palindrome");
}else
	System.out.println(s+" is not a palindrome");
}
}
