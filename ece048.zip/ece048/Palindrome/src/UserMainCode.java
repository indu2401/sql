
public class UserMainCode {

	static boolean isPalindrome(String s)
	{
		char[] a=s.toCharArray();
		int count=0;
		int length=a.length;int mid;
		if(length%2==0)
		 mid=length/2;
		else
			mid=length/2+1;
		//System.out.println(length);
		//System.out.println(mid);
		for(int i=0,j=length-1;i<length-1;i++,j--)
		{
			if(a[i]!=a[j])
			{
				//System.out.println(s+" is not a palindrome");count=1;
				return false;
			}
		}
		/*if(count==0)
		{
			System.out.println(s+" is a palindrome");
		}*/return true;
	}
}
