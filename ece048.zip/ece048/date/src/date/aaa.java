package date;

import java.text.SimpleDateFormat;
import java.util.*;
class Main
{
    public static void main(String[] args)throws Exception
    {
        Scanner sc=new Scanner(System.in);
        String t1=sc.next();
        String t2=sc.next();
        String t3=sc.next();
        int travel=sc.nextInt();
        
        SimpleDateFormat format=new SimpleDateFormat("HH:MM:SS");
        Date d1=format.parse(t1);
        Date d2=format.parse(t2);
        Date d3=format.parse(t3);
        
        long diff=d1.getTime()-d3.getTime();
        float train1sec=diff/(1000%60);
        float train1min=diff/((60*1000)%60);
        float train1hour=diff/(60*60*1000)%24;
        
        float total1diff=(train1hour*60)+train1min;
        
        
        long di=d2.getTime()-d3.getTime();
      float train2sec=diff/(1000%60);
        float train2min=diff/((60*1000)%60);
        float train2hour=diff/(60*60*1000)%24;
        
        float total2diff=(train2hour*60)+train2min;
        
        if(travel<total1diff)
        {
            System.out.println("Train1");
        }else if(travel<total2diff)
        {
            System.out.println("Train2");
        }else
        {
              System.out.println("No");
        }
        
        
       
        
    }
}