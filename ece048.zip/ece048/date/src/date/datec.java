package date;
import java.text.SimpleDateFormat;
import java.util.Date;
public class datec {

	public static void main(String[] args) throws Exception{
			
				String time1 = "05:00:00";
				String time2 = "06:01:00";
		 
				SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
				Date date1 = format.parse(time1);
				Date date2 = format.parse(time2);
				long diff = date2.getTime() - date1.getTime();
				//System.out.println(difference/(60*1000)%60);
				long diffSeconds = diff / 1000 % 60;
				long diffMinutes = diff / (60 * 1000) % 60;
				long diffHours = diff / (60 * 60 * 1000) % 24;
				//long diffDays = diff / (24 * 60 * 60 * 1000);

				//System.out.print(diffDays + " days, ");
				System.out.print(diffHours + " hours, ");
				System.out.print(diffMinutes + " minutes, ");
				System.out.print(diffSeconds + " seconds.");
			}
		
	}


