import java.util.Arrays;
import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		double sum=0;
		int arr[]=new int[n];
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
			 sum = (double) sum+Math.pow(arr[i], i);
		}
		Arrays.sort(arr);
		
		System.out.println(arr[arr.length-1]-arr[0]);
		System.out.println(sum);
	}

}
