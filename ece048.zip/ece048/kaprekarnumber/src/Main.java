
public class Main {
	public static void main(String[] args) {
int n=10;
int square=n*n;
String s=Integer.toString(square);
String a=s.substring(0,2);
String b=s.substring(2,s.length());

int x=Integer.parseInt(a);
int y=Integer.parseInt(b);
int mul=x+y;
if(n==mul&&x!=0&&y!=0)
{
	System.out.println("yes");
}
System.out.println(x);
System.out.println(y);
System.out.println(mul);

	}

}
