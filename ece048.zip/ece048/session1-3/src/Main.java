import java.io.BufferedReader;
import java.io.*;
import java.util.*;
public class Main {
	public static void CheckStatus(ArrayList<Integer> list,int search)
	{
		
		if(list.contains(search))
		{
			System.out.println("Room number "+search+" is booked.");
		}else
			System.out.println("Room number "+search+" is not booked.");
	}
	public static void book(String ac,String cot,String cable,String wifi,String laundry)//String //date)
	{int sum=0;
	
		if(ac.equals("AC"))
		{
			sum=sum+1000;
		}else
			sum=sum+750;
		
		if(cot.equals("Single"))
		{
			sum=sum+0;
		}else
			sum=sum+350;
		
		if(cable.equals("C"))
		{
			sum=sum+50;
		}
		
		if(wifi.equals("W"))
		{
			sum=sum+200;
		}
		
		if(laundry.equals("L"))
		{
			sum=sum+100;
		}
		String a,c,w,l;
		if(ac.equals("nAC")){
			 a="non-AC";
		}else
			 a="AC";
		if(cable.equals("C"))
		{
			 c="enabled";
		}else
			c="disabled";
		
		if(wifi.equals("W"))
		{
			 w="enabled";
		}else
			w="disabled";
		
		if(laundry.equals("L"))
		{
			 l="with ";
		}else
			l="without ";
		
		
		
		System.out.println("The total charge is Rs."+sum+".");
		System.out.println("The services chosen are\n"+cot+" cot "+a+" room");
		System.out.println("Cable connection "+c);
		System.out.println("Wi-Fi "+w);
		System.out.println(l+"laundry service");
		//System.out.println("and the Date of Booking is "+date);
		//System.out.println("\n");
		
		
	}
	public static void main(String args[])throws Exception
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		int count=1,choice=0;
		String ac, cot, cable, wifi, laundry,yn="";
		ArrayList<Integer> a=new ArrayList<Integer>();
		do{
		System.out.println("Menu");
		System.out.println("1. Book");
		System.out.println("2. Check Status");
		System.out.println("3. Exit");
		System.out.println("Enter your choice");
choice=Integer.parseInt(br.readLine());
		if(choice==1)
		{	
			do{
		System.out.println("Booking:");
			
		System.out.println("Please choose the services required.\nAC/non-AC(AC/nAC)");
		ac=br.readLine();
		System.out.println("Cot(Single/Double)");
		cot=br.readLine();
		System.out.println("With cable connection/without cable connection(C/nC)");
		cable=br.readLine();
		
		System.out.println("Wi-Fi needed or not(W/nW)");
		wifi=br.readLine();
		
		System.out.println("Laundry service needed or not(L/nL)");
		laundry=br.readLine();
		
		//System.out.println("Enter the Date of Booking");
		//date=br.readLine();
		//System.out.println();

		//System.out.println("Enter the Date of Booking");
		
		
		
		book(ac, cot, cable, wifi, laundry);
		//System.out.println();
		System.out.println("Do you want to proceed?(yes/no)");
		//System.out.println();
		yn=br.readLine();
		}while(yn.equals("no"));
		
		System.out.println("Thank you for booking. Your room number is "+count+".");
		a.add(count);
		count++;
		
		//br.close();
	}
		if(choice==2){
			int key;
			System.out.println("Check Status:");
			System.out.println("Enter room number");
			
			key=Integer.parseInt(br.readLine());
			CheckStatus(a,key);
		}
	}while(choice!=3);
	}
}


