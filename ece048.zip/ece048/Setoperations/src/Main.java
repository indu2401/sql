import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;


public class Main {
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		ArrayList a=new ArrayList();
		ArrayList b=new ArrayList();
		for(int i=0;i<n;i++)
		{
			a.add(sc.nextInt());
		}
		for(int i=0;i<n;i++)
		{
			b.add(sc.nextInt());
		}
		String c=sc.next();
		
		operations(a,b,c);
	
	}

	private static void operations(ArrayList a, ArrayList b, String c) {
		// TODO Auto-generated method stub
		HashSet hs=new HashSet();
		ArrayList p=new ArrayList();
		ArrayList q=new ArrayList();
		//System.out.println(c);
		//System.out.println("a"+a.size());
		//System.out.println("a"+b.size());
	if(c.equals("+"))
	{
		
		for(int i=0;i<a.size();i++)
		{
			int z=(int) a.get(i);
			hs.add(z);
		}
		for(int i=0;i<b.size();i++)
		{
			//System.out.println("yes");
			int z=(int) b.get(i);
			hs.add(z);
		}
		for(Object i:hs)
		{
			System.out.println("union"+i);
		}
		
	}
	
	if(c.equals("*"))
	{
		//System.out.println("a"+a.size());
		//System.out.println("a"+b.size());
		for(int i=0;i<a.size();i++)
		{	//System.out.print(i);
			for(int j=0;j<b.size();j++)
			{
				//System.out.print(i+" "+j);
				if(a.get(i)==b.get(j)&&!(p.contains(a.get(i))))
				{
					p.add(a.get(i));
			    }
			
			}
		}
		
		for(Object i:p)
		{
			System.out.println("intersection"+i);
		}
		
	}
	
	if(c.equals("-"))
	{
		for(int i=0;i<a.size();i++)
		{
			for(int j=0;j<b.size();j++)
			{
				if(!(b.contains(a.get(i)))&!(q.contains(a.get(i))))
				{
					q.add(a.get(i));
			    }
			
			}
		}
		
		for(Object i:q)
		{
			System.out.println("difference"+i);
		}
		
	}
		
	}
}
