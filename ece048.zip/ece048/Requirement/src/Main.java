import java.util.HashMap;
import java.util.Iterator;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Scanner sc=new Scanner(System.in);
		int n=5;
//int noofelements=Sc.nextInt();
HashMap hm1=new HashMap();
HashMap hm2=new HashMap();
hm1.put(101, "Jack");
hm2.put(101,"jack@gmail.com");
hm1.put(102, "Mainsh");
hm2.put(102,"Mainsh@gmail.com");
hm1.put(103, "suchita");
hm2.put(103,"suchita@gmail.com");
hm1.put(104, "vignesh");
hm2.put(104,"vignesh@gmail.com");
hm1.put(105, "Vini");
hm2.put(105,"Vini@gmail.com");
int key=105;
find(key,hm1,hm2);
display(hm1,hm2);
}

	private static void display(HashMap hm1, HashMap hm2) {
		// TODO Auto-generated method stub
		Iterator i=hm1.keySet().iterator();
		while(i.hasNext())
		{
			int k=(int) i.next();
				System.out.println("id "+k+" name: "+hm1.get(k)+" email id "+hm2.get(k));
			
		}
		
	}

	private static void find(int key, HashMap hm1, HashMap hm2) {
		// TODO Auto-generated method stub
		Iterator i=hm1.keySet().iterator();
		while(i.hasNext())
		{
			int k=(int) i.next();
			int count=0;
			if(key==k)
			{
				System.out.println(hm1.get(k)+" "+hm2.get(k));
				count=1;
			} /*if(!(hm1.keySet().contains(k)))
			{
				System.out.println("id "+k+" name: "+hm1.get(k)+" email id "+hm2.get(k));
			}*/
		}
		
		
	}
}