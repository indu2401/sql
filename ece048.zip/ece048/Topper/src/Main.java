import java.io.*;
public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
int n=Integer.parseInt(br.readLine());
boolean ans;
UserMainCode obj=new UserMainCode();
ans=obj.isTopper(n);
if(ans==true)
	System.out.println("yes");
else System.out.println("no");
	
	}

}
