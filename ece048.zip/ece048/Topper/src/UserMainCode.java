
public class UserMainCode {
	static boolean isTopper(int a)
	{
		boolean flag = false;
	int sumEven = 0, SumODD=0, count =0;
	while(a>0){
		int rem = a % 10;
		a = a / 10;
		
		if(rem % 2 ==0){
			sumEven += rem;
		}
		else if(rem % 2 !=0){
			SumODD += rem;
		}
	}
	
	if(sumEven == SumODD){
		flag = true;
	}
	return flag; 

		
	}
}
