
public class Main {
public static void main(String args[])
{
	String a="What is your name?";
	String arr[]=a.split(" ");
	int max=0,ans=0;
	for(int i=0;i<arr.length;i++)
	{
		//System.out.println(arr[i]);
		int count=checkvowel(arr[i]);
		if(max<count)
		{
			max=count;
			ans=i;
		}
		
	}
	System.out.println(ans);
	System.out.println(arr[ans]);

}

private static int checkvowel(String s) {
	char a[]=s.toCharArray();
	int count=0;
	for(int i=0;i<a.length;i++)
	{
		//System.out.println(a[i]);
		if(a[i]=='a'||a[i]=='e'||a[i]=='i'||a[i]=='o'||a[i]=='u'||a[i]=='A'||a[i]=='E'||a[i]=='I'||a[i]=='O'||a[i]=='U')
			count++;
	}
	return count;
	
}
}
