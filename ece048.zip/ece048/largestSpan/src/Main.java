
public class Main {
	public static void main(String[] args) {
		int a[]={4,2,1,4,5,7};
		int b[]={1,4,2,1,4,1,5};
		int len=b.length;
		int diff=0,max=0;
		for(int i=0;i<(a.length);i++)
		{
			for(int j=0;j<(a.length);j++)
			{
				System.out.print(i+" "+j+" "+"|");
				if(a[i]==a[j])
				{
					diff=i-j;
				}
				if(max<diff)
					max=diff;
					
			}System.out.println();
		}
		System.out.println(max+1);
	}
}
