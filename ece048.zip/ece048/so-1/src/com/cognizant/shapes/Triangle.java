package com.cognizant.shapes;

public class Triangle {
	int sides;
	public static void calculateArea(int sides)
	{
		System.out.println("The area of triangle is "+(0.4333*sides*sides));
	}

}
