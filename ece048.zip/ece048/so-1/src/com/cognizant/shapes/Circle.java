package com.cognizant.shapes;

public class Circle {
int radius;
public static void calculateArea(int radius)
{
	System.out.println("The area of circle is "+(3.14*radius*radius));
}
}
