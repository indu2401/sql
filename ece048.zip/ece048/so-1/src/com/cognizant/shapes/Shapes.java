package com.cognizant.shapes;

public class Shapes {
int numberOfSides;
//static Circle c=new Circle();
//static Square s=new Square();
//static Triangle t=new Triangle();
public static void calculateShapeArea(int no,int side){
	
if(no==1)
{

Circle.calculateArea(side);
}else
if(no==4)
{
	Square.calculateArea(side);
	
}else
if(no==3)
{
	Triangle.calculateArea(side);
}else
{
	System.out.println("No Shapes Present");
}

}
public static void main(String args[])
{calculateShapeArea(3,12);
calculateShapeArea(4,15);
calculateShapeArea(5,15);
	
}

}