
public class UserMainCode {
 static String processString(String s)
{
	 String q=s;
	 String d ="";
	 //q.toUpperCase();
	 String[] a=s.split(" ");
	 //String[] b=q.split(" ");
	 
	 //System.out.println(q);
	 
	 for(int i=0;i<a.length;i++)
	 {
		 
		 d =d+a[i].substring(0, 1).toUpperCase() +a[i].substring(1);
		 d=d+" ";
			 
 	

	 }
	 
	 
	return d;
	
}
}
