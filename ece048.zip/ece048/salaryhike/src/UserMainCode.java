import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;


public class UserMainCode {

	static public TreeMap<Integer,Integer> newsal(HashMap hm1,HashMap hm2) throws ParseException
	{
		Iterator i=hm1.keySet().iterator();
		TreeMap<Integer,Integer> tm=new TreeMap<Integer,Integer>();
		int id,sal,yearnow,year,age=0;
		String bday;
		int newsal=0;
		while(i.hasNext())
		{
			id=(int) i.next();
			
			bday=(String) hm1.get(id);
			
			sal=(int) hm2.get(id);
			
			
			SimpleDateFormat sd=new SimpleDateFormat("dd-MM-yyyy");
			Calendar c1=Calendar.getInstance();
			yearnow=c1.get(Calendar.YEAR);
			
			Date d=sd.parse(bday);
			c1.setTime(d);
			
			year=c1.get(Calendar.YEAR);
			
			System.out.println(year);
			System.out.println(yearnow);
			
			 age=(year-yearnow);
			
			System.out.println("age"+age);
			
			if(age==31){
				System.out.println("age"+age);
				newsal=(int) (sal+(sal*.2));
			}
			System.out.println("age"+age);
			System.out.println("sal"+sal);
			System.out.println("newsal"+newsal);
			tm.put(id, newsal);
			
			
			
		}
		
		
		
		
		
		return tm;
		
	}
}
