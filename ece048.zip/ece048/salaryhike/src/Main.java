import java.text.ParseException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeMap;


public class Main {

	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
int n=sc.nextInt();
HashMap<Integer,String> hm1=new HashMap<Integer,String>();
HashMap<Integer,Integer> hm2=new HashMap<Integer,Integer>();
for(int i=0;i<n;i++)
{
	int id=sc.nextInt();
	String dob=sc.next();
	int sal=sc.nextInt();
	
	hm1.put(id, dob);
	hm2.put(id,sal);
	
	
	
	
}


TreeMap<Integer,Integer> tm=new TreeMap<Integer,Integer>();

tm=UserMainCode.newsal(hm1, hm2);

Iterator i=hm1.keySet().iterator();

while(i.hasNext())
{
	 int key=(int) i.next();
	System.out.println(key+":"+tm.get(key));
}


	}

}
