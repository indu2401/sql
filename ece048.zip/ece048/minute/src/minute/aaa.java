package minute;

import java.text.SimpleDateFormat;
import java.util.Date;

public class aaa {
	//DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

	String time1 = "05:00:00";
	String time2 = "06:01:00";

	SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
	Date date1 = format.parse(time1);
	Date date2 = format.parse(time2);
	long diff = date2.getTime() - date1.getTime();
	LocalDateTime dateTime1= LocalDateTime.parse("2014-11-25 19:00:00", formatter);
	LocalDateTime dateTime2= LocalDateTime.parse("2014-11-25 16:00:00", formatter);

	long diffInMilli = java.time.Duration.between(dateTime1, dateTime2).toMillis();
	long diffInSeconds = java.time.Duration.between(dateTime1, dateTime2).getSeconds();
	long diffInMinutes = java.time.Duration.between(dateTime1, dateTime2).toMinutes();
}
