import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String password=sc.next();
		int length=password.length();
		char[] a=password.toCharArray();
		
		int symbol=0,digits=0;
		for(int i=0;i<a.length;i++)
		{
			if(a[i]=='@'||a[i]=='#'||a[i]=='$')
			{
				symbol++;
			}
			if(a[i]=='1'||a[i]=='2'||a[i]=='3'||a[i]=='4'||a[i]=='5'||a[i]=='6'||a[i]=='7'||a[i]=='8'||a[i]=='9'||a[i]=='0')
			{
				digits++;
			}
			
			
		}
		if(length>6||length<20&&symbol>=1&&digits>=1)
		{
			System.out.println("valid");
		}
	}

}
