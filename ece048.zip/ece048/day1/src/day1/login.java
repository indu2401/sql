package day1;

import java.util.Scanner;

public class login {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Scanner sc=new Scanner(System.in);
		// String Userid="admin",password="adminpassword123";
		String username[]={"aaa","bbb","ccc","ddd","eee"};
		String passwords[]={"111","222","333","444","555"};
		
		 System.out.println("Enter the userid");
		 String Userid = sc.next();
		 System.out.println("Enter the password");
		 String password = sc.next();
		//if(Userid.equals("admin") && password.equals("adminpassword123"))
		 int count=0;
		 for(int i=0;i<4;i++)
		 {
			 if(Userid.equals(username[i])&& password.equals(passwords[i]))
			{
				//System.out.println("logged in");
				 count =1;
			}
		 }
		 if(count==1)
		 {
		 System.out.println("logged in");
		 }
		 else
		 { System.out.println("Invalid credintials");	 
		}
		 }
	}



