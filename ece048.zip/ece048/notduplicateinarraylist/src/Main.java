import java.util.ArrayList;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ArrayList a=new ArrayList();
ArrayList b=new ArrayList();
ArrayList c=new ArrayList();
a.add(10);
a.add(20);
a.add(30);
b.add(10);
b.add(20);
b.add(50);

for(int i=0;i<a.size();i++)
{
	for(int j=0;j<b.size();j++)
	{
		if(a.get(i)!=b.get(j))
		{
			c.add(a.get(i));
		}
	}
}




	}

}
