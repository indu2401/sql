import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;


public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
ArrayList a=new ArrayList();
ArrayList b=new ArrayList();
ArrayList c=new ArrayList();
for(int i=0;i<5;i++)
{
	a.add(Integer.parseInt(br.readLine()));
}
for(int i=0;i<5;i++)
{
	b.add(Integer.parseInt(br.readLine()));
}
c.addAll(a);
c.addAll(b);
Collections.sort(c);
System.out.println(c.get(2));
System.out.println(c.get(6));
System.out.println(c.get(8));



	}

}
