import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
String alphabets="abcdefghijklmnopqrstuvwxyz";
char[] arr=alphabets.toCharArray();
String code=sc.next();
String ans="";
//System.out.println(code.length());
for(int i=0;i<code.length();i++)
{
	if(i%2==0)
	{
		if(code.charAt(i)=='z')
	{
		ans=ans+'a';
	}else{

	for(int j=0;j<arr.length-1;j++)
	{
		
		if(code.charAt(i)==arr[j])
		{
			
			ans=ans+arr[j+1];
			
			
		}
	}}
}else
	ans=ans+code.charAt(i);

	}
System.out.println(ans);
	
}
}