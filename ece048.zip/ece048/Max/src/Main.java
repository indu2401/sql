import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		int a=Integer.parseInt(br.readLine());
		int b=Integer.parseInt(br.readLine());
		int c=Integer.parseInt(br.readLine());
		if(a>b&&a>c)System.out.println(a+" is the maximum number");
		if(b>a&&b>c)System.out.println(b+" is the maximum number");
		if(c>a&&c>b)System.out.println(c+" is the maximum number");
		
		
		
	}

}
