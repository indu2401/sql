import java.io.BufferedReader;
import java.io.*;
public class Main {
	public static void book(String ac,String cot,String cable,String wifi,String laundry,String date)
	{int sum=0;
	
		if(ac.equals("AC"))
		{
			sum=sum+1000;
		}else
			sum=sum+750;
		
		if(cot.equals("Single"))
		{
			sum=sum+0;
		}else
			sum=sum+350;
		
		if(cable.equals("C"))
		{
			sum=sum+50;
		}
		
		if(wifi.equals("W"))
		{
			sum=sum+200;
		}
		
		if(laundry.equals("L"))
		{
			sum=sum+100;
		}
		String a,c,w,l;
		if(ac.equals("nAC")){
			 a="non-AC";
		}else
			 a="AC";
		if(cable.equals("C"))
		{
			 c="enabled";
		}else
			c="disabled";
		
		if(wifi.equals("W"))
		{
			 w="enabled";
		}else
			w="disabled";
		
		if(laundry.equals("L"))
		{
			 l="with ";
		}else
			l="without ";
		
		
		
		System.out.println("The total charge is Rs."+sum+".");
		System.out.println("The services chosen are\n"+cot+" cot "+a+" room");
		System.out.println("Cable connection "+c);
		System.out.println("Wi-Fi "+w);
		System.out.println(l+"laundry service");
		System.out.println("and the Date of Booking is "+date);
		//System.out.println("\n");
		
		
	}
	public static void main(String args[])throws Exception
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		int count=1;
		String ac, cot, cable, wifi, laundry,date,yn;
		System.out.println("Booking:\n");
		do{
			
		//System.out.println("Booking:\n");
		System.out.println("Please choose the services required.\nAC/non-AC(AC/nAC)");
		ac=br.readLine();
		System.out.println("Cot(Single/Double)");
		cot=br.readLine();
		System.out.println("With cable connection/without cable connection(C/nC)");
		cable=br.readLine();
		
		System.out.println("Wi-Fi needed or not(W/nW)");
		wifi=br.readLine();
		
		System.out.println("Laundry service needed or not(L/nL)");
		laundry=br.readLine();
		
		System.out.println("Enter the Date of Booking");
		date=br.readLine();
		System.out.println();

		//System.out.println("Enter the Date of Booking");
		
		
		
		book(ac, cot, cable, wifi, laundry,date);
		System.out.println();
		System.out.println("Do you want to proceed?(yes/no)");
		System.out.println();
		yn=br.readLine();
		}while(yn.equals("no"));
		
		System.out.println("Thank you for booking. Your room number is "+count+".");
		br.close();
	}

}
