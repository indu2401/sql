import java.util.ArrayList;
import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
	ArrayList al=new ArrayList();
	int n=sc.nextInt();
	for(int i=0;i<n;i++)
	{
		String s=sc.next();
		
		al.add(s);
				
	}
	score(al);

	}

	private static void score(ArrayList al) {
		int max=0,i=0;
		String ans="";
		int sum[]=new int[al.size()];
		for(Object s:al)
		{
		String[] arr=((String) s).split("-");
		String name=arr[0];
		int mark1=Integer.parseInt(arr[1]);
		int mark2=Integer.parseInt(arr[2]);
		int mark3=Integer.parseInt(arr[3]);
		
		sum[i]=mark1+mark2+mark3;
	
		
		if(max<sum[i])
			max=sum[i];
		    ans=name;
		
		
			i++;
		
		
		}
			
	//System.out.println(max);
	System.out.println(max);
	System.out.println(ans);
	
		
	}

}
