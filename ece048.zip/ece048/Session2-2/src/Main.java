import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class Main {

	public static void main(String[] args) throws  IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		String  roomId, roomType, roomNumber, roomCapacity, roomAc, roomWifi, roomCabel, roomLaundry,yn;
		System.out.println("Enter the Hotel details:");
		System.out.println("Enter the Hotel Name:");
		String name=br.readLine();
		System.out.println("Enter the Hotel ID:");
		String hotelId=br.readLine();
		System.out.println("Enter the Hotel Address");
		String address=br.readLine();
		do{
		System.out.println("Enter the Room Details:");
		System.out.println("Enter the Room Id:");
		roomId=br.readLine();
		System.out.println("Enter the Room Number:");
		roomNumber=br.readLine();
		System.out.println("Enter the Room Type:");
		System.out.println("1)Normal");
		System.out.println("2)Delux");
		System.out.println("3)Super Delux");
		roomType=br.readLine();
		System.out.println("Enter the Room Capacity:(1/2/3/4)");
		roomCapacity=br.readLine();
		System.out.println("AC Service (true/false):");
		roomAc=br.readLine();
		System.out.println("Wi-Fi Service (true/false):");
		roomWifi=br.readLine();
		System.out.println("Cable Service (true/false):");
		roomCabel=br.readLine();
		System.out.println("Laundry Service (true/false):");
		roomLaundry=br.readLine();
		System.out.println("Do you want to add Another Room (yes/no):");
		yn=br.readLine();
		//System.out.println(yn);
		Room r=new Room(roomId, roomType, roomNumber, roomCapacity, roomAc, roomWifi, roomCabel, roomLaundry);
		r.add();
		
		
		
	}while(yn.equals("yes"));
	
		
		if(yn.equals("no"))
		{
			Hotel h=new Hotel(name, hotelId, address);
			Hotel.display();
		}
		
	}

}
