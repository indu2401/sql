
public class UserMainCode {
	
	
static int findRupees(String s)
{
	char[] arr={'q','w','e','r','t','y','u','i','o','p','a','s','d','f','g','h','j','k','l','z','x','c','v','b','n','m'};
	String type="qwertyuiopasdfghjklzxcvbnm";
	int count=0;int position=0;int rupees=0;
	char[] b=s.toCharArray();
	for(int i=0;i<b.length;i++)
	{
		
		int j=type.indexOf(b[i]);
		
		if(position<j)
		count=position+j;
	
		
		
		if(position>j)
			count=position-j;rupees=count;
		
		position=j;
		
		
		
		
	}
	
	
	
	return rupees;
	
}
}
